BFFT Cartoon for OBS Studio 32.1.x — Windows x64
=================================================

This build includes Cartoon + texture, Difference field, Liquid chrome
relief, and Fine chrome.

Install
-------

1. Close OBS Studio.
2. Open the OBS Studio installation directory. The default is:

       C:\Program Files\obs-studio

3. Copy the "obs-plugins" folder from this archive into that directory.
   Allow Windows to merge the folder.
4. Start OBS Studio.
5. Open a video source's Filters, add "BFFT Cartoon", and choose a display
   mode. Fine chrome is the fourth mode.

The resulting DLL path should be:

    C:\Program Files\obs-studio\obs-plugins\64bit\bfft-cartoon.dll

Compatibility
-------------

* Windows 10 or 11, x64
* OBS Studio 32.1.x, x64
* No separate BFFT, MinGW, or Visual C++ runtime installation is required.

If OBS was running during installation, restart it before looking for the
filter.
