import unittest

import numpy as np

from build_first_ttf import simplify_closed


class FirstTtfTests(unittest.TestCase):
    def test_closed_simplification_preserves_a_loop(self):
        angle = np.linspace(0.0, 2.0 * np.pi, 10240, endpoint=False)
        circle = np.column_stack((100.0 * np.cos(angle), 100.0 * np.sin(angle)))
        simplified = simplify_closed(circle, 0.8)
        self.assertGreaterEqual(len(simplified), 8)
        self.assertLess(len(simplified), 10240)


if __name__ == "__main__":
    unittest.main()
