import unittest

import numpy as np

from makima_quadratic import compile_master, periodic_makima_master


class MakimaQuadraticTests(unittest.TestCase):
    def test_periodic_circle_closes_with_bounded_error(self):
        angle = np.linspace(0.0, 2.0 * np.pi, 2048, endpoint=False)
        circle = np.column_stack((150.0 * np.cos(angle), 150.0 * np.sin(angle)))
        master = periodic_makima_master(circle)
        segments = compile_master(master)
        self.assertLessEqual(master.maximum_error, 0.65)
        self.assertTrue(np.allclose(segments[0].start, segments[-1].end))
        self.assertLessEqual(max(segment.error for segment in segments), 0.42)

    def test_square_corners_are_hard_events(self):
        edge = np.linspace(-100.0, 100.0, 256, endpoint=False)
        square = np.vstack((
            np.column_stack((edge, np.full_like(edge, -100.0))),
            np.column_stack((np.full_like(edge, 100.0), edge)),
            np.column_stack((edge[::-1], np.full_like(edge, 100.0))),
            np.column_stack((np.full_like(edge, -100.0), edge[::-1])),
        ))
        master = periodic_makima_master(square)
        self.assertGreaterEqual(len(master.hard_indices), 4)
        self.assertLessEqual(master.maximum_error, 0.65)


if __name__ == "__main__":
    unittest.main()
