from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from portsmouth_engine import EikonalMidpointEngine, source_applies  # noqa: E402


class EngineTests(unittest.TestCase):
    def test_source_routes_are_case_specific(self):
        self.assertTrue(source_applies("SyneMono-Regular.ttf", "M"))
        self.assertFalse(source_applies("SyneMono-Regular.ttf", "m"))
        self.assertTrue(source_applies("bedstead.otf", "m"))
        self.assertFalse(source_applies("bedstead.otf", "M"))
        self.assertFalse(source_applies("bedstead.otf", "4"))
        self.assertFalse(source_applies("xenia_regular.ttf", "4"))

    def test_midpoint_uses_equal_weights_and_valid_binary_geometry(self):
        engine = EikonalMidpointEngine(pixels_per_unit=0.25)
        result = engine.midpoint("M")
        self.assertEqual(len(result.sources), 4)
        self.assertEqual(result.diagnostics["equalWeight"], 0.25)
        self.assertEqual(result.mask.dtype, np.bool_)
        self.assertTrue(np.any(result.mask))
        self.assertTrue(np.all(result.sdf[result.mask] <= 0))
        self.assertTrue(np.all(result.sdf[~result.mask] >= 0))
        self.assertEqual(result.diagnostics["consensusTopology"], {"components": 1, "holes": 0})
        self.assertEqual(result.diagnostics["midpointTopology"], {"components": 1, "holes": 0})

    def test_common_coverage_contains_printable_ascii(self):
        engine = EikonalMidpointEngine(pixels_per_unit=0.1)
        shared = set(engine.shared_codepoints())
        self.assertTrue(set(range(0x20, 0x7F)) <= shared)

    def test_letter_maximum_height_is_equal_after_normalization(self):
        engine = EikonalMidpointEngine(pixels_per_unit=0.5)
        fields = [
            engine.source_field(source, "m") for source in engine.active_sources("m")
        ]
        tops = []
        for field in fields:
            top_row = int(np.min(np.nonzero(field.mask)[0]))
            tops.append(engine.y_max - (top_row + 0.5) / engine.pixels_per_unit)
        self.assertLessEqual(max(tops) - min(tops), 2.0)


if __name__ == "__main__":
    unittest.main()
