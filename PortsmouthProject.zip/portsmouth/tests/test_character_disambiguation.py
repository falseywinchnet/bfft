import unittest

from audit_character_disambiguation import audit


class CharacterDisambiguationTests(unittest.TestCase):
    def test_zero_one_i_capital_i_and_l_remain_distinct(self):
        report = audit()
        self.assertTrue(report["passed"], report["checks"])


if __name__ == "__main__":
    unittest.main()
