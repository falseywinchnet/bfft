from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from medial_transport import (  # noqa: E402
    MedialMeasure,
    diffusive_geometric_basis,
    intrinsic_graph_barycenter,
)
from transport_barycenter import free_support_barycenter  # noqa: E402


class MedialTransportTests(unittest.TestCase):
    def test_diffusive_basis_preserves_a_shared_translation_geometry(self):
        left = np.array([
            [0.0, 0.0, 2.0], [0.0, 4.0, 2.0],
            [3.0, 0.0, 1.0], [3.0, 4.0, 1.0],
        ])
        right = left + np.array([10.0, 2.0, 0.0])
        mass = np.full(4, 0.25)
        result = free_support_barycenter(
            [left, right], [mass, mass], scale=np.array([10.0, 10.0, 2.0])
        )
        solved, info = diffusive_geometric_basis(result, neighbors=2)
        self.assertEqual(info["nodes"], 4)
        self.assertAlmostEqual(float(np.mean(solved[:, 0])), 6.5, places=6)
        self.assertAlmostEqual(float(np.mean(solved[:, 1])), 3.0, places=6)
        np.testing.assert_allclose(np.sort(solved[:, 2]), [1.0, 1.0, 2.0, 2.0])

    def test_intrinsic_transport_keeps_exact_marginals(self):
        first = np.array([
            [0.0, 0.0, 2.0], [2.0, 0.0, 2.0], [5.0, 0.0, 1.0]
        ])
        second = first[[2, 0, 1]] + np.array([4.0, 1.0, 0.0])
        distance_first = np.abs(first[:, 0, None] - first[None, :, 0])
        distance_second = distance_first[np.ix_([2, 0, 1], [2, 0, 1])]
        mass = np.full(3, 1.0 / 3.0)
        measures = [
            MedialMeasure(first, mass, distance_first),
            MedialMeasure(second, mass, distance_second),
        ]
        initial = free_support_barycenter(
            [first, second], [mass, mass], scale=np.array([10.0, 10.0, 2.0])
        )
        result, _ = intrinsic_graph_barycenter(measures, initial)
        for plan in result.plans:
            np.testing.assert_allclose(plan.sum(axis=1), mass)
            np.testing.assert_allclose(plan.sum(axis=0), mass)


if __name__ == "__main__":
    unittest.main()
