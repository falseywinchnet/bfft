from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from boundary_trace import (  # noqa: E402
    BoundaryCloud,
    _phase_align_clouds,
    contour_relation_signature,
)
from outline_geometry import ContourComplex, ContourLoop, union_contour_complex  # noqa: E402
from run_multicontour_trace_experiment import retain_persistent_loops  # noqa: E402
from run_multicontour_trace_experiment import pair_loops  # noqa: E402
from run_multicontour_trace_experiment import (  # noqa: E402
    _contains_point,
    hole_owner_indices,
)


class MulticontourTests(unittest.TestCase):
    def test_nonzero_union_retains_counter(self):
        outer = np.array([[0.0, 0.0], [8.0, 0.0], [8.0, 8.0], [0.0, 8.0]])
        hole = np.array([[2.0, 2.0], [2.0, 6.0], [6.0, 6.0], [6.0, 2.0]])
        complex_ = union_contour_complex([outer, hole], pixels_per_unit=4.0)
        self.assertEqual(len(complex_.outer), 1)
        self.assertEqual(len(complex_.holes), 1)

    def test_cyclic_phase_synchronization_removes_arbitrary_seam(self):
        angle = np.linspace(0.0, 2.0 * np.pi, 256, endpoint=False)
        points = np.column_stack((80.0 * np.cos(angle), 55.0 * np.sin(angle)))
        anchors = np.column_stack((30.0 * np.cos(angle), 20.0 * np.sin(angle)))
        clouds = [
            BoundaryCloud("one", points, anchors),
            BoundaryCloud("two", np.roll(points, 73, axis=0), np.roll(anchors, 73, axis=0)),
        ]
        aligned, detail = _phase_align_clouds(clouds)
        self.assertLess(np.max(np.abs(aligned[0].points - aligned[1].points)), 1e-9)
        self.assertEqual(detail["operator"], "equal_source_cyclic_phase_synchronization")

    def test_contour_relation_signature_tracks_clearance(self):
        angle = np.linspace(0.0, 2.0 * np.pi, 256, endpoint=False)
        inner = np.column_stack((7.0 * np.cos(angle), 7.0 * np.sin(angle)))
        outer = np.column_stack((10.0 * np.cos(angle), 10.0 * np.sin(angle)))
        signature = contour_relation_signature(inner, outer)
        self.assertLess(abs(float(np.median(signature[:, 0])) - 3.0), 0.02)

    def test_persistence_retains_largest_expected_counter(self):
        def loop(role, area):
            return ContourLoop(
                points=np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]]),
                role=role,
                area=float(area),
                centroid=np.zeros(2),
            )
        complex_ = ContourComplex([
            loop("outer", 100.0), loop("hole", 40.0), loop("hole", 1.0)
        ])
        retained, discarded = retain_persistent_loops(
            complex_, {"components": 1, "holes": 1}
        )
        self.assertEqual([value.area for value in retained.holes], [40.0])
        self.assertEqual(discarded, [{"role": "hole", "area": 1.0}])

    def test_pair_loops_accepts_unity_without_counters(self):
        empty = ContourComplex([])
        self.assertEqual(pair_loops([empty, empty], "hole"), [])

    def test_counter_ownership_follows_containment(self):
        def contour(points, role):
            points = np.asarray(points, dtype=float)
            return ContourLoop(
                points=points,
                role=role,
                area=abs(float(np.sum(
                    points[:, 0] * np.roll(points[:, 1], -1)
                    - points[:, 1] * np.roll(points[:, 0], -1)
                ))) / 2,
                centroid=np.mean(points, axis=0),
            )
        base = contour([[0, 0], [10, 0], [10, 10], [0, 10]], "outer")
        accent = contour([[2, 14], [8, 14], [5, 18]], "outer")
        hole = contour([[3, 3], [7, 3], [7, 7], [3, 7]], "hole")
        self.assertTrue(_contains_point(base.points, hole.centroid))
        self.assertEqual(
            hole_owner_indices([[base, base], [accent, accent]], [[hole, hole]]),
            [0],
        )


if __name__ == "__main__":
    unittest.main()
