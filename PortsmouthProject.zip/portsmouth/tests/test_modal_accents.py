import json
import unittest

import numpy as np

from build_modal_accents import CHARACTERS
from portsmouth_engine import PROJECT


class ModalAccentTests(unittest.TestCase):
    def test_approved_accents_are_archived_as_detached_compounds(self):
        for character in CHARACTERS:
            stem = f"{ord(character):04x}"
            geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
            report_path = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
            report = json.loads(report_path.read_text())
            self.assertEqual(
                report["status"], "experimental_user_approved_modal_topology"
            )
            self.assertEqual(report["outputTopology"]["components"], 2)
            with np.load(geometry, allow_pickle=False) as archive:
                contour_keys = [
                    key for key in archive.files
                    if key not in {"character", "unitsPerEm"}
                ]
                self.assertTrue(contour_keys)
                self.assertTrue(all(archive[key].shape == (10240, 2) for key in contour_keys))


if __name__ == "__main__":
    unittest.main()
