from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from dense_fingerprint import DenseFingerprint, anneal_fingerprints  # noqa: E402


class DenseFingerprintTests(unittest.TestCase):
    def test_equal_source_neighborhood_anneal_moves_clouds_together(self):
        left = np.array([[0.0, 0.0], [0.0, 2.0], [0.0, 4.0]])
        right = left + np.array([4.0, 0.0])
        fingerprints = []
        for name, points in (("left", left), ("right", right)):
            fingerprints.append(DenseFingerprint(
                source=name,
                native_points=points.copy(),
                transported_points=points.copy(),
                tether_points=points.copy(),
                source_anchor=np.arange(3),
                median_anchor=np.arange(3),
                median_anchor_points=points.copy(),
                relative_tangent_normal=np.zeros((3, 2)),
            ))
        before = np.mean(right[:, 0]) - np.mean(left[:, 0])
        result, _ = anneal_fingerprints(
            fingerprints,
            schedule=((6, 0.5, 0.1),),
            passes_per_stage=2,
        )
        after = np.mean(result[1][:, 0]) - np.mean(result[0][:, 0])
        self.assertLess(after, before)


if __name__ == "__main__":
    unittest.main()
