from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from boundary_trace import resample_closed  # noqa: E402


class BoundaryTraceTests(unittest.TestCase):
    def test_closed_resampling_is_dense_and_ordered(self):
        square = np.array([[0.0, 0.0], [3.0, 0.0], [3.0, 3.0], [0.0, 3.0]])
        result = resample_closed(square, 48)
        self.assertEqual(result.shape, (48, 2))
        steps = np.linalg.norm(np.roll(result, -1, axis=0) - result, axis=1)
        self.assertLess(float(np.max(steps)), 0.4)
        self.assertGreater(float(np.min(steps)), 0.1)


if __name__ == "__main__":
    unittest.main()
