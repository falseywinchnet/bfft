from __future__ import annotations

import sys
from pathlib import Path
import unittest


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from portsmouth_engine import EikonalMidpointEngine  # noqa: E402
from structural_fusion import (  # noqa: E402
    field_mean_mask,
    ordered_top_band_fusion,
    register_stems,
)


class StructuralFusionTests(unittest.TestCase):
    def test_lowercase_m_registers_three_stems_and_stays_connected(self):
        engine = EikonalMidpointEngine(pixels_per_unit=0.25)
        fields = [
            engine.source_field(source, "m")
            for source in engine.active_sources("m")
        ]
        registered, stems, _ = register_stems(engine, fields)
        self.assertEqual(len(stems), 3)
        _raw, mask, _level = field_mean_mask(engine, registered)
        ordered, columns = ordered_top_band_fusion(engine, registered, mask)
        self.assertGreater(columns, 0)
        self.assertEqual(engine.topology(ordered)["components"], 1)


if __name__ == "__main__":
    unittest.main()
