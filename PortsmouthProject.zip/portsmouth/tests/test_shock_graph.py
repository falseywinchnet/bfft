from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from shock_graph import extract  # noqa: E402


class ShockGraphTests(unittest.TestCase):
    def test_rectangle_reduces_to_connected_centerline(self):
        mask = np.zeros((60, 80), dtype=bool)
        mask[10:50, 20:60] = True
        graph = extract(mask)
        self.assertTrue(np.any(graph.skeleton))
        self.assertTrue(np.all(graph.radius[~graph.skeleton] == 0))
        self.assertGreater(np.max(graph.radius), 0)


if __name__ == "__main__":
    unittest.main()
