from __future__ import annotations

import sys
from pathlib import Path
import unittest

import numpy as np


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from transport_barycenter import free_support_barycenter  # noqa: E402


class TransportBarycenterTests(unittest.TestCase):
    def test_translation_midpoint_and_marginals(self):
        left = np.array([[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
        right = left + np.array([2.0, 0.0])
        mass = np.full(4, 0.25)
        result = free_support_barycenter(
            [left, right], [mass, mass],
            epsilon=0.005, scale=1.0, maximum_iterations=20,
        )
        self.assertAlmostEqual(float(np.mean(result.support[:, 0])), 1.5, places=2)
        for plan in result.plans:
            np.testing.assert_allclose(plan.sum(axis=1), result.support_mass, atol=1e-9)
            np.testing.assert_allclose(plan.sum(axis=0), mass, atol=1e-9)


if __name__ == "__main__":
    unittest.main()
