from __future__ import annotations

import sys
from pathlib import Path
import unittest


SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))

from portsmouth_engine import EikonalMidpointEngine  # noqa: E402
from vectorize import contours_from_midpoint  # noqa: E402


class VectorizeTests(unittest.TestCase):
    def test_m_produces_closed_outline_data(self):
        engine = EikonalMidpointEngine(pixels_per_unit=0.25)
        result = engine.midpoint("m")
        contours = contours_from_midpoint(engine, result, tolerance=3.0)
        self.assertGreaterEqual(len(contours), 1)
        self.assertTrue(all(len(contour) >= 3 for contour in contours))


if __name__ == "__main__":
    unittest.main()
