import json
import unittest

from fontTools.ttLib import TTFont

from build_first_ttf import geometry_for
from portsmouth_engine import PROJECT


class ConstrainedDecisionTests(unittest.TestCase):
    def test_non_makima_regular_has_an_independent_family_identity(self):
        font = TTFont(PROJECT / "build" / "Portsmouth-Regular-1.0.ttf")
        try:
            self.assertEqual(font["name"].getDebugName(1), "Portsmouth Regular")
            self.assertEqual(font["name"].getDebugName(2), "Regular")
            self.assertEqual(font["name"].getDebugName(4), "Portsmouth Regular")
            self.assertEqual(font["name"].getDebugName(6), "PortsmouthRegular-Regular")
            self.assertEqual(font["name"].getDebugName(16), "Portsmouth Regular")
            self.assertEqual(font["name"].getDebugName(17), "Regular")
            self.assertNotEqual(font["name"].getDebugName(1), "Portsmouth")
        finally:
            font.close()

    def test_base_preserving_repairs_and_component_weights(self):
        repairs = json.loads(
            (PROJECT / "reports" / "extended-body-repairs.json").read_text()
        )
        self.assertAlmostEqual(
            repairs["aogonek"]["baseInkWidth"],
            repairs["aogonek"]["outputInkWidth"],
            delta=0.25,
        )
        self.assertAlmostEqual(
            repairs["uogonek"]["baseInkWidth"],
            repairs["uogonek"]["outputInkWidth"],
            delta=0.25,
        )
        self.assertEqual(
            repairs["gcedilla"]["method"],
            "accepted_g_plus_rotated_scaled_comma_above",
        )
        bold = json.loads((PROJECT / "reports" / "family-bold-1.0.json").read_text())
        glyphs = {entry["codepoint"]: entry for entry in bold["glyphs"]}
        for codepoint in ("U+0102", "U+0123"):
            transform = glyphs[codepoint]["transform"]
            self.assertEqual(transform["appliedRadius"], 22.0)
            self.assertTrue(transform["componentWiseDiacriticWeighting"])
        for codepoint in ("U+0105", "U+0173"):
            self.assertTrue(
                glyphs[codepoint]["transform"]["componentWiseAttachedMarkWeighting"]
            )

    def test_eastern_latin_extensions_have_parent_support(self):
        report = json.loads(
            (PROJECT / "reports" / "eastern-latin-extensions.json").read_text()
        )
        self.assertEqual(report["count"], 20)
        self.assertTrue(report["rawSupportAtLeastThree"])
        self.assertTrue(report["routedSupportAtLeastTwo"])

    def test_punctuation_system_is_direct_and_featureless(self):
        report = json.loads(
            (PROJECT / "reports" / "punctuation-system-promotion.json").read_text()
        )
        semicolon = report["semicolon"]
        self.assertAlmostEqual(
            semicolon["exactMidpointTarget"],
            0.5 * (semicolon["commaDotBoundsCenter"] + semicolon["colonLowerDotBoundsCenter"]),
        )
        self.assertAlmostEqual(
            report["hyphen"]["formerHyphenCenter"] + report["hyphen"]["verticalShift"],
            report["hyphen"]["plusCrossbarCenter"],
        )
        self.assertFalse(report["thoughtBreak"]["openTypeSubstitution"])
        required = {0x2014, 0x2018, 0x2019, 0x201C, 0x201D}
        for path in (PROJECT / "build/family").glob("*.ttf"):
            font = TTFont(path)
            self.assertTrue(required.issubset(font.getBestCmap()))
            self.assertFalse(any(tag in font for tag in ("GSUB", "GPOS", "kern")))
            font.close()

    def test_at_uses_directed_structure_and_proportion_roles(self):
        report = json.loads(
            (PROJECT / "reports" / "multicontour-trace-0040.json").read_text()
        )
        self.assertEqual(
            report["structureSources"],
            ["AnnotationMono-VF.ttf", "routed-gothic.ttf"],
        )
        self.assertEqual(report["proportionReference"], "ComicShannsMono-Regular.ttf")
        self.assertEqual(report["outputTopology"], {"components": 1, "holes": 1})

    def test_f_event_redraw_is_promoted_with_baseline_retained(self):
        report = json.loads(
            (PROJECT / "reports" / "boundary-trace-0066.json").read_text()
        )
        self.assertEqual(report["status"], "experimental_promoted_event_redraw")
        self.assertTrue((PROJECT / report["baselineGeometry"]).exists())
        self.assertTrue((PROJECT / report["baselineReport"]).exists())

    def test_a_and_q_use_the_approved_construction_family(self):
        expected = [
            "ComicShannsMono-Regular.ttf",
            "SyneMono-Regular.ttf",
            "routed-gothic.ttf",
        ]
        for character in "aq":
            report = json.loads(
                (PROJECT / "reports" / f"multicontour-trace-{ord(character):04x}.json").read_text()
            )
            self.assertEqual(report["sources"], expected)
            self.assertAlmostEqual(report["equalSourceWeight"], 1.0 / 3.0)
            self.assertEqual(report["outputTopology"], {"components": 1, "holes": 1})
            self.assertTrue((PROJECT / report["baselineGeometry"]).exists())

    def test_ae_uses_explicit_two_counter_ligature(self):
        report = json.loads(
            (PROJECT / "reports" / "multicontour-trace-00e6.json").read_text()
        )
        self.assertEqual(report["status"], "experimental_promoted_explicit_ligature")
        self.assertEqual(report["halfCenterSeparation"], 145.0)
        self.assertEqual(report["outputTopology"], {"components": 1, "holes": 2})
        self.assertTrue((PROJECT / report["baselineGeometry"]).exists())

    def test_rejected_majority_glyphs_do_not_enter_production(self):
        self.assertIsNone(geometry_for(ord("ß")))
        self.assertIsNone(geometry_for(ord("ð")))
        self.assertIsNotNone(geometry_for(ord("ø")))

    def test_terminal_repairs_are_promoted(self):
        expected = {
            "J": ("width-continuous", "experimental_promoted_width_continuity_repair"),
            "1": ("360", "experimental_promoted_terminal_repair"),
        }
        for character, (candidate, status) in expected.items():
            prefix = "boundary-trace" if character == "J" else "multicontour-trace"
            report = json.loads(
                (PROJECT / "reports" / f"{prefix}-{ord(character):04x}.json").read_text()
            )
            self.assertEqual(report["status"], status)
            self.assertEqual(report["selectedCandidate"], candidate)
            self.assertTrue((PROJECT / report["baselineGeometry"]).exists())

    def test_lower_web_symbol_compositions_are_promoted(self):
        for character in "©ª\u00ad®¶º½¾":
            report = json.loads(
                (PROJECT / "reports" / f"multicontour-trace-{ord(character):04x}.json").read_text()
            )
            self.assertEqual(report["status"], "experimental_promoted_web_symbol_composition")
            self.assertIsNotNone(geometry_for(ord(character)))

    def test_makima_q2_is_isolated_and_topology_audited(self):
        report = json.loads(
            (PROJECT / "reports" / "quadratic-experiment-0.017-makima-q2.json").read_text()
        )
        audit = json.loads((PROJECT / "reports" / "makima-quadratic-audit.json").read_text())
        self.assertEqual(report["familyIsolation"], "Portsmouth Makima Quadratic Test")
        self.assertEqual(report["sourceVersion"], "0.017")
        self.assertEqual(report["makimaGlyphs"], 186)
        self.assertEqual([value["codepoint"] for value in report["polygonalFallbacks"]], ["U+00BF"])
        self.assertLessEqual(report["maximumMasterError"], 2.5)
        self.assertLessEqual(report["maximumCubicToQuadraticError"], 1.8)
        self.assertTrue(audit["passed"])

    def test_canonical_family_and_575_mono_pass_audit(self):
        build = json.loads((PROJECT / "reports" / "family-build-1.0.json").read_text())
        audit = json.loads((PROJECT / "reports" / "family-audit-1.0.json").read_text())
        self.assertEqual(build["monoAdvance"], 575)
        self.assertEqual(build["regularRequestedErosionRadius"], 13.875)
        self.assertEqual(
            set(build["faces"]),
            {"regular", "light", "italic", "bold", "bold_italic"},
        )
        self.assertEqual(audit["monoAdvanceWidths"], [575])
        self.assertEqual(build["italicAngleDegrees"], 13.0)
        self.assertEqual(audit["italicAngleDegrees"], 13.0)
        self.assertEqual(audit["encodedCharactersPerFace"], 330)
        self.assertEqual(audit["collectionFaces"], 5)
        self.assertEqual(build["standaloneMono"], "build/mono/PortsmouthMono.ttf")
        self.assertTrue(audit["passed"])

        spacing = json.loads(
            (PROJECT / "reports" / "spacing-portfolio-audit-1.0.json").read_text()
        )
        self.assertEqual(spacing["lowercasePairTarget"], 140.0)
        self.assertEqual(spacing["mixedCasePairTarget"], 142.5)
        self.assertEqual(spacing["uppercasePairTarget"], 145.0)
        self.assertTrue(spacing["passed"])

        mono = TTFont(PROJECT / "build" / "mono" / "PortsmouthMono.ttf")
        regular = TTFont(PROJECT / "build" / "family" / "Portsmouth.ttf")
        try:
            self.assertEqual(mono["name"].getDebugName(1), "Portsmouth Mono")
            self.assertEqual(mono["name"].getDebugName(16), "Portsmouth Mono")
            self.assertEqual(mono["name"].getDebugName(21), "Portsmouth Mono")
            self.assertEqual(mono["name"].getDebugName(6), "PortsmouthMono-Regular")
            self.assertNotEqual(
                mono["name"].getDebugName(1), regular["name"].getDebugName(1)
            )
            self.assertNotEqual(
                mono["name"].getDebugName(6), regular["name"].getDebugName(6)
            )
        finally:
            mono.close()
            regular.close()

    def test_lowercase_r_spacing_correction_is_inherited(self):
        report = json.loads(
            (PROJECT / "reports" / "boundary-trace-0072.json").read_text()
        )
        derived = json.loads(
            (PROJECT / "reports" / "multicontour-trace-0157.json").read_text()
        )
        self.assertEqual(report["sidebearingReductionPerSide"], 14.0)
        self.assertAlmostEqual(derived["targetAdvance"], report["targetAdvance"])
        self.assertEqual(derived["metricInheritance"], "corrected lowercase r advance")

    def test_extended_coverage_is_promoted_conservatively(self):
        audit = json.loads(
            (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
        )
        self.assertEqual(audit["productionCharacters"], 38)
        self.assertEqual(audit["compatibleCandidates"], 78)
        self.assertEqual(audit["topologyConflicts"], 20)


if __name__ == "__main__":
    unittest.main()
