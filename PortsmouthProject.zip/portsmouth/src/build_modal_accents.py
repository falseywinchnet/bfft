#!/usr/bin/env python3
"""Resolve Portsmouth's Latin-1 lowercase accents with modal detached topology."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import (
    BoundaryCloud,
    annealed_boundary_barycenter,
    rasterize_contour_complex,
    resample_closed,
)
from outline_geometry import ContourLoop, normalized_source_contours, union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask
from vectorize import signed_area


CHARACTERS = "àáâãåèéêñõ"
BASE = {
    "à": "a", "á": "a", "â": "a", "ã": "a", "å": "a",
    "è": "e", "é": "e", "ê": "e", "ñ": "n", "õ": "o",
}


def geometry_for(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            return path
    raise FileNotFoundError(character)


def archived_contours(character: str) -> list[tuple[str, np.ndarray]]:
    with np.load(geometry_for(character), allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key].astype(float))
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def contains(points: np.ndarray, point: np.ndarray) -> bool:
    x, y = map(float, point)
    x0, y0 = points[:, 0], points[:, 1]
    x1, y1 = np.roll(x0, -1), np.roll(y0, -1)
    denominator = np.where(np.abs(y1 - y0) > 1e-12, y1 - y0, 1.0)
    crosses = ((y0 > y) != (y1 > y)) & (
        x < (x1 - x0) * (y - y0) / denominator + x0
    )
    return bool(np.count_nonzero(crosses) % 2)


def clip_above(points: np.ndarray, cut: float) -> np.ndarray:
    """Clip a closed polygon to y >= cut, closing a joined Teletext mark."""
    output = []
    previous = points[-1]
    previous_inside = previous[1] >= cut
    for current in points:
        current_inside = current[1] >= cut
        if current_inside != previous_inside:
            fraction = (cut - previous[1]) / (current[1] - previous[1])
            output.append(previous + fraction * (current - previous))
        if current_inside:
            output.append(current)
        previous, previous_inside = current, current_inside
    result = np.asarray(output, dtype=float)
    if len(result) < 3:
        raise ValueError("Horizontal mark extraction collapsed")
    if signed_area(result) < 0.0:
        result = result[::-1]
    return result


def loop(points: np.ndarray, role: str = "outer") -> ContourLoop:
    points = np.asarray(points, dtype=float)
    if signed_area(points) < 0.0:
        points = points[::-1]
    return ContourLoop(
        points=points,
        role=role,
        area=abs(float(signed_area(points))),
        centroid=np.mean(points, axis=0),
    )


def mark_from_detached(complex_) -> tuple[ContourLoop, list[ContourLoop]]:
    body = max(complex_.outer, key=lambda value: value.area)
    candidates = [value for value in complex_.outer if value is not body]
    if not candidates:
        raise ValueError("No detached mark")
    mark = max(candidates, key=lambda value: value.centroid[1])
    holes = [value for value in complex_.holes if contains(mark.points, value.centroid)]
    return mark, holes


def fit_to_bbox(points: np.ndarray, target: tuple[float, float, float, float]) -> np.ndarray:
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    tx0, ty0, tx1, ty1 = target
    scale = np.array([
        (tx1 - tx0) / max(maximum[0] - minimum[0], 1e-9),
        (ty1 - ty0) / max(maximum[1] - minimum[1], 1e-9),
    ])
    return (points - minimum) * scale + np.array([tx0, ty0])


def fuse_loops(groups: list[ContourLoop], sources: list[str]) -> tuple[np.ndarray, dict]:
    clouds = []
    for source, value in zip(sources, groups):
        points = resample_closed(value.points, 10240)
        clouds.append(BoundaryCloud(source=source, points=points, median_anchor=points))
    return annealed_boundary_barycenter(clouds)


def source_marks(engine, character: str, fields, complexes):
    detached = []
    gap_midpoints = []
    for complex_ in complexes:
        if len(complex_.outer) >= 2:
            mark, _ = mark_from_detached(complex_)
            body = max(complex_.outer, key=lambda value: value.area)
            gap_midpoints.append(0.5 * (
                float(np.max(body.points[:, 1])) + float(np.min(mark.points[:, 1]))
            ))
    if not gap_midpoints:
        raise ValueError(f"No detached reference mark for {character!r}")
    cut = float(np.median(gap_midpoints))

    marks: list[tuple[ContourLoop, list[ContourLoop]] | None] = []
    for field, complex_ in zip(fields, complexes):
        if len(complex_.outer) >= 2:
            marks.append(mark_from_detached(complex_))
            continue
        if character == "õ" and field.source.filename == "routed-gothic.ttf":
            marks.append(None)
            continue
        body = max(complex_.outer, key=lambda value: value.area)
        extracted = loop(clip_above(body.points, cut))
        extracted_holes = []
        for hole in complex_.holes:
            if float(np.max(hole.points[:, 1])) > cut:
                clipped = clip_above(hole.points, cut)
                extracted_holes.append(loop(clipped, "hole"))
        marks.append((extracted, extracted_holes))

    present = [value[0] for value in marks if value is not None]
    boxes = [(
        float(np.min(value.points[:, 0])), float(np.min(value.points[:, 1])),
        float(np.max(value.points[:, 0])), float(np.max(value.points[:, 1])),
    ) for value in present]
    target = tuple(float(np.median([box[index] for box in boxes])) for index in range(4))
    for index, value in enumerate(marks):
        if value is not None:
            continue
        source = fields[index].source
        tilde_raw = normalized_source_contours(engine, "~")[source.filename]
        tilde = max(
            union_contour_complex(tilde_raw, pixels_per_unit=5.0).outer,
            key=lambda item: item.area,
        )
        marks[index] = (loop(fit_to_bbox(tilde.points, target)), [])
    return marks, cut


def pseudo_ring_counter(outer: ContourLoop, references) -> ContourLoop:
    ratios = []
    offsets = []
    for reference_outer, reference_holes in references:
        if not reference_holes:
            continue
        hole = max(reference_holes, key=lambda value: value.area)
        outer_min, outer_max = np.min(reference_outer.points, axis=0), np.max(reference_outer.points, axis=0)
        hole_min, hole_max = np.min(hole.points, axis=0), np.max(hole.points, axis=0)
        ratios.append((hole_max - hole_min) / np.maximum(outer_max - outer_min, 1e-9))
        offsets.append(np.mean(hole.points, axis=0) - np.mean(reference_outer.points, axis=0))
    ratio = np.median(np.asarray(ratios), axis=0)
    offset = np.median(np.asarray(offsets), axis=0)
    center = np.mean(outer.points, axis=0) + offset
    return loop((outer.points - np.mean(outer.points, axis=0)) * ratio + center, "hole")


def render(engine, character: str, fields, output_contours, output):
    entries = [(field.source.family, field.mask) for field in fields]
    entries.append(("Portsmouth detached modal accent", rasterize_contour_complex(engine, output_contours)))
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — modal detached accent", fill="#111", font=title)
    draw.text((40, 78), "four equal geometric contributors · user-approved detached topology", fill="#575149", font=small)
    for index, (name, mask) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_w, 120 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        image = _render_mask(mask, (tile_w - 70, tile_h - 105))
        canvas.paste(image, (x0 + (tile_w - 20 - image.width) // 2, y0 + 63 + (tile_h - 105 - image.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), "fused output" if index == len(entries) - 1 else "normalized source", fill="#655f57", font=small)
    canvas.save(output)


def build_character(engine: EikonalMidpointEngine, character: str) -> dict:
    fields = [engine.source_field(source, character) for source in engine.active_sources(character)]
    raw = normalized_source_contours(engine, character)
    complexes = [union_contour_complex(raw[field.source.filename], pixels_per_unit=5.0) for field in fields]
    marks, cut = source_marks(engine, character, fields, complexes)
    outer_group = [value[0] for value in marks]
    accent_outer, outer_detail = fuse_loops(outer_group, [field.source.filename for field in fields])
    accent_holes = []
    hole_detail = None
    if character == "å":
        hole_group = []
        for outer, holes in marks:
            hole_group.append(max(holes, key=lambda value: value.area) if holes else pseudo_ring_counter(outer, marks))
        counter, hole_detail = fuse_loops(hole_group, [field.source.filename for field in fields])
        accent_holes.append(counter)

    base_contours = archived_contours(BASE[character])
    base_top = max(float(np.max(points[:, 1])) for role, points in base_contours if role == "outer")
    accent_bottom = float(np.min(accent_outer[:, 1]))
    minimum_gap = 24.0
    vertical_adjustment = max(0.0, base_top + minimum_gap - accent_bottom)
    accent_outer[:, 1] += vertical_adjustment
    for counter in accent_holes:
        counter[:, 1] += vertical_adjustment
    output_contours = base_contours + [("outer", accent_outer)] + [("hole", value) for value in accent_holes]
    mask = rasterize_contour_complex(engine, output_contours)
    expected = {"components": 2, "holes": sum(role == "hole" for role, _ in base_contours) + len(accent_holes)}
    actual = engine.topology(mask)
    if actual != expected:
        raise ValueError(f"{character} modal compound topology {actual}, expected {expected}")

    stem = f"{ord(character):04x}"
    geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
    arrays = {
        f"{role}_{index}": resample_closed(points, 10240).astype(np.float32)
        for index, (role, points) in enumerate(output_contours)
    }
    arrays["character"] = np.asarray(character)
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(geometry, **arrays)
    report = {
        "character": character,
        "status": "experimental_user_approved_modal_topology",
        "designConstraint": "detached lowercase accent",
        "pipeline": [
            "user_approved_modal_detached_topology",
            "archived_fused_base_geometry",
            "four_source_accent_extraction_including_bedstead",
            "equal_weight_ordered_accent_trace",
            "minimum_optical_separation",
        ],
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 0.25,
        "baseCharacter": BASE[character],
        "sourceSeparationCut": cut,
        "minimumAccentGap": minimum_gap,
        "accentVerticalAdjustment": vertical_adjustment,
        "pointsPerContour": 10240,
        "expectedTopology": expected,
        "outputTopology": actual,
        "outerAnnealing": outer_detail,
        "counterAnnealing": hole_detail,
        "geometryArtifact": str(geometry.relative_to(PROJECT)),
        "visualReview": None,
    }
    report_path = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    specimen = PROJECT / "specimens" / f"multicontour-trace-{stem}.png"
    render(engine, character, fields, output_contours, specimen)
    return report


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    reports = [build_character(engine, character) for character in CHARACTERS]
    print(json.dumps({
        "characters": [report["character"] for report in reports],
        "status": "built",
        "equalSourceWeight": 0.25,
    }, indent=2))


if __name__ == "__main__":
    main()
