#!/usr/bin/env python3
"""Trace Portsmouth m directly from annealed ordered boundary clouds."""

from __future__ import annotations

from dataclasses import replace
import argparse
import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import (
    annealed_boundary_barycenter,
    boundary_cloud,
    rasterize_contour,
)
from medial_transport import (
    intrinsic_graph_barycenter,
    mask_statistics,
    sample_medial_structure,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from outline_geometry import normalized_source_contours, union_outer_contour
from structural_fusion import detect_stem_axes
from transport_barycenter import free_support_barycenter


def run_character(
    engine: EikonalMidpointEngine,
    character: str,
    points_per_contour: int,
) -> None:
    fields = [
        engine.source_field(source, character)
        for source in engine.active_sources(character)
    ]
    measures = [sample_medial_structure(engine, field, 128) for field in fields]
    initial = free_support_barycenter(
        [measure.support for measure in measures],
        [measure.mass for measure in measures],
        scale=np.array([500.0, 500.0, 60.0]),
    )
    median, median_info = intrinsic_graph_barycenter(measures, initial)
    vector_contours = normalized_source_contours(engine, character)
    union_contours = {
        filename: union_outer_contour(contours, pixels_per_unit=5.0)
        for filename, contours in vector_contours.items()
    }
    union_top = {
        filename: float(np.max(contour[:, 1]))
        for filename, contour in union_contours.items()
    }
    exact_target_top = float(np.median(list(union_top.values())))
    for filename, contour in union_contours.items():
        contour[:, 1] *= exact_target_top / union_top[filename]
    clouds = [boundary_cloud(
        engine, field, measure, median, plan,
        count=points_per_contour,
        source_contour=union_contours[field.source.filename],
    ) for field, measure, plan in zip(fields, measures, median.plans)]
    contour, annealing = annealed_boundary_barycenter(clouds)
    mask = rasterize_contour(engine, contour)
    output_field = replace(fields[0], mask=mask, sdf=engine.signed_distance(mask))
    stems = detect_stem_axes(engine, output_field) if character == "m" else np.array([])
    report = {
        "character": character,
        "status": (
            "needs_design_review" if character in {
                "f", "K", "r", "w", "G", "J", "M", "W"
            }
            else "experimental_direct_trace"
        ),
        "pipeline": [
            "height_normalized_ordered_boundary_clouds",
            "median_skeleton_anchored_monotone_transport",
            "equal_weight_boundary_barycenter_annealing",
            "direct_closed_contour_trace",
        ],
        "sources": [field.source.filename for field in fields],
        "sourceInkTops": {
            field.source.filename: float(np.max(
                union_contours[field.source.filename][:, 1]
            )) for field in fields
        },
        "exactTargetInkTop": exact_target_top,
        "equalSourceWeight": 1.0 / len(fields),
        "pointsPerSourceContour": points_per_contour,
        "sourceBoundaryExtractionPixelsPerUnit": 5.0,
        "medianSkeleton": median_info,
        "annealing": annealing,
        "geometry": mask_statistics(mask),
        "skeletonInflationUsed": False,
        "densityFloodUsed": False,
    }
    if character == "K":
        report["visualReview"] = "user identified the fused diagonal junction and leg balance for redraw"
    if character == "m":
        report["detectedLowerStemCount"] = int(len(stems))
        report["detectedLowerStemAxes"] = list(map(float, stems))
    stem = f"{ord(character):04x}"
    geometry_directory = PROJECT / "geometry"
    geometry_directory.mkdir(exist_ok=True)
    geometry_output = geometry_directory / f"boundary-trace-{stem}.npz"
    np.savez_compressed(
        geometry_output,
        contour=contour.astype(np.float32),
        character=np.asarray(character),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    report["geometryArtifact"] = str(geometry_output.relative_to(PROJECT))
    (PROJECT / "reports" / f"boundary-trace-{stem}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )

    entries = [(field.source.family, field.mask, None) for field in fields]
    entries.append(("Portsmouth direct point-cloud trace", mask, contour))
    tile_w, tile_h, columns = 390, 410, 3
    rows = 2
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 14)
    draw.text((40, 28), f"Portsmouth {character} — direct ordered point-cloud trace", fill="#111", font=title)
    draw.text(
        (40, 78),
        f"{points_per_contour:,} boundary points/source · 5 samples/unit extraction · no skeleton inflation or density flood",
        fill="#575149", font=small,
    )
    for index, (name, source_mask, points) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10,
            fill="#fffdf8", outline="#d0cabf", width=2,
        )
        ys, xs = np.nonzero(source_mask)
        left, right = max(0, xs.min() - 12), min(source_mask.shape[1], xs.max() + 13)
        top, bottom = max(0, ys.min() - 12), min(source_mask.shape[0], ys.max() + 13)
        crop = source_mask[top:bottom, left:right]
        layer = np.full((*crop.shape, 3), 255, dtype=np.uint8)
        layer[crop] = (24, 24, 22)
        glyph = Image.fromarray(layer)
        glyph.thumbnail((tile_w - 70, tile_h - 105), Image.Resampling.LANCZOS)
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 63 + (tile_h - 105 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        if points is not None:
            scale = glyph.width / max(crop.shape[1], 1)
            for x, y in points[::4]:
                column = (x - engine.x_min) * engine.pixels_per_unit - 0.5
                row_pixel = (engine.y_max - y) * engine.pixels_per_unit - 0.5
                px = gx + (column - left) * scale
                py = gy + (row_pixel - top) * scale
                draw.ellipse((px - 1.2, py - 1.2, px + 1.2, py + 1.2), fill="#d34e38")
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        subtitle = "red = traced ordered cloud" if points is not None else "height-normalized source"
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    output = PROJECT / "specimens" / f"boundary-trace-{stem}.png"
    canvas.save(output)
    print(json.dumps(report, indent=2))
    print(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("glyphs", nargs="*", default=list("mnhruvwxyszcs"))
    parser.add_argument("--points", type=int, default=10240)
    arguments = parser.parse_args()
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    for character in arguments.glyphs:
        if len(character) != 1:
            raise SystemExit(f"Expected one character, got {character!r}")
        run_character(engine, character, arguments.points)


if __name__ == "__main__":
    main()
