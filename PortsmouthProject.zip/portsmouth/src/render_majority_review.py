#!/usr/bin/env python3
"""Render majority-source additions together for visual acceptance."""

from __future__ import annotations

import json
import math
import unicodedata

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


CHARACTERS = "¤¦§¬±²³µ·¹ÐØðø"


def contours(character: str):
    stem = f"{ord(character):04x}"
    with np.load(PROJECT / "geometry" / f"multicontour-trace-{stem}.npz", allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    columns, tile_w, tile_h = 5, 330, 365
    rows = math.ceil(len(CHARACTERS) / columns)
    canvas = Image.new("RGB", (70 + columns * tile_w, 145 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 13)
    draw.text((35, 26), "Portsmouth — majority-source additions", fill="#111", font=title)
    draw.text((35, 76), "topology-passing candidates · rendered review remains authoritative", fill="#5e5850", font=small)
    for index, character in enumerate(CHARACTERS):
        column, row = index % columns, index // columns
        x0, y0 = 35 + column * tile_w, 115 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10, fill="#fffdf8", outline="#cec7bb", width=2)
        stem = f"{ord(character):04x}"
        report = json.loads((PROJECT / "reports" / f"multicontour-trace-{stem}.json").read_text())
        mask = rasterize_contour_complex(engine, contours(character))
        image = _render_mask(mask, (tile_w - 80, tile_h - 105))
        canvas.paste(image, (x0 + (tile_w - 20 - image.width) // 2, y0 + 66 + (tile_h - 105 - image.height) // 2))
        draw.text((x0 + 15, y0 + 14), f"{character}  U+{ord(character):04X}", fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 40), unicodedata.name(character), fill="#655f57", font=small)
        draw.text((x0 + 15, y0 + tile_h - 51), f"{len(report['sources'])} equal sources · {report['outputTopology']}", fill="#655f57", font=small)
    output = PROJECT / "specimens" / "majority-source-review.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
