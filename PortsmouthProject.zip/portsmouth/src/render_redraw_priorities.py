#!/usr/bin/env python3
"""Render the four user-selected Portsmouth redraw priorities."""

from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


CHARACTERS = "afKq"


def geometry_for(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            return path
    raise FileNotFoundError(character)


def fused_mask(engine, character):
    with np.load(geometry_for(character), allow_pickle=False) as archive:
        contours = [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]
    return rasterize_contour_complex(engine, contours)


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    columns, tile_width, row_height = 5, 250, 310
    canvas = Image.new("RGB", (90 + columns * tile_width, 170 + len(CHARACTERS) * row_height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 32)
    label = ImageFont.truetype(ui, 16)
    small = ImageFont.truetype(ui, 13)
    draw.text((35, 24), "Portsmouth · first TTF redraw priorities", fill="#111", font=title)
    draw.text((35, 72), "User-selected: a · f · K · q", fill="#5c554c", font=small)
    headings = ["Annotation Mono", "Comic Shanns", "case source", "Routed Gothic", "Portsmouth"]
    for column, heading in enumerate(headings):
        draw.text((90 + column * tile_width, 125), heading, fill="#282522", font=label)
    for row, character in enumerate(CHARACTERS):
        fields = [engine.source_field(source, character) for source in engine.active_sources(character)]
        masks = [field.mask for field in fields] + [fused_mask(engine, character)]
        y0 = 160 + row * row_height
        draw.line((25, y0, canvas.width - 25, y0), fill="#cfc7bb", width=1)
        draw.text((35, y0 + 20), repr(character), fill="#111", font=title)
        for column, mask in enumerate(masks):
            image = _render_mask(mask, (175, 235))
            x = 90 + column * tile_width + (175 - image.width) // 2
            y = y0 + 50 + (235 - image.height) // 2
            canvas.paste(image, (x, y))
    output = PROJECT / "specimens" / "redraw-priorities-afKq.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
