#!/usr/bin/env python3
"""Measure conventional italic angles in fonts installed on this Mac."""

from __future__ import annotations

import json
import statistics
from collections import Counter
from pathlib import Path

from fontTools.ttLib import TTCollection, TTFont

from portsmouth_engine import PROJECT


ROOTS = (
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
    Path.home() / "Library/Fonts",
)


def main() -> None:
    faces = []
    for root in ROOTS:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.suffix.lower() not in {".ttf", ".otf", ".ttc"}:
                continue
            try:
                if path.suffix.lower() == ".ttc":
                    collection = TTCollection(path, lazy=True)
                    fonts = collection.fonts
                else:
                    collection = None
                    fonts = [TTFont(path, lazy=True)]
                for index, font in enumerate(fonts):
                    family = font["name"].getDebugName(1) or ""
                    style = font["name"].getDebugName(2) or ""
                    full_name = font["name"].getDebugName(4) or ""
                    angle = float(getattr(font.get("post"), "italicAngle", 0.0) or 0.0)
                    descriptor = f"{style} {full_name}".lower()
                    magnitude = abs(angle)
                    if angle and ("italic" in descriptor or "oblique" in descriptor):
                        faces.append({
                            "family": family,
                            "style": style,
                            "angle": angle,
                            "magnitude": magnitude,
                            "font": str(path),
                            "collectionIndex": index,
                        })
                for font in fonts:
                    font.close()
                if collection is not None:
                    collection.close()
            except Exception:
                continue
    conventional = sorted(
        face["magnitude"] for face in faces if 5.0 <= face["magnitude"] <= 25.0
    )
    common = Counter(round(value, 2) for value in conventional)

    def percentile(fraction: float) -> float:
        return conventional[round((len(conventional) - 1) * fraction)]

    report = {
        "method": "nonzero post.italicAngle on installed faces named Italic or Oblique",
        "conventionalBandDegrees": [5.0, 25.0],
        "matchingFaces": len(faces),
        "conventionalFaces": len(conventional),
        "medianDegrees": statistics.median(conventional),
        "percentilesDegrees": {
            "10": percentile(0.10),
            "25": percentile(0.25),
            "50": percentile(0.50),
            "75": percentile(0.75),
            "90": percentile(0.90),
        },
        "mostCommonDegrees": [
            {"angle": angle, "faces": count}
            for angle, count in common.most_common(20)
        ],
        "portsmouthChoiceDegrees": 13.0,
        "choiceRationale": (
            "midpoint between the installed-font median of 12 degrees and the "
            "CSS Fonts Level 4 omitted-angle oblique convention of 14 degrees"
        ),
        "cssReference": "https://www.w3.org/TR/css-fonts-4/#font-style-prop",
        "faces": sorted(faces, key=lambda face: (face["magnitude"], face["family"], face["style"])),
    }
    output = PROJECT / "reports" / "italic-angle-survey-0.101.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "faces"}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
