#!/usr/bin/env python3
"""Resolution-independent normalized source contours from font outlines."""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass

import numpy as np
import contourpy
from PIL import Image, ImageDraw
from fontTools.pens.basePen import BasePen
from fontTools.ttLib import TTFont

from portsmouth_engine import EikonalMidpointEngine, SourceFont, _linear_extrapolated_interp


@dataclass
class ContourLoop:
    points: np.ndarray
    role: str
    area: float
    centroid: np.ndarray


@dataclass
class ContourComplex:
    loops: list[ContourLoop]

    @property
    def outer(self) -> list[ContourLoop]:
        return [loop for loop in self.loops if loop.role == "outer"]

    @property
    def holes(self) -> list[ContourLoop]:
        return [loop for loop in self.loops if loop.role == "hole"]


class _FlattenPen(BasePen):
    def __init__(self, glyph_set, step: float):
        super().__init__(glyph_set)
        self.step = float(step)
        self.contours: list[np.ndarray] = []
        self.current: list[tuple[float, float]] = []

    def _moveTo(self, point):
        if self.current:
            self._finish()
        self.current = [tuple(point)]

    def _lineTo(self, point):
        self.current.append(tuple(point))

    def _curveToOne(self, point1, point2, point3):
        start = np.asarray(self.current[-1], dtype=float)
        p1, p2, p3 = map(lambda value: np.asarray(value, dtype=float), (point1, point2, point3))
        length = np.linalg.norm(p1 - start) + np.linalg.norm(p2 - p1) + np.linalg.norm(p3 - p2)
        count = max(2, int(np.ceil(length / self.step)))
        for t in np.linspace(0.0, 1.0, count + 1)[1:]:
            omt = 1.0 - t
            value = omt ** 3 * start + 3 * omt ** 2 * t * p1 + 3 * omt * t ** 2 * p2 + t ** 3 * p3
            self.current.append(tuple(value))

    def _qCurveToOne(self, point1, point2):
        start = np.asarray(self.current[-1], dtype=float)
        p1, p2 = map(lambda value: np.asarray(value, dtype=float), (point1, point2))
        length = np.linalg.norm(p1 - start) + np.linalg.norm(p2 - p1)
        count = max(2, int(np.ceil(length / self.step)))
        for t in np.linspace(0.0, 1.0, count + 1)[1:]:
            omt = 1.0 - t
            value = omt ** 2 * start + 2 * omt * t * p1 + t ** 2 * p2
            self.current.append(tuple(value))

    def _closePath(self):
        self._finish()

    def _endPath(self):
        self._finish()

    def _finish(self):
        if len(self.current) >= 3:
            self.contours.append(np.asarray(self.current, dtype=np.float64))
        self.current = []


def _anchors(engine: EikonalMidpointEngine, source: SourceFont, character: str):
    category = unicodedata.category(character)
    target = engine.target_landmarks
    original = source.landmarks
    if category == "Lu":
        return (
            np.array([original.baseline, original.capheight]),
            np.array([target.baseline, target.capheight]),
        )
    if category == "Ll":
        return (
            np.array([original.descender, original.baseline, original.xheight, original.ascender]),
            np.array([target.descender, target.baseline, target.xheight, target.ascender]),
        )
    return (
        np.array([original.descender, original.baseline, original.capheight]),
        np.array([target.descender, target.baseline, target.capheight]),
    )


def landmark_normalized_contours(
    engine: EikonalMidpointEngine,
    source: SourceFont,
    character: str,
    *,
    flatten_step: float = 0.55,
) -> list[np.ndarray]:
    font = TTFont(source.path, lazy=False)
    glyph_set = font.getGlyphSet()
    glyph_name = source.cmap[ord(character)]
    pen = _FlattenPen(glyph_set, flatten_step * source.upm / 1000.0)
    glyph_set[glyph_name].draw(pen)
    pen._finish()
    font.close()
    scale = 1000.0 / source.upm
    bounds = engine._normalized_bounds(source, character)
    center = 0.5 * (bounds[0] + bounds[2])
    source_anchor, target_anchor = _anchors(engine, source, character)
    result = []
    for contour in pen.contours:
        points = contour * scale
        points[:, 0] -= center
        points[:, 1] = _linear_extrapolated_interp(
            points[:, 1], source_anchor, target_anchor
        )
        result.append(points)
    return result


def normalized_source_contours(
    engine: EikonalMidpointEngine,
    character: str,
) -> dict[str, list[np.ndarray]]:
    return normalized_selected_source_contours(
        engine, character, engine.active_sources(character)
    )


def normalized_selected_source_contours(
    engine: EikonalMidpointEngine,
    character: str,
    sources,
) -> dict[str, list[np.ndarray]]:
    """Normalize an explicit glyph-specific source family at equal height."""
    raw = {
        source.filename: landmark_normalized_contours(engine, source, character)
        for source in sources
    }
    tops = [max(float(np.max(contour[:, 1])) for contour in contours) for contours in raw.values()]
    target_top = float(np.median(tops))
    result = {}
    for filename, contours in raw.items():
        source_top = max(float(np.max(contour[:, 1])) for contour in contours)
        scale = target_top / source_top
        normalized = [contour.copy() for contour in contours]
        for contour in normalized:
            contour[:, 1] *= scale
        result[filename] = normalized
    return result


def union_outer_contour(
    contours: list[np.ndarray],
    *,
    pixels_per_unit: float = 5.0,
    padding: float = 8.0,
) -> np.ndarray:
    """Union overlapping no-hole source contours on a glyph-local 10x grid."""
    minimum = np.min(np.vstack(contours), axis=0) - padding
    maximum = np.max(np.vstack(contours), axis=0) + padding
    width = int(np.ceil((maximum[0] - minimum[0]) * pixels_per_unit)) + 1
    height = int(np.ceil((maximum[1] - minimum[1]) * pixels_per_unit)) + 1
    image = Image.new("1", (width, height), 0)
    draw = ImageDraw.Draw(image)
    for contour in contours:
        points = [
            (
                float((x - minimum[0]) * pixels_per_unit),
                float((maximum[1] - y) * pixels_per_unit),
            )
            for x, y in contour
        ]
        draw.polygon(points, fill=1)
    mask = np.asarray(image, dtype=np.float64)
    x = minimum[0] + np.arange(width) / pixels_per_unit
    y = minimum[1] + np.arange(height) / pixels_per_unit
    generator = contourpy.contour_generator(x=x, y=y, z=mask[::-1])
    lines = [np.asarray(line) for line in generator.lines(0.5)]
    if not lines:
        raise ValueError("Vector contour union produced no boundary")
    from vectorize import signed_area
    return max(lines, key=lambda line: abs(signed_area(line)))


def union_contour_complex(
    contours: list[np.ndarray],
    *,
    pixels_per_unit: float = 5.0,
    padding: float = 8.0,
) -> ContourComplex:
    """Nonzero-winding union with every outer and hole boundary retained."""
    from vectorize import signed_area

    stacked = np.vstack(contours)
    minimum = np.min(stacked, axis=0) - padding
    maximum = np.max(stacked, axis=0) + padding
    width = int(np.ceil((maximum[0] - minimum[0]) * pixels_per_unit)) + 1
    height = int(np.ceil((maximum[1] - minimum[1]) * pixels_per_unit)) + 1
    winding = np.zeros((height, width), dtype=np.int16)
    for contour in contours:
        layer = Image.new("1", (width, height), 0)
        points = [
            (
                float((x - minimum[0]) * pixels_per_unit),
                float((maximum[1] - y) * pixels_per_unit),
            )
            for x, y in contour
        ]
        ImageDraw.Draw(layer).polygon(points, fill=1)
        sign = 1 if signed_area(contour) >= 0.0 else -1
        winding += sign * np.asarray(layer, dtype=np.int16)
    mask = winding != 0
    x = minimum[0] + np.arange(width) / pixels_per_unit
    y = minimum[1] + np.arange(height) / pixels_per_unit
    generator = contourpy.contour_generator(
        x=x, y=y, z=mask[::-1].astype(np.float64)
    )
    lines = [np.asarray(line) for line in generator.lines(0.5)]
    if not lines:
        raise ValueError("Vector contour union produced no boundary complex")
    areas = np.asarray([signed_area(line) for line in lines])
    outer_sign = 1.0 if areas[int(np.argmax(np.abs(areas)))] >= 0.0 else -1.0
    loops = []
    for line, area in zip(lines, areas):
        role = "outer" if area * outer_sign > 0.0 else "hole"
        points = line if signed_area(line) > 0.0 else line[::-1]
        loops.append(ContourLoop(
            points=points,
            role=role,
            area=abs(float(area)),
            centroid=np.mean(points, axis=0),
        ))
    return ContourComplex(loops=loops)
