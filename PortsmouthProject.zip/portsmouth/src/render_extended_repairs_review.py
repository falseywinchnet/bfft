#!/usr/bin/env python3
"""Render before/after review of ą, ģ, ų, and detached-accent weights."""

import tempfile
import zipfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import PROJECT


def main():
    canvas = Image.new("RGB", (2450, 1880), "#f2ede3")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 42)
    label = ImageFont.truetype(ui, 20)
    small = ImageFont.truetype(ui, 15)
    draw.text((65, 35), f"Portsmouth {FAMILY_VERSION} — base-preserving extended-letter repairs", font=title, fill="#171715")
    draw.text((68, 92), "Targets: ą body/ogonek · Latvian ģ comma above · ų ogonek · equal body weight with detached accents", font=label, fill="#625b52")
    text = "a ą    g ģ    u ų    A Ă    G Ğ    U Ŭ"

    with tempfile.TemporaryDirectory() as temporary:
        old = Path(temporary)
        with zipfile.ZipFile(PROJECT / "build/family/Portsmouth-Family-0.109.zip") as archive:
            for filename in ("Portsmouth.ttf", "Portsmouth-Bold.ttf", "PortsmouthMono.ttf"):
                archive.extract(filename, old)
        before = [
            ("0.109 REGULAR", old / "Portsmouth.ttf"),
            ("0.109 BOLD", old / "Portsmouth-Bold.ttf"),
            ("0.109 MONO", old / "PortsmouthMono.ttf"),
        ]
        after = [
            ("1.0 REGULAR", PROJECT / "build/family/Portsmouth.ttf"),
            ("1.0 LIGHT", PROJECT / "build/family/Portsmouth-Light.ttf"),
            ("1.0 ITALIC", PROJECT / "build/family/Portsmouth-Italic.ttf"),
            ("1.0 BOLD", PROJECT / "build/family/Portsmouth-Bold.ttf"),
            ("1.0 BOLD ITALIC", PROJECT / "build/family/Portsmouth-BoldItalic.ttf"),
            ("1.0 MONO", PROJECT / "build/mono/PortsmouthMono.ttf"),
        ]
        y = 165
        draw.text((70, y), "BEFORE", font=label, fill="#985848")
        y += 45
        for name, path in before:
            baseline = y + 125
            draw.text((75, y + 5), name, font=small, fill="#6a6258")
            draw.line((260, baseline, 2360, baseline), fill="#c9c0b3", width=1)
            draw.text((280, baseline), text, font=ImageFont.truetype(path, 92), fill="#171715", anchor="ls")
            y += 190
        draw.line((65, y, 2380, y), fill="#985848", width=2)
        y += 35
        draw.text((70, y), "AFTER · BODY AND MARK WEIGHTED INDEPENDENTLY", font=label, fill="#985848")
        y += 45
        for name, path in after:
            baseline = y + 105
            draw.text((75, y + 5), name, font=small, fill="#6a6258")
            draw.line((260, baseline, 2360, baseline), fill="#c9c0b3", width=1)
            draw.text((280, baseline), text, font=ImageFont.truetype(path, 82), fill="#171715", anchor="ls")
            y += 150
    draw.text((70, 1815), "The base body in every accented pair is now geometrically inherited, not independently fused.", font=label, fill="#625b52")
    output = PROJECT / "specimens" / f"Extended-Repairs-{FAMILY_VERSION}.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
