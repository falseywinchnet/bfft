#!/usr/bin/env python3
"""Fuse the topology-compatible post-Latin-1 majority candidate set."""

from __future__ import annotations

import contextlib
import argparse
import json
import os
import traceback

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import run_character


POINTS_PER_CONTOUR = 10240
PREFIX = "extended-majority-candidate"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument("--only-two-routed", action="store_true")
    parser.add_argument("--characters")
    arguments = parser.parse_args()
    if not 0 <= arguments.shard_index < arguments.shard_count:
        raise ValueError("shard-index must be within shard-count")
    audit = json.loads(
        (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
    )
    complete_set = [
        entry for entry in audit["entries"]
        if entry["compatiblePersistentTopology"] and not entry["production"]
    ]
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    if arguments.only_two_routed:
        complete_set = [
            entry for entry in complete_set
            if len(engine.active_sources(entry["character"])) == 2
        ]
    if arguments.characters:
        requested = set(arguments.characters)
        complete_set = [entry for entry in complete_set if entry["character"] in requested]
    candidates = complete_set[arguments.shard_index::arguments.shard_count]
    successes, failures = [], []
    for index, entry in enumerate(candidates, 1):
        character = entry["character"]
        sources = engine.active_sources(character)
        topologies = [
            engine.topology(engine.source_field(source, character).mask)
            for source in sources
        ]
        if len(sources) < 2 or any(value != topologies[0] for value in topologies[1:]):
            failures.append({
                "codepoint": entry["codepoint"],
                "character": character,
                "error": f"fewer than two compatible routed sources: {topologies}",
            })
            print(f"[{index:02d}/{len(candidates)}] {entry['codepoint']} routed incompatibility", flush=True)
            continue
        geometry = PROJECT / "geometry" / f"{PREFIX}-{ord(character):04x}.npz"
        report = PROJECT / "reports" / f"{PREFIX}-{ord(character):04x}.json"
        try:
            if not geometry.exists() or not report.exists():
                with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
                    run_character(
                        engine,
                        character,
                        POINTS_PER_CONTOUR,
                        selected_sources=sources,
                        output_prefix=PREFIX,
                        status_override="experimental_extended_majority_candidate",
                        source_selection_policy=(
                            "character is encoded by at least three parent files; project case "
                            "routing is then applied and every remaining source contributes at "
                            "equal weight (minimum two routed sources)"
                        ),
                    )
            detail = json.loads(report.read_text())
            successes.append({
                "codepoint": entry["codepoint"],
                "character": character,
                "sources": detail["sources"],
                "topology": detail["outputTopology"],
                "geometry": str(geometry.relative_to(PROJECT)),
                "report": str(report.relative_to(PROJECT)),
            })
            print(f"[{index:02d}/{len(candidates)}] {entry['codepoint']} {character} complete", flush=True)
        except Exception as error:
            failures.append({
                "codepoint": entry["codepoint"],
                "character": character,
                "error": str(error),
                "traceback": traceback.format_exc(),
            })
            print(f"[{index:02d}/{len(candidates)}] {entry['codepoint']} failed: {error}", flush=True)
    summary = {
        "shardIndex": arguments.shard_index,
        "shardCount": arguments.shard_count,
        "pointsPerContourPerSource": POINTS_PER_CONTOUR,
        "requested": len(candidates),
        "completed": len(successes),
        "failed": len(failures),
        "successes": successes,
        "failures": failures,
    }
    route_suffix = "-two-routed" if arguments.only_two_routed else ""
    suffix = route_suffix + (
        "" if arguments.shard_count == 1
        else f"-shard-{arguments.shard_index + 1}-of-{arguments.shard_count}"
    )
    output = PROJECT / "reports" / f"extended-majority-candidates-0.103{suffix}.json"
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: summary[key] for key in ("requested", "completed", "failed")}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
