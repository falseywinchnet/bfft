#!/usr/bin/env python3
"""Build Portsmouth zero as an equal-weight ring with an explicit fused slash."""

from __future__ import annotations

import json
import math

import contourpy
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.spatial import ConvexHull

from boundary_trace import (
    annealed_boundary_barycenter,
    boundary_cloud,
    rasterize_contour_complex,
    resample_closed,
)
from outline_geometry import (
    ContourComplex,
    ContourLoop,
    normalized_source_contours,
    union_contour_complex,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask, medial_basis
from vectorize import signed_area


def reconstructed_counter(complex_) -> ContourLoop:
    """Recover the unslashed counter shared by one- and two-counter sources."""
    holes = complex_.holes
    if len(holes) == 1:
        return holes[0]
    if len(holes) != 2:
        raise ValueError(f"Zero source has {len(holes)} counters; expected one or two")
    points = np.vstack([loop.points for loop in holes])
    hull = points[ConvexHull(points).vertices]
    area = 0.5 * abs(float(np.sum(
        hull[:, 0] * np.roll(hull[:, 1], -1)
        - hull[:, 1] * np.roll(hull[:, 0], -1)
    )))
    return ContourLoop(
        points=hull,
        role="hole",
        area=area,
        centroid=np.mean(hull, axis=0),
    )


def fit_slash(
    slash: np.ndarray, outer: np.ndarray, counter: np.ndarray
) -> np.ndarray:
    """Terminate the slash midway inside the ring stroke, never at its exterior."""
    slash = slash.astype(np.float64).copy()
    outer_min, outer_max = np.min(outer, axis=0), np.max(outer, axis=0)
    counter_min, counter_max = np.min(counter, axis=0), np.max(counter, axis=0)
    slash_min, slash_max = np.min(slash, axis=0), np.max(slash, axis=0)
    outer_height = outer_max[1] - outer_min[1]
    counter_height = counter_max[1] - counter_min[1]
    # The full slash bbox ends halfway through the top/bottom ring strokes.
    # This leaves an explicit exterior margin while still crossing the entire
    # counter and visibly entering the ring at both ends.
    target_height = counter_height + 0.50 * (outer_height - counter_height)
    scale = target_height / max(slash_max[1] - slash_min[1], 1e-9)
    slash_center = 0.5 * (slash_min + slash_max)
    outer_center = 0.5 * (outer_min + outer_max)
    return (slash - slash_center) * scale + outer_center


def clipped_zero_complex(
    outer: np.ndarray,
    counter: np.ndarray,
    slash: np.ndarray,
    *,
    pixels_per_unit: float = 5.0,
    padding: float = 12.0,
) -> ContourComplex:
    """Union ring and slash while making the oval outer boundary an exact clip."""
    stacked = np.vstack((outer, counter, slash))
    minimum = np.min(stacked, axis=0) - padding
    maximum = np.max(stacked, axis=0) + padding
    width = int(np.ceil((maximum[0] - minimum[0]) * pixels_per_unit)) + 1
    height = int(np.ceil((maximum[1] - minimum[1]) * pixels_per_unit)) + 1

    def polygon_mask(contour):
        image = Image.new("1", (width, height), 0)
        points = [
            (
                float((x - minimum[0]) * pixels_per_unit),
                float((maximum[1] - y) * pixels_per_unit),
            )
            for x, y in contour
        ]
        ImageDraw.Draw(image).polygon(points, fill=1)
        return np.asarray(image, dtype=bool)

    outer_mask = polygon_mask(outer)
    counter_mask = polygon_mask(counter)
    slash_mask = polygon_mask(slash)
    # The intersection with outer_mask is the design constraint: no slash
    # point can alter or project beyond the averaged zero silhouette.
    mask = outer_mask & (~counter_mask | slash_mask)
    x = minimum[0] + np.arange(width) / pixels_per_unit
    y = minimum[1] + np.arange(height) / pixels_per_unit
    generator = contourpy.contour_generator(
        x=x, y=y, z=mask[::-1].astype(np.float64)
    )
    lines = [np.asarray(line) for line in generator.lines(0.5)]
    if not lines:
        raise ValueError("Clipped zero produced no contours")
    areas = np.asarray([signed_area(line) for line in lines])
    outer_sign = 1.0 if areas[int(np.argmax(np.abs(areas)))] >= 0.0 else -1.0
    loops = []
    for line, area in zip(lines, areas):
        role = "outer" if area * outer_sign > 0.0 else "hole"
        points = line if signed_area(line) > 0.0 else line[::-1]
        loops.append(ContourLoop(
            points=points,
            role=role,
            area=abs(float(area)),
            centroid=np.mean(points, axis=0),
        ))
    return ContourComplex(loops)


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    character = "0"
    fields = [engine.source_field(source, character) for source in engine.active_sources(character)]
    raw = normalized_source_contours(engine, character)
    complexes = [
        union_contour_complex(raw[field.source.filename], pixels_per_unit=5.0)
        for field in fields
    ]
    tops = [max(float(np.max(loop.points[:, 1])) for loop in value.outer) for value in complexes]
    target_top = float(np.median(tops))
    for complex_, top in zip(complexes, tops):
        scale = target_top / top
        for loop in complex_.loops:
            loop.points[:, 1] *= scale
            loop.centroid[1] *= scale
            loop.area *= scale

    outer_group = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    counter_group = [reconstructed_counter(value) for value in complexes]
    measures, median, median_info = medial_basis(engine, fields)

    def trace(group):
        clouds = [
            boundary_cloud(
                engine,
                field,
                measure,
                median,
                plan,
                count=10240,
                source_contour=loop.points,
            )
            for field, measure, plan, loop in zip(fields, measures, median.plans, group)
        ]
        return annealed_boundary_barycenter(clouds)

    outer, outer_annealing = trace(outer_group)
    counter, counter_annealing = trace(counter_group)
    slash_archive = PROJECT / "geometry" / "multicontour-trace-002f.npz"
    with np.load(slash_archive, allow_pickle=False) as archive:
        slash_keys = [key for key in archive.files if key.startswith("outer_")]
        if len(slash_keys) != 1:
            raise ValueError(f"Expected one fused slash contour, got {slash_keys}")
        slash = fit_slash(archive[slash_keys[0]], outer, counter)

    united = clipped_zero_complex(outer, counter, slash)
    output_contours = [
        (loop.role, resample_closed(loop.points, 10240)) for loop in united.loops
    ]
    mask = rasterize_contour_complex(engine, output_contours)
    topology = engine.topology(mask)
    expected = {"components": 1, "holes": 2}
    status = "experimental_constrained_zero" if topology == expected else "rejected_topology_mismatch"

    geometry_output = PROJECT / "geometry" / "multicontour-trace-0030.npz"
    arrays = {
        f"{role}_{index}": contour.astype(np.float32)
        for index, (role, contour) in enumerate(output_contours)
    }
    arrays["character"] = np.asarray(character)
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(geometry_output, **arrays)
    report = {
        "character": character,
        "status": status,
        "designConstraint": "slashed zero",
        "pipeline": [
            "equal_weight_outer_ring_trace",
            "per_source_common_counter_reconstruction",
            "equal_weight_counter_trace",
            "fused_solidus_fit",
            "slash_shortened_to_mid_ring_termination",
            "compound_clipped_to_averaged_outer_ring",
        ],
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 1.0 / len(fields),
        "nativeSourceTopology": {
            field.source.filename: engine.topology(field.mask) for field in fields
        },
        "nativeSlashedSourceCount": 2,
        "slashTermination": "mid-ring inset; no contact with exterior contour",
        "pointsPerContour": 10240,
        "expectedTopology": expected,
        "outputTopology": topology,
        "medianSkeleton": median_info,
        "outerAnnealing": outer_annealing,
        "counterAnnealing": counter_annealing,
        "slashGeometry": str(slash_archive.relative_to(PROJECT)),
        "geometryArtifact": str(geometry_output.relative_to(PROJECT)),
        "visualReview": {
            "status": "passes_current_rendered_specimen",
            "observation": "both slash ends visibly terminate inside the ring",
            "authority": "rendered specimen, not the intended clipping rule",
        },
    }
    report_output = PROJECT / "reports" / "multicontour-trace-0030.json"
    report_output.write_text(json.dumps(report, indent=2) + "\n")

    entries = [(field.source.family, field.mask) for field in fields]
    entries.append(("Portsmouth constrained slashed zero", mask))
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 14)
    draw.text((40, 28), "Portsmouth 0 — constrained slashed zero", fill="#111", font=title)
    draw.text(
        (40, 78),
        "equal-weight ring and counter · Portsmouth fused solidus · 10,240 points/contour",
        fill="#575149",
        font=small,
    )
    for index, (name, source_mask) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
            radius=10,
            fill="#fffdf8",
            outline="#d0cabf",
            width=2,
        )
        glyph = _render_mask(source_mask, (tile_w - 70, tile_h - 105))
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 63 + (tile_h - 105 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        subtitle = str(topology) if index == len(entries) - 1 else "height-normalized source"
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    specimen_output = PROJECT / "specimens" / "multicontour-trace-0030.png"
    canvas.save(specimen_output)
    print(json.dumps({key: value for key, value in report.items() if "Annealing" not in key}, indent=2))
    print(specimen_output)


if __name__ == "__main__":
    main()
