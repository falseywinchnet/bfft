#!/usr/bin/env python3
"""Build decomposable Latin Extended glyphs from Portsmouth bases plus marks."""

from __future__ import annotations

import json
import unicodedata

import numpy as np

from boundary_trace import rasterize_contour_complex, resample_closed
from build_first_ttf import archived_contours, geometry_for, mean_advance
from portsmouth_engine import EikonalMidpointEngine, PROJECT


FULL_GEOMETRY_MARKS = {0x0328}  # ogonek joins the body and requires a unified outline
FULL_TARGETS = set("Ţţ")  # these cedillas join the T foot in every compatible source
SIDE_CARON = set("Ľľ")
TEMPLATES = {
    0x0301: ("Á", "á"),
    0x0302: ("Â", "â"),
    0x0303: ("Ã", "ã"),
    0x0304: ("Ā", "ā"),
    0x0306: ("Ă", "ă"),
    0x0307: ("Ċ", "ċ"),
    0x030B: ("Ő", "Ő"),
    0x030C: ("Š", "Š"),
    0x0327: ("Ş", "ş"),
}


def candidate_path(character: str):
    path = PROJECT / "geometry" / f"extended-majority-candidate-{ord(character):04x}.npz"
    return path if path.exists() else None


def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key].astype(float))
            for key in archive.files if key not in {"character", "unitsPerEm"}
        ]


def base_contours(character: str):
    path = geometry_for(ord(character))
    if path is None:
        path = candidate_path(character)
    if path is None:
        raise FileNotFoundError(f"No Portsmouth base geometry for {character!r}")
    return load(path), path


def bbox(contours):
    points = np.vstack([value for _, value in contours])
    return (
        float(np.min(points[:, 0])), float(np.min(points[:, 1])),
        float(np.max(points[:, 0])), float(np.max(points[:, 1])),
    )


def clip_below(points: np.ndarray, cut: float) -> np.ndarray:
    output = []
    previous = points[-1]
    previous_inside = previous[1] <= cut
    for current in points:
        current_inside = current[1] <= cut
        if current_inside != previous_inside:
            fraction = (cut - previous[1]) / (current[1] - previous[1])
            output.append(previous + fraction * (current - previous))
        if current_inside:
            output.append(current)
        previous, previous_inside = current, current_inside
    result = np.asarray(output, dtype=float)
    if len(result) < 3:
        raise ValueError("Below-mark extraction collapsed")
    return result


def comma_below(base, comma):
    source = max((points for role, points in comma if role == "outer"), key=len).copy()
    center = 0.5 * (np.min(source, axis=0) + np.max(source, axis=0))
    source = (source - center) * 0.58
    bx0, by0, bx1, _ = bbox(base)
    minimum, maximum = np.min(source, axis=0), np.max(source, axis=0)
    target_center_x = 0.5 * (bx0 + bx1)
    source[:, 0] += target_center_x - 0.5 * (minimum[0] + maximum[0])
    source[:, 1] += by0 - 18.0 - maximum[1]
    return [("outer", source)]


def detached_mark(template, base, *, above: bool, preserve_position: bool):
    outers = [(role, points) for role, points in template if role == "outer"]
    body_role, body = max(
        outers,
        key=lambda item: float(np.ptp(item[1][:, 0]) * np.ptp(item[1][:, 1])),
    )
    body_top, body_bottom = float(np.max(body[:, 1])), float(np.min(body[:, 1]))
    if preserve_position:
        marks = [
            (role, points.copy()) for role, points in outers if points is not body
        ]
    elif above:
        marks = [
            (role, points.copy()) for role, points in outers
            if points is not body and float(np.min(points[:, 1])) > body_top + 8.0
        ]
    else:
        marks = [
            (role, points.copy()) for role, points in outers
            if points is not body and float(np.max(points[:, 1])) < body_bottom - 8.0
        ]
        if not marks:
            marks = [("outer", clip_below(body, min(-28.0, body_bottom + 8.0)))]
    if not marks:
        raise ValueError("No detached accent contour found")
    bx0, by0, bx1, by1 = bbox(base)
    mx0, my0, mx1, my1 = bbox(marks)
    shift_x = 0.0 if preserve_position else 0.5 * (bx0 + bx1) - 0.5 * (mx0 + mx1)
    if preserve_position:
        shift_y = 0.0
    elif above:
        shift_y = by1 + 24.0 - my0
    else:
        shift_y = by0 - 18.0 - my1
    return [
        (role, points + np.array([shift_x, shift_y]))
        for role, points in marks
    ]


def main() -> None:
    audit = json.loads(
        (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
    )
    entries = [
        entry for entry in audit["entries"]
        if entry["compatiblePersistentTopology"] and not entry["production"]
    ]
    decomposable = []
    for entry in entries:
        decomposition = unicodedata.normalize("NFD", entry["character"])
        if len(decomposition) > 1 and all(unicodedata.combining(value) for value in decomposition[1:]):
            decomposable.append((entry, decomposition))
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    comma = archived_contours(geometry_for(ord(",")))
    results = []
    for entry, decomposition in decomposable:
        character = entry["character"]
        base_character = decomposition[0]
        marks = [ord(value) for value in decomposition[1:]]
        # Above marks replace the native i/j tittle.
        if base_character == "i" and any(mark not in {0x0327, 0x0328, 0x0326} for mark in marks):
            base_character = "ı"
        if base_character == "j" and any(mark not in {0x0327, 0x0328, 0x0326} for mark in marks):
            base_character = "ȷ"
        base, base_path = base_contours(base_character)
        if character in FULL_TARGETS or any(mark in FULL_GEOMETRY_MARKS for mark in marks):
            source_path = candidate_path(character)
            if source_path is None:
                raise FileNotFoundError(f"Attached ogonek candidate missing for {character}")
            output = load(source_path)
            method = "attached_mark_full_unity"
            template_character = character
        else:
            output = [(role, points.copy()) for role, points in base]
            template_character = character if candidate_path(character) else None
            for mark in marks:
                if mark == 0x0326:
                    output += comma_below(base, comma)
                    continue
                if template_character is None:
                    template_character = TEMPLATES[mark][0 if character.isupper() else 1]
                template = load(candidate_path(template_character) or geometry_for(ord(template_character)))
                output += detached_mark(
                    template,
                    base,
                    above=mark not in {0x0327, 0x0326},
                    preserve_position=character in SIDE_CARON and template_character == character,
                )
            method = "accepted_base_plus_detached_mark"
        actual = engine.topology(rasterize_contour_complex(engine, output))
        expected = next(iter(entry["topologies"].values()))
        if actual != expected:
            raise ValueError(
                f"{entry['codepoint']} composition topology {actual}, expected {expected}"
            )
        codepoint = ord(character)
        geometry = PROJECT / "geometry" / f"extended-composed-candidate-{codepoint:04x}.npz"
        arrays = {
            f"{role}_{index}": resample_closed(points, 10240).astype(np.float32)
            for index, (role, points) in enumerate(output)
        }
        arrays["character"] = np.asarray(character)
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(geometry, **arrays)
        report = {
            "character": character,
            "status": "experimental_extended_composed_candidate",
            "method": method,
            "baseCharacter": base_character,
            "baseGeometry": str(base_path.relative_to(PROJECT)),
            "targetAdvance": mean_advance(engine, base_character),
            "combiningMarks": [f"U+{mark:04X}" for mark in marks],
            "templateCharacter": template_character,
            "pointsPerContour": 10240,
            "expectedTopology": expected,
            "outputTopology": actual,
            "geometryArtifact": str(geometry.relative_to(PROJECT)),
        }
        report_path = PROJECT / "reports" / f"extended-composed-candidate-{codepoint:04x}.json"
        report_path.write_text(json.dumps(report, indent=2) + "\n")
        results.append(entry["codepoint"])
        print(entry["codepoint"], character, method)
    summary = PROJECT / "reports" / "extended-composed-candidates-0.103.json"
    summary.write_text(json.dumps({
        "count": len(results),
        "codepoints": results,
        "policy": "reuse accepted Portsmouth bases; add or unite only the diacritic geometry",
    }, indent=2) + "\n")
    print(summary)


if __name__ == "__main__":
    main()
