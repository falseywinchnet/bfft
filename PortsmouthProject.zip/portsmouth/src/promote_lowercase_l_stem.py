#!/usr/bin/env python3
"""Remove both horizontal bars from Portsmouth lowercase l."""

from __future__ import annotations

import json

import numpy as np

from boundary_trace import resample_closed
from portsmouth_engine import PROJECT
from vectorize import signed_area


SOURCE = PROJECT / "geometry" / "boundary-trace-006c.npz"
OUTPUT = PROJECT / "geometry" / "letter-repair-006c.npz"
REPORT = PROJECT / "reports" / "letter-repair-006c.json"


def clip_vertical(points: np.ndarray, boundary: float, *, keep_greater: bool) -> np.ndarray:
    output = []
    previous = points[-1]
    previous_inside = previous[0] >= boundary if keep_greater else previous[0] <= boundary
    for point in points:
        inside = point[0] >= boundary if keep_greater else point[0] <= boundary
        if inside != previous_inside:
            fraction = (boundary - previous[0]) / (point[0] - previous[0])
            output.append(previous + fraction * (point - previous))
        if inside:
            output.append(point)
        previous, previous_inside = point, inside
    result = np.asarray(output, dtype=np.float64)
    if len(result) < 3:
        raise ValueError("lowercase l stem clipping collapsed the contour")
    return result


def band_span(points: np.ndarray, start: float, end: float) -> tuple[float, float]:
    minimum_y, maximum_y = np.min(points[:, 1]), np.max(points[:, 1])
    selected = points[
        (points[:, 1] >= minimum_y + start * (maximum_y - minimum_y))
        & (points[:, 1] <= minimum_y + end * (maximum_y - minimum_y))
    ]
    return float(np.min(selected[:, 0])), float(np.max(selected[:, 0]))


def main() -> None:
    with np.load(SOURCE, allow_pickle=False) as archive:
        source = archive["contour"].astype(np.float64)
    # The central 25–85% is the uninterrupted accepted stem. Its union of
    # cross-section extrema defines the shaving plane for both terminal bars.
    stem_left, stem_right = band_span(source, 0.25, 0.85)
    clipped = clip_vertical(source, stem_left, keep_greater=True)
    clipped = clip_vertical(clipped, stem_right, keep_greater=False)
    if signed_area(clipped) * signed_area(source) < 0:
        clipped = clipped[::-1]
    repaired = resample_closed(clipped, 10240)
    np.savez_compressed(
        OUTPUT,
        outer_0=repaired.astype(np.float32),
        character=np.asarray("l"),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    source_top = band_span(source, 0.88, 1.0)
    source_bottom = band_span(source, 0.0, 0.12)
    repaired_top = band_span(repaired, 0.88, 1.0)
    repaired_bottom = band_span(repaired, 0.0, 0.12)
    report = {
        "status": "promoted",
        "character": "l",
        "codepoint": "U+006C",
        "method": "accepted stem preserved; upper and lower horizontal overhang clipped",
        "sourceGeometry": str(SOURCE.relative_to(PROJECT)),
        "outputGeometry": str(OUTPUT.relative_to(PROJECT)),
        "stemBounds": [stem_left, stem_right],
        "sourceTerminalSpans": {
            "top": source_top[1] - source_top[0],
            "bottom": source_bottom[1] - source_bottom[0],
        },
        "outputTerminalSpans": {
            "top": repaired_top[1] - repaired_top[0],
            "bottom": repaired_bottom[1] - repaired_bottom[0],
        },
        "horizontalOverhangRemaining": 0.0,
        "densePoints": len(repaired),
    }
    REPORT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
