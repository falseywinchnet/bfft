#!/usr/bin/env python3
"""Validate and index Portsmouth's full-resolution alphabet geometry."""

from __future__ import annotations

import json
import unicodedata
from string import ascii_letters

import numpy as np

from portsmouth_engine import PROJECT


def build_manifest() -> dict:
    entries = []
    rejected = []
    geometry_paths = sorted((PROJECT / "geometry").glob("boundary-trace-*.npz"))
    geometry_paths += sorted((PROJECT / "geometry").glob("multicontour-trace-*.npz"))
    discovered = {}
    for geometry_path in geometry_paths:
        prefix, stem = geometry_path.stem.rsplit("-", 1)
        if len(stem) != 4:
            # Baselines and rejected variants may end in a hexadecimal-looking
            # word fragment (for example "a"); only exact U+XXXX artifacts are
            # current glyph geometry.
            continue
        try:
            codepoint = int(stem, 16)
        except ValueError:
            # Explicitly archived baselines and rejected variants are not
            # current Unicode geometry artifacts.
            continue
        character = chr(codepoint)
        if character in discovered:
            raise ValueError(f"Duplicate geometry for {character!r}")
        discovered[character] = (prefix, geometry_path)
    missing_ascii = sorted(set(ascii_letters) - set(discovered))
    if missing_ascii:
        raise FileNotFoundError(f"Missing ASCII alphabet geometry: {missing_ascii}")
    for character in sorted(discovered, key=ord):
        prefix, geometry_path = discovered[character]
        stem = f"{ord(character):04x}"
        report_path = PROJECT / "reports" / f"{prefix}-{stem}.json"
        if not report_path.exists():
            raise FileNotFoundError(f"Missing archived geometry/report for {character!r}")
        report = json.loads(report_path.read_text())
        if report.get("status", "").startswith("rejected"):
            rejected.append({
                "character": character,
                "codepoint": f"U+{ord(character):04X}",
                "geometry": str(geometry_path.relative_to(PROJECT)),
                "report": str(report_path.relative_to(PROJECT)),
                "status": report["status"],
                "visualReview": report.get("visualReview"),
            })
            continue
        with np.load(geometry_path, allow_pickle=False) as archive:
            archived_character = str(archive["character"])
            units_per_em = int(archive["unitsPerEm"])
            contour_keys = sorted(
                key for key in archive.files if key not in {"character", "unitsPerEm"}
            )
            if archived_character != character:
                raise ValueError(
                    f"{geometry_path.name} contains {archived_character!r}, expected {character!r}"
                )
            if units_per_em != 1000:
                raise ValueError(f"{geometry_path.name} has UPM {units_per_em}")
            shapes = {key: list(archive[key].shape) for key in contour_keys}
            if any(shape != [10240, 2] for shape in shapes.values()):
                raise ValueError(f"Unexpected contour shape in {geometry_path.name}: {shapes}")
        entries.append({
            "character": character,
            "codepoint": f"U+{ord(character):04X}",
            "method": prefix,
            "status": report["status"],
            "visualReview": report.get("visualReview"),
            "sources": report["sources"],
            "equalSourceWeight": report["equalSourceWeight"],
            "geometry": str(geometry_path.relative_to(PROJECT)),
            "report": str(report_path.relative_to(PROJECT)),
            "contours": shapes,
        })
    review = [entry["character"] for entry in entries if entry["status"] == "needs_design_review"]
    letter_count = sum(
        unicodedata.category(entry["character"]).startswith("L") for entry in entries
    )
    return {
        "name": "Portsmouth",
        "unitsPerEm": 1000,
        "pointsPerContour": 10240,
        "alphabetGlyphs": len(ascii_letters),
        "glyphs": len(entries),
        "letterGlyphs": letter_count,
        "nonLetterGlyphs": len(entries) - letter_count,
        "extendedLetterGlyphs": letter_count - len(ascii_letters),
        "reviewGlyphs": review,
        "rejectedArtifacts": rejected,
        "entries": entries,
    }


def main() -> None:
    manifest = build_manifest()
    output = PROJECT / "geometry" / "manifest.json"
    output.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
