#!/usr/bin/env python3
"""Run transport and barycenter stages for lowercase m, without geometry."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from transport_barycenter import free_support_barycenter, sample_ink_measure


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    fields = [
        engine.source_field(source, "m") for source in engine.active_sources("m")
    ]
    source_supports = []
    source_masses = []
    for index, field in enumerate(fields):
        support, mass = sample_ink_measure(
            engine, field, 96, seed=1701 + index * 104729
        )
        source_supports.append(support)
        source_masses.append(mass)
    result = free_support_barycenter(source_supports, source_masses)

    report = {
        "character": "m",
        "stage": "transport_then_barycenter_only",
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 1.0 / len(fields),
        "atomsPerMeasure": len(result.support),
        "transport": "exact_hard_uniform_particle_assignment",
        "costScale": 500.0,
        "objective": result.objective,
        "iterations": result.iterations,
        "selectedInitialization": fields[result.initialization].source.filename,
        "marginalMaximumErrors": [
            {
                "source": field.source.filename,
                "barycenter": float(np.max(np.abs(
                    plan.sum(axis=1) - result.support_mass
                ))),
                "sourceMeasure": float(np.max(np.abs(
                    plan.sum(axis=0) - result.source_masses[index]
                ))),
            }
            for index, (field, plan) in enumerate(zip(fields, result.plans))
        ],
        "geometryBuilt": False,
        "geometryMerged": False,
    }
    report_path = PROJECT / "reports" / "transport-barycenter-006d.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")

    tile_w, tile_h, columns = 380, 400, 3
    entries = list(zip(fields, result.source_supports, result.plans))
    rows = math.ceil((len(entries) + 1) / columns)
    canvas = Image.new(
        "RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 34
    )
    label = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 19
    )
    small = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 14
    )
    draw.text((40, 30), "Portsmouth m — transport → barycenter", fill="#111", font=title)
    draw.text(
        (40, 78),
        "96 equal-mass atoms per native rendering · no geometry constructed",
        fill="#575149", font=small,
    )
    x_min, x_max = -430.0, 430.0
    y_min, y_max = -70.0, 570.0

    def project(points, x0, y0):
        px = x0 + 30 + (points[:, 0] - x_min) / (x_max - x_min) * (tile_w - 80)
        py = y0 + 75 + (y_max - points[:, 1]) / (y_max - y_min) * (tile_h - 120)
        return np.column_stack((px, py))

    for index, (field, source, plan) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
            radius=10, fill="#fffdf8", outline="#d0cabf", width=2,
        )
        source_xy = project(source, x0, y0)
        bary_xy = project(result.support, x0, y0)
        # Show only the strongest destination for each barycenter atom; the
        # full soft plan remains in the numeric artifact.
        strongest = np.argmax(plan, axis=1)
        for bary_index, source_index in enumerate(strongest):
            draw.line(
                (*bary_xy[bary_index], *source_xy[source_index]),
                fill="#b9c8d4", width=1,
            )
        for x, y in source_xy:
            draw.ellipse((x - 2, y - 2, x + 2, y + 2), fill="#1f1f1d")
        for x, y in bary_xy:
            draw.ellipse((x - 2, y - 2, x + 2, y + 2), fill="#d34e38")
        draw.text((x0 + 15, y0 + 15), field.source.family, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 43), "blue transport · red barycenter", fill="#655f57", font=small)

    index = len(entries)
    col, row = index % columns, index // columns
    x0, y0 = 40 + col * tile_w, 120 + row * tile_h
    draw.rounded_rectangle(
        (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
        radius=10, fill="#fffdf8", outline="#d0cabf", width=2,
    )
    bary_xy = project(result.support, x0, y0)
    for x, y in bary_xy:
        draw.ellipse((x - 3, y - 3, x + 3, y + 3), fill="#d34e38")
    draw.text((x0 + 15, y0 + 15), "Equal-weight barycenter measure", fill="#151515", font=label)
    draw.text((x0 + 15, y0 + 43), "geometry deliberately not built", fill="#655f57", font=small)

    output = PROJECT / "specimens" / "transport-barycenter-006d.png"
    canvas.save(output)
    print(json.dumps(report, indent=2))
    print(output)


if __name__ == "__main__":
    main()
