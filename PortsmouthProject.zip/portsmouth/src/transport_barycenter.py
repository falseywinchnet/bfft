#!/usr/bin/env python3
"""Discrete transport and free-support barycenter for Portsmouth glyph mass."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import linear_sum_assignment

from portsmouth_engine import EikonalMidpointEngine, GlyphField


@dataclass
class TransportBarycenter:
    support: np.ndarray
    support_mass: np.ndarray
    source_supports: list[np.ndarray]
    source_masses: list[np.ndarray]
    plans: list[np.ndarray]
    objective: float
    iterations: int
    initialization: int


def sample_ink_measure(
    engine: EikonalMidpointEngine,
    field: GlyphField,
    count: int,
    *,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Deterministically sample equal atoms from a rendered ink measure."""
    rows, columns = np.nonzero(field.mask)
    if len(rows) < count:
        raise ValueError(
            f"{field.source.filename} has only {len(rows)} ink samples"
        )
    rng = np.random.default_rng(seed)
    selected = rng.choice(len(rows), size=count, replace=False)
    x = engine.x_min + (columns[selected] + 0.5) / engine.pixels_per_unit
    y = engine.y_max - (rows[selected] + 0.5) / engine.pixels_per_unit
    support = np.column_stack((x, y)).astype(np.float64)
    mass = np.full(count, 1.0 / count, dtype=np.float64)
    return support, mass


def squared_cost(
    left: np.ndarray,
    right: np.ndarray,
    scale: float | np.ndarray,
) -> np.ndarray:
    difference = left[:, None, :] - right[None, :, :]
    return np.sum((difference / np.asarray(scale)) ** 2, axis=2)


def _logsumexp(values: np.ndarray, axis: int) -> np.ndarray:
    maximum = np.max(values, axis=axis, keepdims=True)
    summed = np.sum(np.exp(values - maximum), axis=axis, keepdims=True)
    return np.squeeze(maximum + np.log(summed), axis=axis)


def sinkhorn_plan(
    left: np.ndarray,
    right: np.ndarray,
    left_mass: np.ndarray,
    right_mass: np.ndarray,
    *,
    epsilon: float,
    scale: float | np.ndarray,
    iterations: int = 160,
) -> tuple[np.ndarray, float]:
    """Balanced entropic transport with explicit marginal normalization."""
    cost = squared_cost(left, right, scale)
    log_kernel = -cost / epsilon
    log_left_mass = np.log(left_mass)
    log_right_mass = np.log(right_mass)
    log_u = np.zeros_like(left_mass)
    log_v = np.zeros_like(right_mass)
    for _ in range(iterations):
        log_u = log_left_mass - _logsumexp(
            log_kernel + log_v[None, :], axis=1
        )
        log_v = log_right_mass - _logsumexp(
            log_kernel + log_u[:, None], axis=0
        )
    plan = np.exp(log_u[:, None] + log_kernel + log_v[None, :])
    # Alternating scaling is repeated after materialization until both
    # marginals are numerically balanced.  A fixed handful of passes is not
    # sufficient for glyphs whose distant regions have almost-disconnected
    # kernels (and it made the claimed equal source weight only approximate).
    for _ in range(2048):
        plan *= (left_mass / np.maximum(plan.sum(axis=1), 1e-300))[:, None]
        plan *= (right_mass / np.maximum(plan.sum(axis=0), 1e-300))[None, :]
        row_error = np.max(np.abs(plan.sum(axis=1) - left_mass))
        column_error = np.max(np.abs(plan.sum(axis=0) - right_mass))
        if max(row_error, column_error) <= 1e-12:
            break
    return plan, float(np.sum(plan * cost))


def exact_particle_plan(
    left: np.ndarray,
    right: np.ndarray,
    left_mass: np.ndarray,
    right_mass: np.ndarray,
    *,
    scale: float | np.ndarray,
) -> tuple[np.ndarray, float]:
    """Exact one-to-one transport for uniform, equally sized glyph atoms.

    Portsmouth deliberately uses a hard particle correspondence here.  Soft
    entropic transport diffuses a distinctive shoulder into nearby majority
    shapes before the barycenter is even formed.
    """
    if len(left) != len(right):
        raise ValueError("Exact particle transport needs equal support sizes")
    expected = np.full(len(left_mass), 1.0 / len(left_mass))
    if not (
        np.allclose(left_mass, expected)
        and np.allclose(right_mass, expected)
    ):
        raise ValueError("Exact particle transport needs uniform masses")
    cost = squared_cost(left, right, scale)
    rows, columns = linear_sum_assignment(cost)
    plan = np.zeros_like(cost)
    plan[rows, columns] = expected[rows]
    return plan, float(np.sum(plan * cost))


def _solve_from_initialization(
    source_supports: list[np.ndarray],
    source_masses: list[np.ndarray],
    initialization: int,
    *,
    epsilon: float,
    scale: float | np.ndarray,
    maximum_iterations: int,
    tolerance: float,
) -> TransportBarycenter:
    support = source_supports[initialization].copy()
    support_mass = np.full(len(support), 1.0 / len(support))
    plans = []
    objective = np.inf
    for iteration in range(1, maximum_iterations + 1):
        projections = []
        plans = []
        objective = 0.0
        for source, mass in zip(source_supports, source_masses):
            plan, value = exact_particle_plan(
                support,
                source,
                support_mass,
                mass,
                scale=scale,
            )
            plans.append(plan)
            objective += value / len(source_supports)
            projections.append((plan @ source) / support_mass[:, None])
        updated = np.mean(projections, axis=0)
        displacement = np.max(np.linalg.norm(updated - support, axis=1))
        support = updated
        if displacement <= tolerance:
            break
    # Refresh plans at the accepted support.
    plans = []
    objective = 0.0
    for source, mass in zip(source_supports, source_masses):
        plan, value = exact_particle_plan(
            support,
            source,
            support_mass,
            mass,
            scale=scale,
        )
        plans.append(plan)
        objective += value / len(source_supports)
    return TransportBarycenter(
        support=support,
        support_mass=support_mass,
        source_supports=source_supports,
        source_masses=source_masses,
        plans=plans,
        objective=objective,
        iterations=iteration,
        initialization=initialization,
    )


def free_support_barycenter(
    source_supports: list[np.ndarray],
    source_masses: list[np.ndarray],
    *,
    epsilon: float = 0.018,
    scale: float | np.ndarray = 500.0,
    maximum_iterations: int = 30,
    tolerance: float = 0.05,
) -> TransportBarycenter:
    """Equal-weight hard-particle barycenter with multi-starts.

    ``epsilon`` is retained temporarily for call compatibility with the first
    experimental driver; the hard Portsmouth transport does not use it.
    """
    if not source_supports:
        raise ValueError("At least one source measure is required")
    count = len(source_supports[0])
    if any(len(source) != count for source in source_supports):
        raise ValueError("All sampled measures must have equal support size")
    candidates = [
        _solve_from_initialization(
            source_supports,
            source_masses,
            initialization,
            epsilon=epsilon,
            scale=scale,
            maximum_iterations=maximum_iterations,
            tolerance=tolerance,
        )
        for initialization in range(len(source_supports))
    ]
    return min(candidates, key=lambda candidate: candidate.objective)
