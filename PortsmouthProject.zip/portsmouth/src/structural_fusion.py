#!/usr/bin/env python3
"""Ordered structural fusion experiments for Portsmouth lowercase m."""

from __future__ import annotations

from dataclasses import replace

import numpy as np
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

from portsmouth_engine import EikonalMidpointEngine, GlyphField


def x_coordinates(engine: EikonalMidpointEngine) -> np.ndarray:
    return engine.x_min + (
        np.arange(engine.width, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit


def y_coordinates(engine: EikonalMidpointEngine) -> np.ndarray:
    return engine.y_max - (
        np.arange(engine.height, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit


def detect_stem_axes(
    engine: EikonalMidpointEngine, field: GlyphField
) -> np.ndarray:
    """Detect the three lower-stem axes of a normalized lowercase m."""
    y = y_coordinates(engine)
    rows = (y >= 20.0) & (y <= 180.0)
    profile = field.mask[rows].mean(axis=0)
    sigma = max(1.0, 16.0 * engine.pixels_per_unit)
    profile = gaussian_filter1d(profile, sigma=sigma)
    minimum_distance = max(1, int(round(120.0 * engine.pixels_per_unit)))
    peaks, properties = find_peaks(
        profile, distance=minimum_distance, prominence=0.05
    )
    if len(peaks) < 3:
        raise ValueError(
            f"Could not find three stems in {field.source.filename}: {len(peaks)}"
        )
    prominence = properties["prominences"]
    selected = peaks[np.argsort(prominence)[-3:]]
    selected.sort()
    return x_coordinates(engine)[selected]


def _inverse_piecewise_map(
    target: np.ndarray, target_anchors: np.ndarray, source_anchors: np.ndarray
) -> np.ndarray:
    result = np.interp(target, target_anchors, source_anchors)
    left = target < target_anchors[0]
    right = target > target_anchors[-1]
    left_slope = (
        (source_anchors[1] - source_anchors[0])
        / (target_anchors[1] - target_anchors[0])
    )
    right_slope = (
        (source_anchors[-1] - source_anchors[-2])
        / (target_anchors[-1] - target_anchors[-2])
    )
    result[left] = source_anchors[0] + (
        target[left] - target_anchors[0]
    ) * left_slope
    result[right] = source_anchors[-1] + (
        target[right] - target_anchors[-1]
    ) * right_slope
    return result


def register_stems(
    engine: EikonalMidpointEngine,
    fields: list[GlyphField],
) -> tuple[list[GlyphField], np.ndarray, dict[str, list[float]]]:
    axes = {
        field.source.filename: detect_stem_axes(engine, field)
        for field in fields
    }
    target_axes = np.mean(np.stack(list(axes.values())), axis=0)
    target_x = x_coordinates(engine)
    rows = np.broadcast_to(
        np.arange(engine.height, dtype=np.float64)[:, None],
        (engine.height, engine.width),
    )
    registered = []
    for field in fields:
        source_x = _inverse_piecewise_map(
            target_x, target_axes, axes[field.source.filename]
        )
        source_columns = (
            (source_x - engine.x_min) * engine.pixels_per_unit - 0.5
        )
        columns = np.broadcast_to(source_columns[None, :], field.mask.shape)
        warped = ndimage.map_coordinates(
            field.mask.astype(np.float64),
            (rows, columns),
            order=1,
            mode="constant",
            cval=0.0,
            prefilter=False,
        ) >= 0.5
        registered.append(replace(
            field,
            mask=warped,
            sdf=engine.signed_distance(warped),
        ))
    return registered, target_axes, {
        name: list(map(float, values)) for name, values in axes.items()
    }


def field_mean_mask(
    engine: EikonalMidpointEngine,
    fields: list[GlyphField],
) -> tuple[np.ndarray, np.ndarray, float]:
    raw = np.mean([field.sdf for field in fields], axis=0)
    if engine.field_smoothing > 0:
        raw = ndimage.gaussian_filter(
            raw,
            sigma=engine.field_smoothing * engine.pixels_per_unit,
            mode="nearest",
        )
    level, mask, _expected = engine.topology_constrained_level(raw, fields)
    return raw, mask, level


def ordered_top_band_fusion(
    engine: EikonalMidpointEngine,
    registered: list[GlyphField],
    base_mask: np.ndarray,
) -> tuple[np.ndarray, int]:
    """Average ordered shoulder envelopes/radii in the common stem frame.

    For columns where every source has a finite top stroke separated from the
    baseline, the outer and inner boundaries of that stroke are averaged
    independently. This retains first/second shoulder asymmetry rather than
    letting a majority occupancy vote erase it.
    """
    fused = base_mask.copy()
    target_top = np.full(engine.width, np.nan)
    target_bottom = np.full(engine.width, np.nan)
    for column in range(engine.width):
        runs = []
        for field in registered:
            values = field.mask[:, column]
            true_rows = np.flatnonzero(values)
            if not len(true_rows):
                break
            top = int(true_rows[0])
            false_after = np.flatnonzero(~values[top:])
            if not len(false_after):
                break
            bottom = top + int(false_after[0]) - 1
            if bottom - top < max(2, round(6 * engine.pixels_per_unit)):
                break
            runs.append((top, bottom))
        if len(runs) != len(registered):
            continue
        top = float(np.mean([run[0] for run in runs]))
        bottom = float(np.mean([run[1] for run in runs]))
        # Only replace a separated shoulder band. A run extending close to the
        # baseline is a stem and remains governed by the registered field mean.
        bottom_y = y_coordinates(engine)[min(int(round(bottom)), engine.height - 1)]
        if bottom_y < 190.0:
            continue
        target_top[column] = top
        target_bottom[column] = bottom

    valid = np.isfinite(target_top) & np.isfinite(target_bottom)
    labels, count = ndimage.label(valid)
    replaced_columns = 0
    for label in range(1, count + 1):
        columns = np.flatnonzero(labels == label)
        if len(columns) < max(5, round(16 * engine.pixels_per_unit)):
            continue
        top_values = target_top[columns]
        bottom_values = target_bottom[columns]
        sigma = max(1.0, 4.0 * engine.pixels_per_unit)
        top_values = gaussian_filter1d(top_values, sigma=sigma, mode="nearest")
        bottom_values = gaussian_filter1d(bottom_values, sigma=sigma, mode="nearest")
        ramp_length = max(2, round(14 * engine.pixels_per_unit))
        distance_to_edge = np.minimum(
            np.arange(len(columns)) + 1,
            np.arange(len(columns), 0, -1),
        )
        blend = np.clip(distance_to_edge / ramp_length, 0.0, 1.0)
        for index, column in enumerate(columns):
            base_rows = np.flatnonzero(base_mask[:, column])
            if not len(base_rows):
                continue
            base_top = int(base_rows[0])
            false_after = np.flatnonzero(~base_mask[base_top:, column])
            if not len(false_after):
                continue
            base_bottom = base_top + int(false_after[0]) - 1
            top = int(round(
                (1.0 - blend[index]) * base_top
                + blend[index] * top_values[index]
            ))
            bottom = int(round(
                (1.0 - blend[index]) * base_bottom
                + blend[index] * bottom_values[index]
            ))
            if bottom <= top:
                continue
            fused[:, column] = False
            fused[top:bottom + 1, column] = True
            replaced_columns += 1
    return fused, replaced_columns


def shoulder_mass_delta(
    engine: EikonalMidpointEngine,
    mask: np.ndarray,
    stems: np.ndarray,
) -> float:
    """Return second-minus-first shoulder vertical center of mass in units."""
    x = x_coordinates(engine)
    y = y_coordinates(engine)
    centers = []
    for left, right in zip(stems[:-1], stems[1:]):
        inset = 0.18 * (right - left)
        columns = (x >= left + inset) & (x <= right - inset)
        region = mask[:, columns]
        rows, _cols = np.nonzero(region)
        centers.append(float(np.mean(y[rows])))
    return centers[1] - centers[0]
