#!/usr/bin/env python3
"""Audit Portsmouth's deliberately distinct zero/one/I/i/l silhouettes."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT


CHARACTERS = "01iIl|"


def geometry_for(character: str) -> Path:
    stem = f"{ord(character):04x}"
    for prefix in ("letter-repair", "boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            return path
    raise FileNotFoundError(f"No geometry archive for {character!r}")


def archived_contours(path: Path) -> list[tuple[str, np.ndarray]]:
    with np.load(path, allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def tight(mask: np.ndarray) -> np.ndarray:
    rows, columns = np.nonzero(mask)
    return mask[rows.min():rows.max() + 1, columns.min():columns.max() + 1]


def normalized(mask: np.ndarray, size: int = 256) -> np.ndarray:
    image = Image.fromarray(tight(mask))
    return np.asarray(image.resize((size, size), Image.Resampling.NEAREST), bool)


def difference(first: np.ndarray, second: np.ndarray) -> dict[str, float]:
    first, second = normalized(first), normalized(second)
    intersection = int(np.sum(first & second))
    union = int(np.sum(first | second))
    return {
        "intersectionOverUnion": intersection / union,
        "exclusivePixelFraction": float(np.mean(first ^ second)),
    }


def band_measure(mask: np.ndarray, start: float, end: float) -> dict[str, float]:
    mask = tight(mask)
    height, width = mask.shape
    first = max(0, int(round(start * height)))
    last = min(height, max(first + 1, int(round(end * height))))
    spans, centers = [], []
    for row in mask[first:last]:
        columns = np.flatnonzero(row)
        if columns.size:
            spans.append(float(columns[-1] - columns[0] + 1))
            centers.append(float((columns[-1] + columns[0]) / (2.0 * width)))
    if not spans:
        raise ValueError(f"Empty measurement band {start:.2f}..{end:.2f}")
    return {
        "medianSpan": float(np.median(spans)),
        "normalizedCenter": float(np.median(centers)),
    }


def render_specimen(masks: dict[str, np.ndarray], output: Path) -> None:
    labels = {
        "0": "two counters; inset slash",
        "1": "flag + broad foot",
        "i": "separate dot",
        "I": "bilateral cap and foot",
        "l": "bare lowercase stem",
        "|": "full-height pipe",
    }
    tile_width, tile_height = 260, 410
    canvas = Image.new("RGB", (80 + len(CHARACTERS) * tile_width, 560), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 32
    )
    label = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 19
    )
    small = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 14
    )
    draw.text((40, 28), "Portsmouth character disambiguation", fill="#111", font=title)
    draw.text(
        (40, 76),
        "Rendered from archived 10,240-point geometry · visual review is authoritative",
        fill="#575149",
        font=small,
    )
    for index, character in enumerate(CHARACTERS):
        x0, y0 = 40 + index * tile_width, 120
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_width - 20, y0 + tile_height),
            radius=12,
            fill="#fffdf8",
            outline="#c8c0b4",
            width=2,
        )
        draw.text((x0 + 15, y0 + 12), repr(character), fill="#111", font=label)
        draw.text((x0 + 15, y0 + 40), labels[character], fill="#625b52", font=small)
        glyph = tight(masks[character])
        layer = np.full((*glyph.shape, 3), 255, dtype=np.uint8)
        layer[glyph] = (20, 20, 18)
        image = Image.fromarray(layer)
        image.thumbnail((190, 300), Image.Resampling.LANCZOS)
        canvas.paste(
            image,
            (x0 + (tile_width - 20 - image.width) // 2, y0 + 82 + (300 - image.height) // 2),
        )
    canvas.save(output)


def audit() -> dict:
    engine = EikonalMidpointEngine(pixels_per_unit=2.0)
    paths = {character: geometry_for(character) for character in CHARACTERS}
    masks = {
        character: rasterize_contour_complex(engine, archived_contours(path))
        for character, path in paths.items()
    }
    topology = {character: engine.topology(mask) for character, mask in masks.items()}
    one_i = difference(masks["1"], masks["i"])
    capital_i_l = difference(masks["I"], masks["l"])
    lowercase_l_pipe = difference(masks["l"], masks["|"])
    capital_top = band_measure(masks["I"], 0.05, 0.15)
    capital_middle = band_measure(masks["I"], 0.40, 0.60)
    capital_bottom = band_measure(masks["I"], 0.85, 0.95)
    lowercase_top = band_measure(masks["l"], 0.05, 0.15)
    lowercase_bottom = band_measure(masks["l"], 0.85, 0.95)
    lowercase_middle = band_measure(masks["l"], 0.40, 0.60)
    capital_i_structure = {
        "topBarToStemRatio": capital_top["medianSpan"] / capital_middle["medianSpan"],
        "bottomBarToStemRatio": capital_bottom["medianSpan"] / capital_middle["medianSpan"],
        "topCenter": capital_top["normalizedCenter"],
        "bottomCenter": capital_bottom["normalizedCenter"],
    }
    lowercase_l_structure = {
        "topBarToStemRatio": lowercase_top["medianSpan"] / lowercase_middle["medianSpan"],
        "bottomBarToStemRatio": lowercase_bottom["medianSpan"] / lowercase_middle["medianSpan"],
        "topCenter": lowercase_top["normalizedCenter"],
        "bottomCenter": lowercase_bottom["normalizedCenter"],
        "centerShift": (
            lowercase_bottom["normalizedCenter"]
            - lowercase_top["normalizedCenter"]
        ),
    }
    checks = {
        "zeroIsSlashedTwoCounterForm": topology["0"] == {"components": 1, "holes": 2},
        "oneAndLowercaseIUseDifferentComponentStructures": (
            topology["1"] == {"components": 1, "holes": 0}
            and topology["i"] == {"components": 2, "holes": 0}
        ),
        "oneAndLowercaseIAreVisiblyDifferent": one_i["exclusivePixelFraction"] > 0.10,
        "capitalIHasBilateralBars": (
            capital_i_structure["topBarToStemRatio"] > 2.5
            and capital_i_structure["bottomBarToStemRatio"] > 2.5
            and abs(capital_i_structure["topCenter"] - 0.5) < 0.08
            and abs(capital_i_structure["bottomCenter"] - 0.5) < 0.08
        ),
        "lowercaseLHasNoTerminalBars": (
            lowercase_l_structure["topBarToStemRatio"] < 1.15
            and lowercase_l_structure["bottomBarToStemRatio"] < 1.15
        ),
        "capitalIAndLowercaseLAreVisiblyDifferent": (
            capital_i_l["exclusivePixelFraction"] > 0.10
        ),
        "lowercaseLAndPipeHaveDifferentVerticalExtent": (
            tight(masks["|"]).shape[0] > tight(masks["l"]).shape[0] * 1.15
        ),
    }
    specimen = PROJECT / "specimens" / "disambiguation-01iIl.png"
    render_specimen(masks, specimen)
    return {
        "characters": list(CHARACTERS),
        "geometry": {
            character: str(path.relative_to(PROJECT))
            for character, path in paths.items()
        },
        "topology": topology,
        "shapeDifference": {"1/i": one_i, "I/l": capital_i_l, "l/pipe": lowercase_l_pipe},
        "capitalIStructure": capital_i_structure,
        "lowercaseLStructure": lowercase_l_structure,
        "checks": checks,
        "passed": all(checks.values()),
        "visualReview": {
            "status": "passes_current_specimen",
            "zero": "slash ends visibly inside the ring in the rendered specimen",
            "authority": "rendered specimen, not the intended geometric rule",
        },
        "specimen": str(specimen.relative_to(PROJECT)),
    }


def main() -> None:
    report = audit()
    output = PROJECT / "reports" / "disambiguation-audit.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    print(output)
    if not report["passed"]:
        raise SystemExit("Character disambiguation audit failed")


if __name__ == "__main__":
    main()
