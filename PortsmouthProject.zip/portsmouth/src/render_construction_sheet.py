#!/usr/bin/env python3
"""Render vertically normalized source glyphs for topology review."""

from __future__ import annotations

from pathlib import Path
import unicodedata

from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "portsmouth" / "specimens"
SOURCES = (
    ("AnnotationMono-VF.ttf", "Annotation Mono"),
    ("ComicShannsMono-Regular.ttf", "Comic Shanns Mono"),
    ("SyneMono-Regular.ttf", "Syne Mono"),
    ("bedstead.otf", "Bedstead"),
    ("routed-gothic.ttf", "Routed Gothic"),
)


def source_applies(filename: str, glyph: str) -> bool:
    category = unicodedata.category(glyph)
    if filename == "SyneMono-Regular.ttf":
        return category == "Lu"
    if filename == "bedstead.otf":
        return category == "Ll"
    return True


def landmark_height(path: Path, glyph: str) -> tuple[int, int, str]:
    font = TTFont(path, lazy=True)
    upm = font["head"].unitsPerEm
    os2 = font.get("OS/2")
    is_capital = glyph.isalpha() and glyph.upper() == glyph
    field = "sCapHeight" if is_capital else "sxHeight"
    reference = "H" if is_capital else "x"
    label = "cap height" if is_capital else "x-height"
    value = getattr(os2, field, 0) if os2 is not None else 0
    if not value:
        glyph_set = font.getGlyphSet()
        from fontTools.pens.boundsPen import BoundsPen
        reference_glyph = glyph_set[font.getBestCmap()[ord(reference)]]
        pen = BoundsPen(glyph_set)
        reference_glyph.draw(pen)
        value = pen.bounds[3]
    font.close()
    return upm, int(value), label


def main(glyph: str = "m") -> None:
    width, height = 1680, 1050
    image = Image.new("RGB", (width, height), "#f2eee5")
    draw = ImageDraw.Draw(image)
    title_font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 36)
    label_font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 22)
    small_font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 17)
    draw.text((70, 42), f"Portsmouth construction study — {glyph}", fill="#151515", font=title_font)
    capital = glyph.isalpha() and glyph.upper() == glyph
    landmark_label = "cap height" if capital else "x-height"
    draw.text((70, 92), f"Equal baseline and {landmark_label}; natural horizontal proportions preserved", fill="#55514a", font=small_font)

    tile_w, tile_h = 370, 390
    x_positions = (70, 480, 890, 1300)
    y_positions = (150, 570)
    target_height = 230
    active_sources = [
        source for source in SOURCES if source_applies(source[0], glyph)
    ]
    for index, (filename, label) in enumerate(active_sources):
        col, row = index % 4, index // 4
        left, top = x_positions[col], y_positions[row]
        baseline = top + 300
        path = ROOT / filename
        upm, source_height, _ = landmark_height(path, glyph)
        pixel_size = round(target_height * upm / source_height)
        face = ImageFont.truetype(path, pixel_size)
        bbox = draw.textbbox((0, baseline), glyph, font=face, anchor="ls")
        glyph_width = bbox[2] - bbox[0]
        origin_x = left + (tile_w - glyph_width) / 2 - bbox[0]

        draw.rounded_rectangle((left, top, left + tile_w, top + tile_h), radius=12, fill="#fffdf8", outline="#d4cec2", width=2)
        draw.line((left + 24, baseline, left + tile_w - 24, baseline), fill="#d7513c", width=2)
        draw.line((left + 24, baseline - target_height, left + tile_w - 24, baseline - target_height), fill="#4e78a0", width=2)
        draw.text((origin_x, baseline), glyph, font=face, fill="#111111", anchor="ls")
        draw.text((left + 18, top + 18), label, fill="#151515", font=label_font)
        draw.text((left + 18, top + 49), f"{filename} · {glyph_width:.0f}px wide", fill="#625e57", font=small_font)

    draw.text((1300, 640), f"blue  {landmark_label}", fill="#4e78a0", font=small_font)
    draw.text((1300, 667), "red   baseline", fill="#d7513c", font=small_font)
    OUT.mkdir(parents=True, exist_ok=True)
    image.save(OUT / f"construction-{ord(glyph):04x}.png")


if __name__ == "__main__":
    main()
