#!/usr/bin/env python3
"""Render every available source @, distinguishing route from reference."""

from __future__ import annotations

import math

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    active = {source.filename for source in engine.active_sources("@")}
    entries = []
    for source in engine.sources:
        if ord("@") not in source.cmap:
            continue
        field = engine.source_field(source, "@")
        entries.append((source, field.mask, engine.topology(field.mask)))
    tile_width, tile_height, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_width, 155 + rows * tile_height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), "Portsmouth @ — every source drawing", fill="#111", font=title)
    draw.text((40, 78), "three routed contributors · Syne Mono and Bedstead shown as design references", fill="#575149", font=small)
    for index, (source, mask, topology) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_width, 120 + row * tile_height
        routed = source.filename in active
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_width - 20, y0 + tile_height - 20),
            radius=10,
            fill="#fffdf8",
            outline="#b8513e" if routed else "#aaa39a",
            width=3 if routed else 2,
        )
        image = _render_mask(mask, (tile_width - 70, tile_height - 120))
        canvas.paste(image, (x0 + (tile_width - 20 - image.width) // 2, y0 + 70 + (tile_height - 120 - image.height) // 2))
        draw.text((x0 + 15, y0 + 15), source.family, fill="#151515", font=label)
        route = "ROUTED · equal ⅓" if routed else "REFERENCE ONLY · weight 0"
        draw.text((x0 + 15, y0 + 42), route, fill="#b13f31" if routed else "#655f57", font=small)
        draw.text((x0 + 15, y0 + tile_height - 55), f"{topology['components']} component · {topology['holes']} hole(s)", fill="#655f57", font=small)
    output = PROJECT / "specimens" / "at-all-sources.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
