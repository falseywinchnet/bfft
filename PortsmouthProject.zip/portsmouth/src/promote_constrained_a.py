#!/usr/bin/env python3
"""Promote approved selected a/q/æ while retaining former geometry."""

from __future__ import annotations

import argparse
import json
import shutil

import numpy as np

from portsmouth_engine import PROJECT


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("character", nargs="?", choices=("a", "q", "æ"), default="a")
    arguments = parser.parse_args()
    character = arguments.character
    stem = f"{ord(character):04x}"
    current_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
    current_report = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
    baseline_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}-pre-one-storey.npz"
    baseline_report = PROJECT / "reports" / f"multicontour-trace-{stem}-pre-one-storey.json"
    candidate_geometry = PROJECT / "geometry" / f"constrained-{character}-{stem}.npz"
    candidate_report_path = PROJECT / "reports" / f"constrained-{character}-{stem}.json"
    candidate_report = json.loads(candidate_report_path.read_text())
    if not baseline_geometry.exists():
        shutil.copy2(current_geometry, baseline_geometry)
    if not baseline_report.exists():
        shutil.copy2(current_report, baseline_report)
    with np.load(candidate_geometry, allow_pickle=False) as archive:
        arrays = {
            key: archive[key].astype(np.float32)
            for key in archive.files if key not in {"character", "unitsPerEm"}
        }
        arrays["character"] = np.asarray(character)
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(current_geometry, **arrays)
    report = {
        "character": character,
        "status": f"experimental_user_directed_one_storey_{character}",
        "designConstraint": candidate_report["designConstraint"],
        "pipeline": candidate_report["pipeline"],
        "sources": candidate_report["sources"],
        "excludedSources": candidate_report["excludedSources"],
        "equalSourceWeight": candidate_report["equalSourceWeight"],
        "targetAdvance": candidate_report["targetAdvance"],
        "pointsPerSourceContour": candidate_report["pointsPerContour"],
        "expectedTopology": candidate_report["expectedTopology"],
        "outputTopology": candidate_report["outputTopology"],
        "candidateReport": str(candidate_report_path.relative_to(PROJECT)),
        "baselineGeometry": str(baseline_geometry.relative_to(PROJECT)),
        "baselineReport": str(baseline_report.relative_to(PROJECT)),
        "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
        "visualReview": (
            "Accepted one-storey construction; slight Syne-derived shoulder facet retained for running-text review."
            if character == "a"
            else "Accepted one-storey bowl and clean straight descender; no hook, wedge, or pinched join."
            if character == "q"
            else "Accepted joined a/e body with two open counters and no congested seam."
        ),
    }
    current_report.write_text(json.dumps(report, indent=2) + "\n")
    candidate_report["status"] = f"experimental_promoted_one_storey_{character}"
    candidate_report["replacesCurrentGeometry"] = True
    candidate_report["visualReview"] = report["visualReview"]
    candidate_report_path.write_text(json.dumps(candidate_report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
