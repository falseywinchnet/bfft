#!/usr/bin/env python3
"""Render all 78 extended majority candidates on one acceptance sheet."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


PREFIX = "extended-majority-candidate"


def selected_prefix(codepoint: int) -> str:
    composed = PROJECT / "geometry" / f"extended-composed-candidate-{codepoint:04x}.npz"
    return "extended-composed-candidate" if composed.exists() else PREFIX


def contours(codepoint: int):
    prefix = selected_prefix(codepoint)
    with np.load(
        PROJECT / "geometry" / f"{prefix}-{codepoint:04x}.npz",
        allow_pickle=False,
    ) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files if key not in {"character", "unitsPerEm"}
        ]


def main() -> None:
    audit = json.loads(
        (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
    )
    candidates = [
        entry for entry in audit["entries"]
        if entry["compatiblePersistentTopology"] and not entry["production"]
    ]
    missing = [
        entry["codepoint"] for entry in candidates
        if not (
            PROJECT / "geometry"
            / f"{selected_prefix(ord(entry['character']))}-{ord(entry['character']):04x}.npz"
        ).exists()
    ]
    if missing:
        raise ValueError(f"Candidate geometry is incomplete: {missing}")
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    columns, tile_width, tile_height = 8, 245, 285
    rows = math.ceil(len(candidates) / columns)
    canvas = Image.new(
        "RGB", (50 + columns * tile_width, 145 + rows * tile_height), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 17)
    small = ImageFont.truetype(ui, 12)
    draw.text((30, 24), "Portsmouth — 78 extended majority candidates", fill="#111", font=title)
    draw.text(
        (30, 74),
        "10,240 points per contour per source · project case routing · equal weight within routed source set",
        fill="#5e5850", font=small,
    )
    for index, entry in enumerate(candidates):
        codepoint = ord(entry["character"])
        prefix = selected_prefix(codepoint)
        report = json.loads(
            (PROJECT / "reports" / f"{prefix}-{codepoint:04x}.json").read_text()
        )
        column, row = index % columns, index // columns
        x0, y0 = 25 + column * tile_width, 115 + row * tile_height
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_width - 15, y0 + tile_height - 15),
            radius=9, fill="#fffdf8", outline="#cec7bb", width=1,
        )
        draw.text(
            (x0 + 12, y0 + 10),
            f"{entry['character']}  {entry['codepoint']}",
            fill="#171715", font=label,
        )
        draw.text(
            (x0 + 12, y0 + 35),
            (
                f"composed · {report['outputTopology']}"
                if prefix == "extended-composed-candidate"
                else f"{len(report['sources'])} routed source(s) · {report['outputTopology']}"
            ),
            fill="#6a6259", font=small,
        )
        mask = rasterize_contour_complex(engine, contours(codepoint))
        glyph = _render_mask(mask, (175, 185))
        canvas.paste(
            glyph,
            (x0 + (tile_width - 15 - glyph.width) // 2, y0 + 70),
        )
    output = PROJECT / "specimens" / "extended-majority-candidates-0.103.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
