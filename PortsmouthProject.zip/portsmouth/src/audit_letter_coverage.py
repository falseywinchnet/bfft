#!/usr/bin/env python3
"""Audit archived and topology-conflicting letters in Portsmouth's shared cmap."""

from __future__ import annotations

import json
import unicodedata

from portsmouth_engine import EikonalMidpointEngine, PROJECT


def geometry_for(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            return prefix, path
    return None, None


def audit() -> dict:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    shared = set.intersection(*(set(source.cmap) for source in engine.sources))
    archived = []
    conflicts = []
    compatible_missing = []
    for codepoint in sorted(shared):
        character = chr(codepoint)
        if not unicodedata.category(character).startswith("L"):
            continue
        fields = [
            engine.source_field(source, character)
            for source in engine.active_sources(character)
        ]
        topologies = {
            field.source.filename: engine.topology(field.mask) for field in fields
        }
        values = list(topologies.values())
        consensus = all(value == values[0] for value in values[1:])
        prefix, geometry_path = geometry_for(character)
        entry = {
            "character": character,
            "codepoint": f"U+{codepoint:04X}",
            "name": unicodedata.name(character, "UNKNOWN"),
            "sourceTopology": topologies,
        }
        if geometry_path is not None:
            report_path = PROJECT / "reports" / f"{prefix}-{codepoint:04x}.json"
            report = json.loads(report_path.read_text())
            entry.update({
                "geometry": str(geometry_path.relative_to(PROJECT)),
                "report": str(report_path.relative_to(PROJECT)),
                "status": report["status"],
            })
            archived.append(entry)
        elif not consensus:
            conflicts.append(entry)
        else:
            compatible_missing.append(entry)
    return {
        "sharedLetterCount": len(archived) + len(conflicts) + len(compatible_missing),
        "archivedLetterCount": len(archived),
        "topologyConflictCount": len(conflicts),
        "topologyCompatibleMissingCount": len(compatible_missing),
        "archived": archived,
        "topologyConflicts": conflicts,
        "topologyCompatibleMissing": compatible_missing,
    }


def main() -> None:
    report = audit()
    output = PROJECT / "reports" / "letter-coverage-audit.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if not isinstance(value, list)}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
