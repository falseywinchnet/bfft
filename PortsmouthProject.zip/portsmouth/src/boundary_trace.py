#!/usr/bin/env python3
"""Ordered dense boundary clouds and elastic equal-weight tracing."""

from __future__ import annotations

from dataclasses import dataclass

import contourpy
import numpy as np
from PIL import Image, ImageDraw
from scipy.spatial import cKDTree

from medial_transport import MedialMeasure
from portsmouth_engine import EikonalMidpointEngine, GlyphField
from transport_barycenter import TransportBarycenter
from vectorize import signed_area


@dataclass
class BoundaryCloud:
    source: str
    points: np.ndarray
    median_anchor: np.ndarray


def _normalized_phase_features(cloud: BoundaryCloud) -> np.ndarray:
    """Dimensionless contour features used only to choose a cyclic gauge."""
    points = cloud.points - np.mean(cloud.points, axis=0)
    point_scale = max(float(np.sqrt(np.mean(np.sum(points ** 2, axis=1)))), 1.0)
    points /= point_scale
    anchors = cloud.median_anchor - np.mean(cloud.median_anchor, axis=0)
    anchor_scale = max(float(np.sqrt(np.mean(np.sum(anchors ** 2, axis=1)))), 1.0)
    anchors /= anchor_scale
    return np.hstack((points, 0.45 * anchors))


def _best_cyclic_shift(reference: np.ndarray, source: np.ndarray) -> tuple[int, float]:
    """Find the full-resolution phase with a coarse search and local refinement."""
    count = len(reference)
    probe_count = min(512, count)
    probe_index = np.linspace(0, count, probe_count, endpoint=False, dtype=np.int64)
    reference_probe = reference[probe_index]
    source_probe = source[probe_index]
    probe_costs = np.empty(probe_count, dtype=np.float64)
    for shift in range(probe_count):
        delta = reference_probe - np.roll(source_probe, -shift, axis=0)
        probe_costs[shift] = np.mean(np.sum(delta ** 2, axis=1))
    coarse_shift = int(np.argmin(probe_costs))
    center = int(round(coarse_shift * count / probe_count))
    radius = max(2, int(np.ceil(count / probe_count)))
    candidates = np.arange(center - radius, center + radius + 1, dtype=np.int64)
    costs = []
    for shift in candidates:
        delta = reference - np.roll(source, -int(shift), axis=0)
        costs.append(float(np.mean(np.sum(delta ** 2, axis=1))))
    winner = int(np.argmin(costs))
    return int(candidates[winner] % count), float(costs[winner])


def _phase_align_clouds(clouds: list[BoundaryCloud]) -> tuple[list[BoundaryCloud], dict]:
    """Choose a cyclic seam jointly, without assigning geometric weight to a source."""
    features = [_normalized_phase_features(cloud) for cloud in clouds]
    # Pick the lowest-total-cost gauge. The gauge only fixes the array seam; the
    # resulting coordinates remain an equal-weight mean of every source.
    candidate_costs = []
    candidate_shifts = []
    for reference_index, reference in enumerate(features):
        shifts = []
        total = 0.0
        for source in features:
            shift, cost = _best_cyclic_shift(reference, source)
            shifts.append(shift)
            total += cost
        candidate_costs.append(total)
        candidate_shifts.append(shifts)
    gauge = int(np.argmin(candidate_costs))
    shifts = candidate_shifts[gauge]
    aligned = [
        BoundaryCloud(
            source=cloud.source,
            points=np.roll(cloud.points, -shift, axis=0),
            median_anchor=np.roll(cloud.median_anchor, -shift, axis=0),
        )
        for cloud, shift in zip(clouds, shifts)
    ]
    return aligned, {
        "operator": "equal_source_cyclic_phase_synchronization",
        "gaugeSource": clouds[gauge].source,
        "shifts": {cloud.source: int(shift) for cloud, shift in zip(clouds, shifts)},
        "candidateCosts": {
            cloud.source: float(cost) for cloud, cost in zip(clouds, candidate_costs)
        },
    }


def _largest_contour(
    engine: EikonalMidpointEngine, mask: np.ndarray
) -> np.ndarray:
    x = engine.x_min + (
        np.arange(engine.width, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit
    y = engine.y_min + (
        np.arange(engine.height, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit
    generator = contourpy.contour_generator(
        x=x, y=y, z=mask[::-1].astype(np.float64)
    )
    contours = [np.asarray(line) for line in generator.lines(0.5)]
    if not contours:
        raise ValueError("No boundary contour found")
    contour = max(contours, key=lambda value: abs(signed_area(value)))
    if len(contour) > 1 and np.allclose(contour[0], contour[-1]):
        contour = contour[:-1]
    if signed_area(contour) < 0.0:
        contour = contour[::-1]
    return contour


def _canonical_start(points: np.ndarray) -> np.ndarray:
    """Start at the lower-left foot, a stable location for Latin letters."""
    minimum_y = float(np.min(points[:, 1]))
    maximum_y = float(np.max(points[:, 1]))
    low = points[:, 1] <= minimum_y + 0.06 * max(maximum_y - minimum_y, 1.0)
    candidates = np.flatnonzero(low)
    start = int(candidates[np.argmin(points[candidates, 0])])
    return np.vstack((points[start:], points[:start]))


def resample_closed(points: np.ndarray, count: int) -> np.ndarray:
    points = _canonical_start(points)
    closed = np.vstack((points, points[0]))
    length = np.linalg.norm(np.diff(closed, axis=0), axis=1)
    cumulative = np.concatenate(([0.0], np.cumsum(length)))
    if cumulative[-1] <= 0.0:
        raise ValueError("Degenerate contour")
    targets = np.linspace(0.0, cumulative[-1], count, endpoint=False)
    result = np.empty((count, 2), dtype=np.float64)
    for dimension in range(2):
        result[:, dimension] = np.interp(
            targets, cumulative, closed[:, dimension]
        )
    return result


def contour_relation_signature(
    points: np.ndarray, relation_contour: np.ndarray
) -> np.ndarray:
    """Clearance and local-direction relation from one loop to another."""
    relation = resample_closed(relation_contour, len(points))
    nearest = cKDTree(relation).query(points, k=1)[1]
    vectors = relation[nearest] - points
    tangent = np.roll(points, -1, axis=0) - np.roll(points, 1, axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-9)
    normal = np.column_stack((-tangent[:, 1], tangent[:, 0]))
    return np.column_stack((
        np.linalg.norm(vectors, axis=1),
        np.sum(vectors * tangent, axis=1),
        np.sum(vectors * normal, axis=1),
    ))


def boundary_cloud(
    engine: EikonalMidpointEngine,
    field: GlyphField,
    measure: MedialMeasure,
    median: TransportBarycenter,
    plan: np.ndarray,
    *,
    count: int = 1024,
    source_contour: np.ndarray | None = None,
    relation_contour: np.ndarray | None = None,
) -> BoundaryCloud:
    """Trace one source and attach every ordered point to the median graph."""
    contour = (
        _largest_contour(engine, field.mask)
        if source_contour is None else np.asarray(source_contour)
    )
    points = resample_closed(contour, count)
    permutation = np.argmax(plan, axis=1)  # median -> source
    inverse = np.empty(len(permutation), dtype=np.int64)
    inverse[permutation] = np.arange(len(permutation))
    source_anchor = cKDTree(measure.support[:, :2]).query(points, k=1)[1]
    median_index = inverse[source_anchor]
    median_anchor = median.support[median_index, :2]
    if relation_contour is not None:
        # Hole correspondence now sees how its source counter sits relative to
        # the outer body. This couples a Q-like tail intrusion without merging
        # or inflating either contour.
        median_anchor = np.hstack((
            median_anchor,
            0.75 * contour_relation_signature(points, relation_contour),
        ))
    return BoundaryCloud(
        source=field.source.filename,
        points=points,
        median_anchor=median_anchor,
    )


def _fill_missing(values: np.ndarray, present: np.ndarray) -> np.ndarray:
    if np.all(present):
        return values
    indices = np.arange(len(values))
    known = indices[present]
    if not len(known):
        raise ValueError("DTW produced no correspondence")
    extended_x = np.concatenate((known - len(values), known, known + len(values)))
    result = values.copy()
    for dimension in range(values.shape[1]):
        extended_y = np.tile(values[present, dimension], 3)
        result[:, dimension] = np.interp(indices, extended_x, extended_y)
    return result


def _dtw_align(
    reference: np.ndarray,
    reference_anchor: np.ndarray,
    cloud: BoundaryCloud,
    *,
    band: int,
    warp_penalty: float = 0.025,
) -> tuple[np.ndarray, np.ndarray, float, np.ndarray]:
    """Monotone contour correspondence; it can never jump across the loop."""
    source = cloud.points
    source_anchor = cloud.median_anchor
    count = len(reference)
    infinity = np.inf
    cost = np.full((count + 1, count + 1), infinity, dtype=np.float64)
    pointer = np.zeros((count + 1, count + 1), dtype=np.uint8)
    cost[0, 0] = 0.0
    for i in range(1, count + 1):
        j0 = max(1, i - band)
        j1 = min(count, i + band)
        for j in range(j0, j1 + 1):
            spatial = np.sum((reference[i - 1] - source[j - 1]) ** 2) / 90000.0
            anchor = np.sum(
                (reference_anchor[i - 1] - source_anchor[j - 1]) ** 2
            ) / 40000.0
            choices = (
                cost[i - 1, j - 1],
                cost[i - 1, j] + warp_penalty,
                cost[i, j - 1] + warp_penalty,
            )
            move = int(np.argmin(choices))
            cost[i, j] = spatial + 0.55 * anchor + choices[move]
            pointer[i, j] = move
    i = j = count
    pairs = []
    while i > 0 and j > 0:
        pairs.append((i - 1, j - 1))
        move = int(pointer[i, j])
        if move == 0:
            i -= 1
            j -= 1
        elif move == 1:
            i -= 1
        else:
            j -= 1
    aligned = np.zeros_like(reference)
    aligned_anchor = np.zeros_like(reference_anchor)
    population = np.zeros(count, dtype=np.int32)
    mapping = np.zeros(count, dtype=np.float64)
    for reference_index, source_index in pairs:
        aligned[reference_index] += source[source_index]
        aligned_anchor[reference_index] += source_anchor[source_index]
        mapping[reference_index] += source_index
        population[reference_index] += 1
    present = population > 0
    aligned[present] /= population[present, None]
    aligned_anchor[present] /= population[present, None]
    mapping[present] /= population[present]
    mapping_filled = _fill_missing(mapping[:, None], present)[:, 0]
    return (
        _fill_missing(aligned, present),
        _fill_missing(aligned_anchor, present),
        float(cost[count, count] / count),
        mapping_filled,
    )


def annealed_boundary_barycenter(
    clouds: list[BoundaryCloud],
    *,
    bands: tuple[int, ...] = (144, 104, 72, 48, 28, 16),
    _phase_aligned: bool = False,
) -> tuple[np.ndarray, dict]:
    """Anneal ordered source contours into one equal-weight traced contour."""
    phase_info = None
    if not _phase_aligned:
        clouds, phase_info = _phase_align_clouds(clouds)
    count = len(clouds[0].points)
    if count > 2048:
        coarse_count = 1024
        coarse_index = np.linspace(
            0, count, coarse_count, endpoint=False, dtype=np.int64
        )
        coarse_clouds = [BoundaryCloud(
            source=cloud.source,
            points=cloud.points[coarse_index],
            median_anchor=cloud.median_anchor[coarse_index],
        ) for cloud in clouds]
        coarse, detail = annealed_boundary_barycenter(
            coarse_clouds, bands=bands, _phase_aligned=True
        )
        coarse_anchor = np.mean(
            [cloud.median_anchor for cloud in coarse_clouds], axis=0
        )
        full_indices = np.arange(count, dtype=np.float64)
        coarse_positions = np.linspace(0.0, count, coarse_count, endpoint=False)
        aligned_full = []
        for cloud, coarse_cloud in zip(clouds, coarse_clouds):
            _, _, _, mapping = _dtw_align(
                coarse, coarse_anchor, coarse_cloud, band=bands[-1]
            )
            unwrapped = np.maximum.accumulate(mapping)
            mapping_full = np.interp(
                full_indices,
                np.append(coarse_positions, count),
                np.append(unwrapped * count / coarse_count, count),
            )
            lower = np.floor(mapping_full).astype(np.int64) % count
            fraction = mapping_full - np.floor(mapping_full)
            upper = (lower + 1) % count
            aligned_full.append(
                (1.0 - fraction[:, None]) * cloud.points[lower]
                + fraction[:, None] * cloud.points[upper]
            )
        result = np.mean(aligned_full, axis=0)
        result += 0.018 * (
            np.roll(result, 1, axis=0)
            + np.roll(result, -1, axis=0)
            - 2.0 * result
        )
        detail["drawingPoints"] = count
        detail["correspondencePoints"] = coarse_count
        detail["hierarchicalUpsampling"] = True
        if phase_info is not None:
            detail["cyclicPhase"] = phase_info
        return result, detail

    reference = np.mean([cloud.points for cloud in clouds], axis=0)
    reference_anchor = np.mean([cloud.median_anchor for cloud in clouds], axis=0)
    trace = []
    previous_objective = np.inf
    previous_displacement = np.inf
    for stage, band in enumerate(bands, start=1):
        aligned_points = []
        aligned_anchors = []
        objectives = []
        for cloud in clouds:
            points, anchors, objective, _mapping = _dtw_align(
                reference, reference_anchor, cloud, band=band
            )
            aligned_points.append(points)
            aligned_anchors.append(anchors)
            objectives.append(objective)
        candidate = np.mean(aligned_points, axis=0)
        # A very small periodic membrane step removes sampling chatter while
        # retaining corners and, crucially, the ordered contour itself.
        smoothing = 0.035 * band / bands[0]
        candidate += smoothing * (
            np.roll(candidate, 1, axis=0)
            + np.roll(candidate, -1, axis=0)
            - 2.0 * candidate
        )
        displacement = float(np.sqrt(np.mean(np.sum(
            (candidate - reference) ** 2, axis=1
        ))))
        mean_objective = float(np.mean(objectives))
        destabilized = (
            stage > 1
            and mean_objective > previous_objective * 1.005
            and displacement > max(previous_displacement * 2.0, 0.5)
        )
        if not destabilized:
            reference = candidate
            reference_anchor = np.mean(aligned_anchors, axis=0)
            previous_objective = mean_objective
            previous_displacement = displacement
        trace.append({
            "stage": stage,
            "band": band,
            "meanObjective": mean_objective,
            "rmsDisplacement": displacement,
            "accepted": not destabilized,
        })
    detail = {
        "operator": "ordered_boundary_dtw_annealing",
        "drawingPoints": count,
        "correspondencePoints": count,
        "hierarchicalUpsampling": False,
        "trace": trace,
    }
    if phase_info is not None:
        detail["cyclicPhase"] = phase_info
    return reference, detail


def rasterize_contour(
    engine: EikonalMidpointEngine, contour: np.ndarray
) -> np.ndarray:
    image = Image.new("1", (engine.width, engine.height), 0)
    points = [
        (
            float((x - engine.x_min) * engine.pixels_per_unit - 0.5),
            float((engine.y_max - y) * engine.pixels_per_unit - 0.5),
        )
        for x, y in contour
    ]
    ImageDraw.Draw(image).polygon(points, fill=1)
    return np.asarray(image, dtype=bool)


def rasterize_contour_complex(
    engine: EikonalMidpointEngine,
    contours: list[tuple[str, np.ndarray]],
) -> np.ndarray:
    """Trace filled components first and subtract their paired counter paths."""
    image = Image.new("1", (engine.width, engine.height), 0)
    draw = ImageDraw.Draw(image)
    for role in ("outer", "hole"):
        fill = 1 if role == "outer" else 0
        for contour_role, contour in contours:
            if contour_role != role:
                continue
            points = [
                (
                    float((x - engine.x_min) * engine.pixels_per_unit - 0.5),
                    float((engine.y_max - y) * engine.pixels_per_unit - 0.5),
                )
                for x, y in contour
            ]
            draw.polygon(points, fill=fill)
    return np.asarray(image, dtype=bool)
