#!/usr/bin/env python3
"""Audit the canonical Portsmouth family faces, topology, flags, and Mono metrics."""

from __future__ import annotations

import json

import numpy as np
from fontTools.ttLib import TTCollection, TTFont
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

from portsmouth_engine import PROJECT
from build_portsmouth_family import FAMILY_VERSION, ITALIC_ANGLE


PATHS = {
    "regular": PROJECT / "build" / "family" / "Portsmouth.ttf",
    "light": PROJECT / "build" / "family" / "Portsmouth-Light.ttf",
    "italic": PROJECT / "build" / "family" / "Portsmouth-Italic.ttf",
    "bold": PROJECT / "build" / "family" / "Portsmouth-Bold.ttf",
    "bold_italic": PROJECT / "build" / "family" / "Portsmouth-BoldItalic.ttf",
    "mono": PROJECT / "build" / "mono" / "PortsmouthMono.ttf",
}
MINIMUM_PERSISTENT_HOLE_AREA = 16


def render(font, character: str) -> np.ndarray:
    image = Image.new("L", (1700, 1600), 0)
    ImageDraw.Draw(image).text((420, 250), character, fill=255, font=font)
    return np.asarray(image) >= 128


def topology(mask: np.ndarray) -> dict[str, int]:
    structure = np.ones((3, 3), dtype=np.uint8)
    _, components = ndimage.label(mask, structure=structure)
    background, count = ndimage.label(~mask, structure=structure)
    border = set(map(int, np.unique(np.concatenate((
        background[0], background[-1], background[:, 0], background[:, -1]
    )))))
    holes = sum(
        label not in border and int(np.count_nonzero(background == label)) >= MINIMUM_PERSISTENT_HOLE_AREA
        for label in range(1, count + 1)
    )
    return {"components": int(components), "holes": int(holes)}


def main() -> None:
    fonts = {key: TTFont(path, lazy=False, recalcBBoxes=True) for key, path in PATHS.items()}
    raster_fonts = {key: ImageFont.truetype(path, 1000) for key, path in PATHS.items()}
    cmaps = {key: font.getBestCmap() for key, font in fonts.items()}
    codepoints = sorted(cmaps["regular"])
    structural = []
    for key, cmap in cmaps.items():
        if sorted(cmap) != codepoints:
            structural.append(f"{key} cmap differs from Regular")
    expected_names = {
        "regular": ("Portsmouth", "Regular"),
        "light": ("Portsmouth", "Light"),
        "italic": ("Portsmouth", "Italic"),
        "bold": ("Portsmouth", "Bold"),
        "bold_italic": ("Portsmouth", "Bold Italic"),
        "mono": ("Portsmouth Mono", "Regular"),
    }
    for key, (family, style) in expected_names.items():
        if fonts[key]["name"].getDebugName(1) != family or fonts[key]["name"].getDebugName(2) != style:
            structural.append(f"{key} name table mismatch")
    if fonts["light"]["OS/2"].usWeightClass != 300:
        structural.append("Light does not declare OS/2 weight class 300")
    if fonts["light"]["OS/2"].fsSelection & 0x40:
        structural.append("Light is incorrectly flagged as Regular")
    mono_widths = set(width for width, _ in fonts["mono"]["hmtx"].metrics.values())
    if mono_widths != {575} or fonts["mono"]["post"].isFixedPitch != 1:
        structural.append("Mono is not uniformly fixed at 575")
    expected_caret_run = int(round(np.tan(np.radians(ITALIC_ANGLE)) * 1000.0))
    for key in ("italic", "bold_italic"):
        if not np.isclose(fonts[key]["post"].italicAngle, -ITALIC_ANGLE):
            structural.append(f"{key} post italic angle differs from {-ITALIC_ANGLE:g}")
        if fonts[key]["hhea"].caretSlopeRun != expected_caret_run:
            structural.append(f"{key} caret slope differs from {ITALIC_ANGLE:g} degrees")

    bold_report = json.loads((PROJECT / "reports" / f"family-bold-{FAMILY_VERSION}.json").read_text())
    bold_expected = {
        int(value["codepoint"][2:], 16): value["transform"]["outputTopology"]
        for value in bold_report["glyphs"]
    }
    topology_mismatches = []
    area_failures = []
    light_area_failures = []
    for cp in codepoints:
        # Soft hyphen is deliberately suppressed by shaping/rendering unless a
        # discretionary break requests its stored hyphen outline.
        if cp in {0x20, 0xA0, 0xAD}:
            continue
        character = chr(cp)
        masks = {key: render(font, character) for key, font in raster_fonts.items()}
        topologies = {key: topology(mask) for key, mask in masks.items()}
        for key in ("light", "italic", "mono"):
            if topologies[key] != topologies["regular"]:
                topology_mismatches.append({
                    "codepoint": f"U+{cp:04X}", "character": character,
                    "face": key, "expected": topologies["regular"], "actual": topologies[key],
                })
        if topologies["bold"] != bold_expected[cp]:
            topology_mismatches.append({
                "codepoint": f"U+{cp:04X}", "character": character,
                "face": "bold", "expected": bold_expected[cp], "actual": topologies["bold"],
            })
        if topologies["bold_italic"] != topologies["bold"]:
            topology_mismatches.append({
                "codepoint": f"U+{cp:04X}", "character": character,
                "face": "bold_italic", "expected": topologies["bold"], "actual": topologies["bold_italic"],
            })
        if np.sum(masks["bold"]) <= np.sum(masks["regular"]):
            area_failures.append(f"U+{cp:04X}")
        if np.sum(masks["light"]) >= np.sum(masks["regular"]):
            light_area_failures.append(f"U+{cp:04X}")

    collection = TTCollection(PROJECT / "build" / "family" / "Portsmouth-Family.ttc")
    collection_faces = len(collection.fonts)
    for font in collection.fonts:
        font.close()
    report = {
        "faces": {key: str(path.relative_to(PROJECT)) for key, path in PATHS.items()},
        "encodedCharactersPerFace": len(codepoints),
        "structuralFailures": structural,
        "topologyMismatches": topology_mismatches,
        "boldAreaFailures": area_failures,
        "lightAreaFailures": light_area_failures,
        "monoAdvanceWidths": sorted(mono_widths),
        "italicAngleDegrees": ITALIC_ANGLE,
        "minimumPersistentHoleAreaPixels": MINIMUM_PERSISTENT_HOLE_AREA,
        "collectionFaces": collection_faces,
        "passed": (
            not structural and not topology_mismatches and not area_failures
            and not light_area_failures and collection_faces == 5
        ),
    }
    output = PROJECT / "reports" / f"family-audit-{FAMILY_VERSION}.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    print(output)
    for font in fonts.values():
        font.close()
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
