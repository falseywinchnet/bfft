#!/usr/bin/env python3
"""Audit raster topology and shape agreement for the Makima q2 experiment."""

from __future__ import annotations

import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

from portsmouth_engine import PROJECT


SOURCE = PROJECT / "build" / "Portsmouth-Regular-0.017.ttf"
EXPERIMENT = PROJECT / "build" / "experimental" / "Portsmouth-Quadratic-0.017-makima-q2.ttf"


def render(font, character: str, size: int = 1000) -> np.ndarray:
    image = Image.new("L", (1500, 1500), 0)
    ImageDraw.Draw(image).text((400, 230), character, fill=255, font=font)
    return np.asarray(image) >= 128


def topology(mask: np.ndarray) -> dict[str, int]:
    structure = np.ones((3, 3), dtype=np.uint8)
    _, components = ndimage.label(mask, structure=structure)
    background, count = ndimage.label(~mask, structure=structure)
    border = set(map(int, np.unique(np.concatenate((
        background[0], background[-1], background[:, 0], background[:, -1]
    )))))
    holes = sum(label not in border for label in range(1, count + 1))
    return {"components": int(components), "holes": int(holes)}


def main() -> None:
    source_font = ImageFont.truetype(SOURCE, 1000)
    experiment_font = ImageFont.truetype(EXPERIMENT, 1000)
    from fontTools.ttLib import TTFont
    source_tt = TTFont(SOURCE)
    experiment_tt = TTFont(EXPERIMENT)
    codepoints = sorted(set(source_tt.getBestCmap()) & set(experiment_tt.getBestCmap()))
    source_tt.close()
    experiment_tt.close()
    glyphs = []
    mismatches = []
    for codepoint in codepoints:
        character = chr(codepoint)
        left = render(source_font, character)
        right = render(experiment_font, character)
        left_topology = topology(left)
        right_topology = topology(right)
        union = left | right
        intersection = left & right
        iou = float(np.sum(intersection) / np.sum(union)) if np.any(union) else 1.0
        record = {
            "codepoint": f"U+{codepoint:04X}",
            "character": character,
            "sourceTopology": left_topology,
            "experimentTopology": right_topology,
            "intersectionOverUnion": iou,
        }
        glyphs.append(record)
        if left_topology != right_topology:
            mismatches.append(record)
    worst = sorted(glyphs, key=lambda value: value["intersectionOverUnion"])[:20]
    report = {
        "source": str(SOURCE.relative_to(PROJECT)),
        "experiment": str(EXPERIMENT.relative_to(PROJECT)),
        "renderSizePixels": 1000,
        "glyphsAudited": len(glyphs),
        "topologyMismatches": mismatches,
        "minimumIntersectionOverUnion": min(value["intersectionOverUnion"] for value in glyphs),
        "worstShapeAgreement": worst,
        "passed": not mismatches,
    }
    output = PROJECT / "reports" / "makima-quadratic-audit.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "worstShapeAgreement"}, indent=2))
    print(output)
    if mismatches:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
