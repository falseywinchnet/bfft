#!/usr/bin/env python3
"""Dense fingerprint annealing experiment for Portsmouth lowercase m."""

from __future__ import annotations

import json
from dataclasses import replace

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from dense_fingerprint import (
    anneal_fingerprints,
    blue_noise_centroids,
    density_geometry,
    redraw_from_new_skeleton,
    transport_fingerprint,
)
from medial_transport import (
    disk_envelope,
    intrinsic_graph_barycenter,
    mask_statistics,
    sample_medial_structure,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from transport_barycenter import free_support_barycenter
from structural_fusion import detect_stem_axes


def _mask_image(mask: np.ndarray, skeleton: np.ndarray | None = None) -> Image.Image:
    ys, xs = np.nonzero(mask)
    left, right = max(0, xs.min() - 12), min(mask.shape[1], xs.max() + 13)
    top, bottom = max(0, ys.min() - 12), min(mask.shape[0], ys.max() + 13)
    layer = np.full((bottom - top, right - left, 3), 255, dtype=np.uint8)
    layer[mask[top:bottom, left:right]] = (24, 24, 22)
    if skeleton is not None:
        local = skeleton[top:bottom, left:right]
        local = np.asarray(local, dtype=bool)
        layer[local] = (211, 67, 46)
    return Image.fromarray(layer)


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    fields = [engine.source_field(source, "m") for source in engine.active_sources("m")]
    measures = [sample_medial_structure(engine, field, 128) for field in fields]
    initial = free_support_barycenter(
        [measure.support for measure in measures],
        [measure.mass for measure in measures],
        scale=np.array([500.0, 500.0, 60.0]),
    )
    median, median_info = intrinsic_graph_barycenter(measures, initial)
    permutations = [np.argmax(plan, axis=1) for plan in median.plans]
    median_geodesic = np.mean(np.asarray([
        measure.geodesic[np.ix_(permutation, permutation)]
        for measure, permutation in zip(measures, permutations)
    ]), axis=0)
    _, median_envelope = disk_envelope(engine, median.support)
    from shock_graph import extract
    median_skeleton = extract(
        median_envelope, pixels_per_unit=engine.pixels_per_unit
    ).skeleton
    fingerprints = []
    for index, (field, measure, plan) in enumerate(zip(fields, measures, median.plans)):
        native = blue_noise_centroids(
            engine, field, 2048, seed=0x5054 + index * 104729
        )
        fingerprints.append(transport_fingerprint(
            field, measure, median, plan, native, median_geodesic
        ))
    transported = [fingerprint.transported_points for fingerprint in fingerprints]
    annealed, trace = anneal_fingerprints(fingerprints)
    target_area = int(round(np.mean([np.count_nonzero(field.mask) for field in fields])))
    _, transported_mask = density_geometry(
        engine, transported, target_area, seed_skeleton=median_skeleton
    )
    _, annealed_mask = density_geometry(
        engine, annealed, target_area, seed_skeleton=median_skeleton
    )
    final_mask, new_skeleton, skeleton_atoms = redraw_from_new_skeleton(engine, annealed_mask)
    final_field = replace(
        fields[0], mask=final_mask, sdf=engine.signed_distance(final_mask)
    )
    lower_stem_axes = detect_stem_axes(engine, final_field)

    report = {
        "character": "m",
        "status": "rejected_gap_from_skeleton_inflation",
        "pipeline": [
            "transport_dense_fingerprint_to_median_skeleton",
            "equal_source_neighborhood_annealing",
            "build_new_skeleton_and_radius",
            "merge_new_skeleton_envelope",
        ],
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 1.0 / len(fields),
        "skeletonAttractorAtoms": 128,
        "blueNoiseAtomsPerSource": 2048,
        "annealingPasses": len(trace),
        "medianSkeleton": median_info,
        "transportedDensity": mask_statistics(transported_mask),
        "annealedDensity": mask_statistics(annealed_mask),
        "newSkeletonAtoms": int(len(skeleton_atoms)),
        "finalEnvelope": mask_statistics(final_mask),
        "detectedLowerStemCount": int(len(lower_stem_axes)),
        "detectedLowerStemAxes": list(map(float, lower_stem_axes)),
        "trace": trace,
    }
    (PROJECT / "reports" / "dense-annealing-006d.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )

    entries = [
        (field.source.family, field.mask, None) for field in fields
    ] + [
        ("Transported dense fingerprint", transported_mask, None),
        ("Annealed dense fingerprint", annealed_mask, None),
        ("New annealed skeleton", annealed_mask, new_skeleton),
        ("Redrawn skeleton envelope", final_mask, None),
    ]
    tile_w, tile_h, columns = 370, 380, 4
    rows = 2
    canvas = Image.new("RGB", (70 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 14)
    draw.text((35, 28), "Portsmouth m — dense fingerprint annealing", fill="#111", font=title)
    draw.text(
        (35, 78),
        "2,048 blue-noise centroids/source → median-skeleton frame → neighborhood anneal → new skeleton",
        fill="#575149", font=small,
    )
    for index, (name, mask, skeleton) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 35 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10,
            fill="#fffdf8", outline="#d0cabf", width=2,
        )
        glyph = _mask_image(mask, skeleton)
        glyph.thumbnail((tile_w - 65, tile_h - 105), Image.Resampling.LANCZOS)
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 62 + (tile_h - 105 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        subtitle = "red = newly inferred skeleton" if skeleton is not None else "equal normalized frame"
        draw.text((x0 + 15, y0 + 41), subtitle, fill="#655f57", font=small)
    output = PROJECT / "specimens" / "dense-annealing-006d.png"
    canvas.save(output)
    print(json.dumps({key: value for key, value in report.items() if key != "trace"}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
