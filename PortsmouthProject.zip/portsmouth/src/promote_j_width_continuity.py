#!/usr/bin/env python3
"""Promote the accepted capital-J width-continuity correction."""

from __future__ import annotations

import json
import shutil

from portsmouth_engine import PROJECT


def main() -> None:
    current_geometry = PROJECT / "geometry" / "boundary-trace-004a.npz"
    current_report = PROJECT / "reports" / "boundary-trace-004a.json"
    baseline_geometry = PROJECT / "geometry" / "boundary-trace-004a-pre-width-continuity.npz"
    baseline_report = PROJECT / "reports" / "boundary-trace-004a-pre-width-continuity.json"
    candidate_geometry = PROJECT / "geometry" / "terminal-repair-004a-width-continuous.npz"
    candidate_report = PROJECT / "reports" / "terminal-repair-004a-width-continuous.json"
    if not baseline_geometry.exists():
        shutil.copy2(current_geometry, baseline_geometry)
    if not baseline_report.exists():
        shutil.copy2(current_report, baseline_report)
    shutil.copy2(candidate_geometry, current_geometry)
    report = {
        "character": "J",
        "status": "experimental_promoted_width_continuity_repair",
        "designConstraint": "restrained rounded top bar with stem-width continuity",
        "pipeline": [
            "preserve_accepted_body_below_y430",
            "match_vertical_return_to_observed_86_unit_stem",
            "retain_restrained_rounded_top_bar",
            "nonzero_winding_union",
        ],
        "sources": [
            "AnnotationMono-VF.ttf",
            "ComicShannsMono-Regular.ttf",
            "SyneMono-Regular.ttf",
            "routed-gothic.ttf",
        ],
        "equalSourceWeight": 0.25,
        "selectedCandidate": "width-continuous",
        "candidateGeometry": str(candidate_geometry.relative_to(PROJECT)),
        "candidateReport": str(candidate_report.relative_to(PROJECT)),
        "baselineGeometry": str(baseline_geometry.relative_to(PROJECT)),
        "baselineReport": str(baseline_report.relative_to(PROJECT)),
        "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
        "expectedTopology": {"components": 1, "holes": 0},
        "outputTopology": {"components": 1, "holes": 0},
        "pointsPerContour": 10240,
        "verticalReturnWidth": 86.0,
        "visualReview": "passes side-by-side review: cap retained and vertical width continuous",
    }
    current_report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
