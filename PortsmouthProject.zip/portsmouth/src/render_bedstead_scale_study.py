#!/usr/bin/env python3
"""Render Bedstead at native text sizes instead of outline-analysis scale."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[2]
FONT = ROOT / "bedstead.otf"
OUT = ROOT / "portsmouth" / "specimens" / "bedstead-native-scales.png"


def main() -> None:
    sizes = (18, 24, 36, 48, 60, 72, 90)
    image = Image.new("RGB", (1500, 980), "#eee9df")
    draw = ImageDraw.Draw(image)
    title = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 34
    )
    label = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 20
    )
    draw.text((45, 30), "Bedstead 2.002 — native-size FreeType rendering", fill="#111", font=title)
    for index, size in enumerate(sizes):
        row = index // 2
        col = index % 2
        left = 45 + col * 725
        top = 100 + row * 210
        face = ImageFont.truetype(FONT, size)
        # Render at native size, then enlarge with nearest-neighbor so the
        # rasterizer's phase remains visible rather than being rerendered.
        native = Image.new("L", (180, 100), 255)
        native_draw = ImageDraw.Draw(native)
        native_draw.text((8, 78), "lmn", font=face, fill=0, anchor="ls")
        zoom = max(2, min(6, 288 // size))
        enlarged = native.resize(
            (native.width * zoom, native.height * zoom), Image.Resampling.NEAREST
        ).convert("RGB")
        crop = enlarged.crop((0, max(0, 15 * zoom), 170 * zoom, 95 * zoom))
        crop.thumbnail((650, 155), Image.Resampling.NEAREST)
        image.paste(crop, (left, top + 38))
        draw.text((left, top), f"{size}px · {zoom}× nearest display", fill="#333", font=label)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
