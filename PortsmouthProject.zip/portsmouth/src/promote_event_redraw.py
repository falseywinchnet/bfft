#!/usr/bin/env python3
"""Promote visually accepted event redraws while archiving their baseline."""

from __future__ import annotations

import json
import shutil

import numpy as np

from portsmouth_engine import PROJECT


def promote_f() -> None:
    stem = "0066"
    current_geometry = PROJECT / "geometry" / f"boundary-trace-{stem}.npz"
    current_report = PROJECT / "reports" / f"boundary-trace-{stem}.json"
    baseline_geometry = PROJECT / "geometry" / f"boundary-trace-{stem}-pre-event.npz"
    baseline_report = PROJECT / "reports" / f"boundary-trace-{stem}-pre-event.json"
    candidate_geometry = PROJECT / "geometry" / f"event-redraw-{stem}.npz"
    candidate_report = json.loads(
        (PROJECT / "reports" / f"event-redraw-{stem}.json").read_text()
    )
    if not baseline_geometry.exists():
        shutil.copy2(current_geometry, baseline_geometry)
    if not baseline_report.exists():
        shutil.copy2(current_report, baseline_report)
    with np.load(candidate_geometry, allow_pickle=False) as archive:
        contour_keys = [
            key for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]
        if contour_keys != ["outer_0"]:
            raise ValueError(f"Unexpected f candidate contours: {contour_keys}")
        np.savez_compressed(
            current_geometry,
            contour=archive["outer_0"].astype(np.float32),
            character=np.asarray("f"),
            unitsPerEm=np.asarray(1000, dtype=np.int32),
        )
    report = {
        "character": "f",
        "status": "experimental_promoted_event_redraw",
        "pipeline": [
            "six_event_piecewise_contour_correspondence",
            "equal_weight_four_source_arc_barycenter",
            "modal_bottom_terminal_width_normalization",
            "compact_round_stem_cap",
        ],
        "sources": candidate_report["sources"],
        "equalSourceWeight": 0.25,
        "pointsPerSourceContour": 10240,
        "expectedTopology": candidate_report["expectedTopology"],
        "outputTopology": candidate_report["outputTopology"],
        "eventRedrawReport": f"reports/event-redraw-{stem}.json",
        "baselineGeometry": str(baseline_geometry.relative_to(PROJECT)),
        "baselineReport": str(baseline_report.relative_to(PROJECT)),
        "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
        "visualReview": "passes current rendered review: clean crossbar junction and compact terminal",
    }
    current_report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    promote_f()
