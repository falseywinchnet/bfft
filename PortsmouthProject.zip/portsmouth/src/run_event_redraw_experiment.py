#!/usr/bin/env python3
"""Targeted correspondence controls for Portsmouth a/f/K/q redraws."""

from __future__ import annotations

import argparse
import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import gaussian_filter1d

from boundary_trace import (
    BoundaryCloud,
    annealed_boundary_barycenter,
    rasterize_contour_complex,
    resample_closed,
)
from outline_geometry import normalized_source_contours, union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask, retain_persistent_loops


CHARACTERS = "afKq"
POINTS = 10240


def current_geometry(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            with np.load(path, allow_pickle=False) as archive:
                return [
                    ("hole" if key.startswith("hole") else "outer", archive[key])
                    for key in archive.files
                    if key not in {"character", "unitsPerEm"}
                ]
    raise FileNotFoundError(character)


def normalized_complexes(engine, character, fields):
    raw = normalized_source_contours(engine, character)
    extracted = [
        union_contour_complex(raw[field.source.filename], pixels_per_unit=5.0)
        for field in fields
    ]
    topologies = [engine.topology(field.mask) for field in fields]
    filtered = [
        retain_persistent_loops(complex_, topology)[0]
        for complex_, topology in zip(extracted, topologies)
    ]
    tops = [max(float(np.max(loop.points[:, 1])) for loop in value.outer) for value in filtered]
    target = float(np.median(tops))
    for complex_, top in zip(filtered, tops):
        scale = target / top
        for loop in complex_.loops:
            loop.points[:, 1] *= scale
            loop.centroid[1] *= scale
            loop.area *= scale
    return filtered, target


def radial_profile(points: np.ndarray, center: np.ndarray, count: int) -> np.ndarray:
    dense = resample_closed(points, max(65536, count * 6))
    relative = dense - center
    angle = np.mod(np.arctan2(relative[:, 1], relative[:, 0]), 2.0 * np.pi)
    radius = np.linalg.norm(relative, axis=1)
    bins = np.floor(angle * count / (2.0 * np.pi)).astype(np.int64) % count
    profile = np.full(count, -np.inf, dtype=np.float64)
    np.maximum.at(profile, bins, radius)
    present = np.isfinite(profile)
    if np.count_nonzero(present) < count // 2:
        raise ValueError("Contour is not sufficiently radial around its counter")
    indices = np.arange(count)
    known = indices[present]
    profile = np.interp(
        indices,
        np.concatenate((known - count, known, known + count)),
        np.tile(profile[present], 3),
    )
    return gaussian_filter1d(profile, sigma=1.1, mode="wrap")


def counter_centered_trace(complexes):
    outer_loops = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    hole_loops = [max(value.holes, key=lambda loop: loop.area) for value in complexes]
    centers = [np.mean(loop.points, axis=0) for loop in hole_loops]
    fused_center = np.mean(centers, axis=0)
    outer_profiles = [
        radial_profile(loop.points, center, POINTS)
        for loop, center in zip(outer_loops, centers)
    ]
    hole_profiles = [
        radial_profile(loop.points, center, POINTS)
        for loop, center in zip(hole_loops, centers)
    ]
    angle = np.linspace(0.0, 2.0 * np.pi, POINTS, endpoint=False)
    direction = np.column_stack((np.cos(angle), np.sin(angle)))
    outer = fused_center + np.mean(outer_profiles, axis=0)[:, None] * direction
    hole = fused_center + np.mean(hole_profiles, axis=0)[:, None] * direction
    return [("outer", outer), ("hole", hole)], {
        "operator": "equal_weight_counter_centered_radial_transport",
        "profileSamplesPerSource": max(65536, POINTS * 6),
        "drawingPoints": POINTS,
        "sourceCounterCenters": [list(map(float, center)) for center in centers],
        "fusedCounterCenter": list(map(float, fused_center)),
    }


def self_anchored_trace(complexes, fields):
    loops = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    clouds = []
    for field, value in zip(fields, loops):
        points = resample_closed(value.points, POINTS)
        clouds.append(BoundaryCloud(
            source=field.source.filename,
            points=points,
            median_anchor=points,
        ))
    contour, detail = annealed_boundary_barycenter(clouds)
    detail["operatorControl"] = "boundary_self_anchored_without_medial_assignment"
    return [("outer", contour)], detail


def _resample_open(points: np.ndarray, count: int) -> np.ndarray:
    if len(points) == 1 or np.allclose(points, points[0]):
        return np.repeat(points[:1], count, axis=0)
    length = np.linalg.norm(np.diff(points, axis=0), axis=1)
    cumulative = np.concatenate(([0.0], np.cumsum(length)))
    if cumulative[-1] <= 0.0:
        raise ValueError("Degenerate contour arc")
    targets = np.linspace(0.0, cumulative[-1], count, endpoint=False)
    result = np.empty((count, 2), dtype=float)
    for dimension in range(2):
        result[:, dimension] = np.interp(targets, cumulative, points[:, dimension])
    return result


def f_landmarks(points: np.ndarray) -> dict[str, int]:
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    width, height = maximum - minimum
    probe_y = np.linspace(minimum[1] + 0.25 * height, minimum[1] + 0.70 * height, 180)
    spans = []
    for y in probe_y:
        band = points[np.abs(points[:, 1] - y) < max(height / 500.0, 1.5)]
        spans.append(float(np.ptp(band[:, 0])) if len(band) > 1 else 0.0)
    crossbar_y = float(probe_y[int(np.argmax(spans))])
    half_thickness = 0.055 * height
    scale = np.array([max(width, 1.0), max(height, 1.0)])

    def nearest(target):
        return int(np.argmin(np.sum(((points - target) / scale) ** 2, axis=1)))

    return {
        "bottom": int(np.argmin(points[:, 1])),
        "right_crossbar_bottom": nearest(np.array([maximum[0], crossbar_y - half_thickness])),
        "right_crossbar_top": nearest(np.array([maximum[0], crossbar_y + half_thickness])),
        "top": int(np.argmax(points[:, 1])),
        "left_crossbar_top": nearest(np.array([minimum[0], crossbar_y + half_thickness])),
        "left_crossbar_bottom": nearest(np.array([minimum[0], crossbar_y - half_thickness])),
    }


def piecewise_f_trace(complexes, fields):
    contours = [
        resample_closed(max(value.outer, key=lambda loop: loop.area).points, POINTS)
        for value in complexes
    ]
    bottom_widths = []
    bottom_centers = []
    stem_centers = []
    for points in contours:
        minimum_y, maximum_y = float(np.min(points[:, 1])), float(np.max(points[:, 1]))
        height = maximum_y - minimum_y
        band = points[points[:, 1] <= minimum_y + 0.08 * height]
        left, right = float(np.min(band[:, 0])), float(np.max(band[:, 0]))
        bottom_widths.append(right - left)
        bottom_centers.append(0.5 * (left + right))
        stem_band = points[
            (points[:, 1] >= minimum_y + 0.22 * height)
            & (points[:, 1] <= minimum_y + 0.34 * height)
        ]
        stem_centers.append(0.5 * (
            float(np.min(stem_band[:, 0])) + float(np.max(stem_band[:, 0]))
        ))
    target_bottom_width = float(np.median(bottom_widths))
    normalized_contours = []
    for points, width, center, stem_center in zip(
        contours, bottom_widths, bottom_centers, stem_centers
    ):
        points = points.copy()
        minimum_y, maximum_y = float(np.min(points[:, 1])), float(np.max(points[:, 1]))
        transition_y = minimum_y + 0.16 * (maximum_y - minimum_y)
        amount = np.clip((transition_y - points[:, 1]) / max(transition_y - minimum_y, 1e-9), 0.0, 1.0)
        amount = amount * amount * (3.0 - 2.0 * amount)
        terminal_scale = target_bottom_width / max(width, 1e-9)
        local_scale = 1.0 + amount * (terminal_scale - 1.0)
        points[:, 0] = center + (points[:, 0] - center) * local_scale
        points[:, 0] += amount * (stem_center - center)
        normalized_contours.append(points)
    contours = normalized_contours
    order = [
        "bottom",
        "right_crossbar_bottom",
        "right_crossbar_top",
        "top",
        "left_crossbar_top",
        "left_crossbar_bottom",
    ]
    landmarks = [f_landmarks(points) for points in contours]
    segment_counts = [POINTS // len(order)] * len(order)
    for index in range(POINTS % len(order)):
        segment_counts[index] += 1
    aligned_sources = []
    for points, source_landmarks in zip(contours, landmarks):
        arcs = []
        for index, name in enumerate(order):
            first = source_landmarks[name]
            last = source_landmarks[order[(index + 1) % len(order)]]
            if last <= first:
                indices = np.concatenate((np.arange(first, len(points)), np.arange(0, last + 1)))
            else:
                indices = np.arange(first, last + 1)
            arcs.append(_resample_open(points[indices], segment_counts[index]))
        aligned_sources.append(np.vstack(arcs))
    contour = np.mean(aligned_sources, axis=0)
    contour += 0.018 * (
        np.roll(contour, 1, axis=0) + np.roll(contour, -1, axis=0) - 2.0 * contour
    )
    # The source-terminal normalization is completed as a conventional round
    # stem cap. Three sources already use a compact terminal; this prevents
    # Comic Shanns' optional slab foot from surviving as a teardrop after the
    # equal-weight event average.
    minimum_y, maximum_y = float(np.min(contour[:, 1])), float(np.max(contour[:, 1]))
    height = maximum_y - minimum_y
    stem_band = contour[
        (contour[:, 1] >= minimum_y + 0.22 * height)
        & (contour[:, 1] <= minimum_y + 0.34 * height)
    ]
    stem_center = 0.5 * (float(np.min(stem_band[:, 0])) + float(np.max(stem_band[:, 0])))
    radius = 0.5 * target_bottom_width
    cap_center_y = minimum_y + radius
    below = contour[:, 1] <= minimum_y + 0.18 * height
    vertical = contour[below, 1] - cap_center_y
    desired_half = np.where(
        contour[below, 1] < cap_center_y,
        np.sqrt(np.maximum(radius ** 2 - vertical ** 2, 0.0)),
        radius,
    )
    desired_x = stem_center + np.where(
        contour[below, 0] >= stem_center, desired_half, -desired_half
    )
    fade = np.clip(
        (minimum_y + 0.18 * height - contour[below, 1]) / (0.06 * height),
        0.0,
        1.0,
    )
    contour[below, 0] = (
        (1.0 - fade) * contour[below, 0] + fade * desired_x
    )
    return [("outer", contour)], {
        "operator": "equal_weight_piecewise_contour_event_barycenter",
        "events": order,
        "sourceEventIndices": {
            field.source.filename: source_landmarks
            for field, source_landmarks in zip(fields, landmarks)
        },
        "sourceBottomTerminalWidths": {
            field.source.filename: float(width)
            for field, width in zip(fields, bottom_widths)
        },
        "normalizedBottomTerminalWidth": target_bottom_width,
        "outputTerminal": "modal compact round stem cap",
        "sourceBottomToStemCenterShift": {
            field.source.filename: float(stem_center - bottom_center)
            for field, bottom_center, stem_center in zip(
                fields, bottom_centers, stem_centers
            )
        },
        "drawingPoints": POINTS,
    }


def extrema_landmarks(points: np.ndarray) -> dict[str, int]:
    return {
        "bottom": int(np.argmin(points[:, 1])),
        "right": int(np.argmax(points[:, 0])),
        "top": int(np.argmax(points[:, 1])),
        "left": int(np.argmin(points[:, 0])),
    }


def a_landmarks(points: np.ndarray, hole) -> dict[str, int]:
    center = np.mean(hole.points, axis=0)
    upper_ids = np.flatnonzero(points[:, 1] > center[1])
    lower_ids = np.flatnonzero(points[:, 1] <= center[1])
    return {
        "bottom": int(np.argmin(points[:, 1])),
        "right_lower": int(lower_ids[np.argmax(points[lower_ids, 0])]),
        "right_upper": int(upper_ids[np.argmax(points[upper_ids, 0])]),
        "top": int(np.argmax(points[:, 1])),
        "left_upper": int(upper_ids[np.argmin(points[upper_ids, 0])]),
        "left": int(np.argmin(points[:, 0])),
    }


def q_landmarks(points: np.ndarray, hole) -> dict[str, int]:
    center = np.mean(hole.points, axis=0)
    hole_min, hole_max = np.min(hole.points, axis=0), np.max(hole.points, axis=0)
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    width, height = maximum - minimum

    def selected(mask, values, maximum_value=True):
        indices = np.flatnonzero(mask)
        position = np.argmax(values[indices]) if maximum_value else np.argmin(values[indices])
        return int(indices[position])

    low = points[:, 1] < min(float(hole_min[1]), 50.0)
    upper = points[:, 1] > center[1]
    left_lower = (
        (points[:, 0] < center[0])
        & (points[:, 1] > minimum[1] + 0.20 * height)
    )
    join_target = np.array([
        hole_max[0], max(0.0, hole_min[1] - 0.15 * height)
    ])
    normalized_delta = (
        (points - join_target)
        / np.array([max(width, 1.0), max(height, 1.0)])
    )
    return {
        "bottom": int(np.argmin(points[:, 1])),
        "descender_outer": selected(low, points[:, 0]),
        "upper_right": selected(upper, points[:, 0]),
        "top": int(np.argmax(points[:, 1])),
        "left": int(np.argmin(points[:, 0])),
        "bowl_bottom": selected(left_lower, points[:, 1], maximum_value=False),
        "inner_join": int(np.argmin(np.sum(normalized_delta ** 2, axis=1))),
    }


def canonical_k_contour(points: np.ndarray) -> np.ndarray:
    """Start at the stem foot and traverse the lower arm before the upper."""
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    width, height = maximum - minimum
    normalized_x = (points[:, 0] - minimum[0]) / max(width, 1.0)
    normalized_y = (points[:, 1] - minimum[1]) / max(height, 1.0)
    stem_ids = np.flatnonzero(normalized_x < 0.42)
    start = int(stem_ids[np.argmin(points[stem_ids, 1])])
    points = np.roll(points, -start, axis=0)
    normalized_y = (points[:, 1] - minimum[1]) / max(height, 1.0)
    lower_ids = np.flatnonzero(normalized_y < 0.48)
    upper_ids = np.flatnonzero(normalized_y > 0.52)
    lower_tip = int(lower_ids[np.argmax(points[lower_ids, 0])])
    upper_tip = int(upper_ids[np.argmax(points[upper_ids, 0])])
    if lower_tip > upper_tip:
        points = np.vstack((points[:1], points[:0:-1]))
    return points


def k_landmarks(points: np.ndarray) -> dict[str, int]:
    """Locate construction events within canonical arm intervals."""
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    width, height = maximum - minimum
    normalized_x = (points[:, 0] - minimum[0]) / max(width, 1.0)
    normalized_y = (points[:, 1] - minimum[1]) / max(height, 1.0)
    stride = max(8, len(points) // 256)
    incoming = points - np.roll(points, stride, axis=0)
    outgoing = np.roll(points, -stride, axis=0) - points
    turn = np.arctan2(
        incoming[:, 0] * outgoing[:, 1] - incoming[:, 1] * outgoing[:, 0],
        np.sum(incoming * outgoing, axis=1),
    )

    def strongest_concavity(first: int, last: int, mask: np.ndarray) -> int:
        interval = np.zeros(len(points), dtype=bool)
        interval[max(0, first):min(len(points), last)] = True
        indices = np.flatnonzero(mask & interval)
        if not len(indices):
            raise ValueError("K event region has no contour samples")
        return int(indices[np.argmin(turn[indices])])

    lower_ids = np.flatnonzero(normalized_y < 0.48)
    upper_ids = np.flatnonzero(normalized_y > 0.52)
    lower_tip = int(lower_ids[np.argmax(points[lower_ids, 0])])
    upper_tip = int(upper_ids[np.argmax(points[upper_ids, 0])])
    stem_ids = np.flatnonzero(normalized_x < 0.42)
    top = int(stem_ids[np.argmax(points[stem_ids, 1])])
    lower_join = strongest_concavity(
        max(1, len(points) // 80), lower_tip,
        (normalized_x < 0.49) & (normalized_y > 0.27),
    )
    crotch = strongest_concavity(
        lower_tip + 1, upper_tip,
        (normalized_x > 0.20) & (normalized_y > 0.42) & (normalized_y < 0.68),
    )
    upper_join = strongest_concavity(
        upper_tip + 1, top,
        (normalized_x < 0.43) & (normalized_y < 0.75),
    )
    left_interval = np.arange(top, len(points))
    return {
        "bottom": 0,
        "lower_join": lower_join,
        "lower_tip": lower_tip,
        "crotch": crotch,
        "upper_tip": upper_tip,
        "upper_join": upper_join,
        "top": top,
        "left": int(left_interval[np.argmin(points[left_interval, 0])]),
    }


def _piecewise_average(contours, landmarks, order):
    segment_counts = [POINTS // len(order)] * len(order)
    for index in range(POINTS % len(order)):
        segment_counts[index] += 1
    aligned = []
    for points, values in zip(contours, landmarks):
        arcs = []
        for index, name in enumerate(order):
            first = values[name]
            last = values[order[(index + 1) % len(order)]]
            if last < first:
                indices = np.concatenate((
                    np.arange(first, len(points)), np.arange(0, last + 1)
                ))
            else:
                indices = np.arange(first, last + 1)
            arcs.append(_resample_open(points[indices], segment_counts[index]))
        aligned.append(np.vstack(arcs))
    result = np.mean(aligned, axis=0)
    result += 0.018 * (
        np.roll(result, 1, axis=0)
        + np.roll(result, -1, axis=0)
        - 2.0 * result
    )
    return result


def piecewise_countered_trace(character, complexes, fields):
    outer_loops = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    hole_loops = [max(value.holes, key=lambda loop: loop.area) for value in complexes]
    outer_contours = [resample_closed(value.points, POINTS) for value in outer_loops]
    if character == "a":
        outer_order = [
            "bottom", "right_lower", "right_upper",
            "top", "left_upper", "left",
        ]
        outer_landmarks = [
            a_landmarks(points, hole)
            for points, hole in zip(outer_contours, hole_loops)
        ]
    else:
        outer_order = [
            "bottom", "descender_outer", "upper_right", "top",
            "left", "bowl_bottom", "inner_join",
        ]
        outer_landmarks = [
            q_landmarks(points, hole)
            for points, hole in zip(outer_contours, hole_loops)
        ]
    outer = _piecewise_average(outer_contours, outer_landmarks, outer_order)
    hole_contours = [resample_closed(value.points, POINTS) for value in hole_loops]
    hole_landmarks = [extrema_landmarks(points) for points in hole_contours]
    hole_order = ["bottom", "right", "top", "left"]
    hole = _piecewise_average(hole_contours, hole_landmarks, hole_order)
    return [("outer", outer), ("hole", hole)], {
        "operator": "equal_weight_piecewise_countered_event_barycenter",
        "outerEvents": outer_order,
        "counterEvents": hole_order,
        "sourceOuterEventIndices": {
            field.source.filename: values
            for field, values in zip(fields, outer_landmarks)
        },
        "sourceCounterEventIndices": {
            field.source.filename: values
            for field, values in zip(fields, hole_landmarks)
        },
        "drawingPoints": POINTS,
    }


def piecewise_k_trace(complexes, fields):
    contours = [
        canonical_k_contour(
            resample_closed(max(value.outer, key=lambda loop: loop.area).points, POINTS)
        )
        for value in complexes
    ]
    order = [
        "bottom", "lower_join", "lower_tip", "crotch",
        "upper_tip", "upper_join", "top", "left",
    ]
    landmarks = [k_landmarks(points) for points in contours]
    contour = _piecewise_average(contours, landmarks, order)
    return [("outer", contour)], {
        "operator": "equal_weight_piecewise_k_event_barycenter",
        "events": order,
        "sourceEventIndices": {
            field.source.filename: values
            for field, values in zip(fields, landmarks)
        },
        "drawingPoints": POINTS,
    }


def render(engine, character, fields, candidate, output):
    current = current_geometry(character)
    entries = [(field.source.family, field.mask) for field in fields]
    entries += [
        ("Current Portsmouth 0.011", rasterize_contour_complex(engine, current)),
        ("Event-anchored candidate", rasterize_contour_complex(engine, candidate)),
    ]
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — targeted redraw control", fill="#111", font=title)
    if character in "aq":
        method = "piecewise bowl/counter event transport"
    elif character == "f":
        method = "piecewise crossbar-event transport"
    elif character == "K":
        method = "piecewise arm/junction event transport"
    else:
        method = "boundary-self-anchored transport"
    draw.text((40, 78), f"{method} · four equal sources · candidate does not replace current geometry", fill="#575149", font=small)
    for index, (name, mask) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_w, 120 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        image = _render_mask(mask, (tile_w - 70, tile_h - 105))
        canvas.paste(image, (x0 + (tile_w - 20 - image.width) // 2, y0 + 63 + (tile_h - 105 - image.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), "candidate" if index == len(entries) - 1 else "normalized source/current", fill="#655f57", font=small)
    canvas.save(output)


def run_character(engine, character):
    fields = [engine.source_field(source, character) for source in engine.active_sources(character)]
    complexes, target_top = normalized_complexes(engine, character, fields)
    if character in "aq":
        contours, detail = piecewise_countered_trace(character, complexes, fields)
    elif character == "f":
        contours, detail = piecewise_f_trace(complexes, fields)
    elif character == "K":
        contours, detail = piecewise_k_trace(complexes, fields)
    else:
        contours, detail = self_anchored_trace(complexes, fields)
    mask = rasterize_contour_complex(engine, contours)
    expected = engine.topology(fields[0].mask)
    actual = engine.topology(mask)
    status = "candidate_event_redraw" if actual == expected else "rejected_topology_mismatch"
    stem = f"{ord(character):04x}"
    geometry = PROJECT / "geometry" / f"event-redraw-{stem}.npz"
    arrays = {
        f"{role}_{index}": points.astype(np.float32)
        for index, (role, points) in enumerate(contours)
    }
    arrays["character"] = np.asarray(character)
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(geometry, **arrays)
    report = {
        "character": character,
        "status": status,
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 0.25,
        "exactTargetInkTop": target_top,
        "expectedTopology": expected,
        "outputTopology": actual,
        "method": detail,
        "geometryArtifact": str(geometry.relative_to(PROJECT)),
        "replacesCurrentGeometry": False,
        "visualReview": None,
    }
    (PROJECT / "reports" / f"event-redraw-{stem}.json").write_text(json.dumps(report, indent=2) + "\n")
    specimen = PROJECT / "specimens" / f"event-redraw-{stem}.png"
    render(engine, character, fields, contours, specimen)
    print(json.dumps({key: value for key, value in report.items() if key != "method"}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("characters", nargs="*", default=list(CHARACTERS))
    arguments = parser.parse_args()
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    for character in arguments.characters:
        run_character(engine, character)


if __name__ == "__main__":
    main()
