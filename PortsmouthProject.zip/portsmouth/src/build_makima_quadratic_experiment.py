#!/usr/bin/env python3
"""Build the isolated event-aware Makima-to-quadratic Portsmouth experiment."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageChops, ImageDraw, ImageFont

from build_first_ttf import (
    GRAPHIC_CODEPOINTS,
    MINIMUM_SIDEBEARING,
    archived_contours,
    empty_glyph,
    geometry_for,
    glyph_name,
    mean_advance,
    notdef_glyph,
    outline_glyph,
)
from makima_quadratic import compile_master, periodic_makima_master
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from vectorize import signed_area


SOURCE_VERSION = "0.017"
EXPERIMENT_VERSION = "0.017-makima-q2"
FONT_REVISION = 0.0172
SIMPLIFICATION_TOLERANCE = 4.0
MASTER_TOLERANCE = 2.5
CORNER_DEGREES = 24.0
QUADRATIC_TOLERANCE = 1.8
LINE_TOLERANCE = 0.30


def makima_outline_glyph(contours, advance: int, *, tolerance_override=None):
    tolerance_override = tolerance_override or {}
    simplification_tolerance = tolerance_override.get("simplification", SIMPLIFICATION_TOLERANCE)
    master_tolerance = tolerance_override.get("master", MASTER_TOLERANCE)
    quadratic_tolerance = tolerance_override.get("quadratic", QUADRATIC_TOLERANCE)
    line_tolerance = tolerance_override.get("line", LINE_TOLERANCE)
    shift = advance / 2.0
    pen = TTGlyphPen(None)
    reports = []
    all_points = []
    for role, source in contours:
        points = source.astype(np.float64)
        area = signed_area(points)
        should_be_clockwise = role == "outer"
        if (area < 0.0) != should_be_clockwise:
            points = points[::-1]
        master = periodic_makima_master(
            points,
            simplification_tolerance=simplification_tolerance,
            master_tolerance=master_tolerance,
            corner_degrees=CORNER_DEGREES,
        )
        segments = compile_master(
            master,
            quadratic_tolerance=quadratic_tolerance,
            line_tolerance=line_tolerance,
        )
        first = np.rint(segments[0].start + np.asarray([shift, 0.0])).astype(np.int32)
        pen.moveTo(tuple(map(int, first)))
        current = first
        quadratic_count = line_count = 0
        maximum_quadratic_error = 0.0
        for segment in segments:
            end = np.rint(segment.end + np.asarray([shift, 0.0])).astype(np.int32)
            maximum_quadratic_error = max(maximum_quadratic_error, segment.error)
            if segment.control is None:
                if not np.array_equal(end, current):
                    pen.lineTo(tuple(map(int, end)))
                    line_count += 1
            else:
                control = np.rint(segment.control + np.asarray([shift, 0.0])).astype(np.int32)
                if np.array_equal(end, current) or np.array_equal(control, current) or np.array_equal(control, end):
                    if not np.array_equal(end, current):
                        pen.lineTo(tuple(map(int, end)))
                        line_count += 1
                else:
                    pen.qCurveTo(tuple(map(int, control)), tuple(map(int, end)))
                    quadratic_count += 1
            current = end
        pen.closePath()
        all_points.append(points)
        reports.append({
            "role": role,
            "densePoints": len(points),
            "makimaKnots": len(master.knot_indices),
            "hardEvents": len(master.hard_indices),
            "cubicHermiteSegments": len(master.cubics),
            "quadraticSegments": quadratic_count,
            "lineSegments": line_count,
            "masterRefinementPasses": master.refinement_passes,
            "maximumMasterError": master.maximum_error,
            "maximumMasterNormalError": master.maximum_normal_error,
            "maximumCubicToQuadraticError": maximum_quadratic_error,
        })
    stacked = np.vstack(all_points)
    left = int(math.floor(float(np.min(stacked[:, 0])) + shift))
    right = int(math.ceil(float(np.max(stacked[:, 0])) + shift))
    return pen.glyph(), left, {
        "contours": reports,
        "densePoints": sum(value["densePoints"] for value in reports),
        "makimaKnots": sum(value["makimaKnots"] for value in reports),
        "hardEvents": sum(value["hardEvents"] for value in reports),
        "quadraticSegments": sum(value["quadraticSegments"] for value in reports),
        "lineSegments": sum(value["lineSegments"] for value in reports),
        "maximumMasterError": max(value["maximumMasterError"] for value in reports),
        "maximumMasterNormalError": max(value["maximumMasterNormalError"] for value in reports),
        "maximumCubicToQuadraticError": max(value["maximumCubicToQuadraticError"] for value in reports),
        "leftSidebearing": left,
        "rightSidebearing": advance - right,
        "toleranceOverride": tolerance_override or None,
    }


def _render_line(font_path: Path, size: int, text: str, width=1660) -> Image.Image:
    font = ImageFont.truetype(font_path, size)
    image = Image.new("L", (width, size + 50), 0)
    ImageDraw.Draw(image).text((15, 10), text, fill=255, font=font)
    return image


def raster_metrics(source: Path, experiment: Path) -> list[dict]:
    text = "Portsmouth J1 ©® ½¾ / minimum aqua quay"
    values = []
    for size in (18, 28, 44, 72, 112):
        left = _render_line(source, size, text)
        right = _render_line(experiment, size, text)
        delta = np.asarray(ImageChops.difference(left, right), dtype=np.float64) / 255.0
        union = (np.asarray(left) > 0) | (np.asarray(right) > 0)
        values.append({
            "sizePixels": size,
            "meanAbsoluteDifference": float(np.mean(delta)),
            "meanDifferenceOnUnion": float(np.mean(delta[union])) if np.any(union) else 0.0,
            "differingPixelFraction": float(np.mean(delta > (1.0 / 255.0))),
        })
    return values


def render_comparison(source: Path, q1: Path, q2: Path) -> Path:
    canvas = Image.new("RGB", (2100, 1530), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 36)
    label = ImageFont.truetype(ui, 16)
    draw.text((55, 28), "Portsmouth Makima quadratic experiment", fill="#111", font=title)
    draw.text(
        (55, 78),
        "protected Regular 0.017 · previous q1 control · periodic event-aware Makima q2",
        fill="#5d574e",
        font=label,
    )
    columns = [("Regular 0.017", source), ("Quadratic q1", q1), ("Makima q2", q2)]
    x_positions = (55, 735, 1415)
    panel_width = 630
    for (name, _), x in zip(columns, x_positions):
        draw.text((x, 120), name, fill="#776f65", font=label)
    rows = [
        (20, "Portsmouth makes ordinary language feel newly drawn."),
        (34, "JULY 1 · J1 JI Il 1i"),
        (54, "aquamarine / minimum"),
        (92, "a q æ m w S 8 @"),
        (112, "Portsmouth"),
    ]
    y = 155
    for size, text in rows:
        for (_, path), x in zip(columns, x_positions):
            face = ImageFont.truetype(path, size)
            panel = Image.new("RGB", (panel_width, size + 35), "#eee9df")
            ImageDraw.Draw(panel).text((0, 0), text, fill="#171715", font=face)
            canvas.paste(panel, (x, y))
        draw.text((15, y + 4), f"{size}", fill="#8b8277", font=label)
        y += size + 105
    draw.line((700, 110, 700, 1470), fill="#c8c0b4", width=2)
    draw.line((1380, 110, 1380, 1470), fill="#c8c0b4", width=2)
    output = PROJECT / "specimens" / "experimental" / f"Portsmouth-Quadratic-{EXPERIMENT_VERSION}-comparison.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    return output


def build():
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    archived = [cp for cp in GRAPHIC_CODEPOINTS if geometry_for(cp) is not None]
    cmap_codepoints = sorted(set(archived) | {0x20, 0xA0})
    names = {cp: glyph_name(cp) for cp in cmap_codepoints}
    glyph_order = [".notdef"] + [names[cp] for cp in cmap_codepoints]
    glyphs = {".notdef": notdef_glyph()}
    metrics = {".notdef": (600, 55)}
    cmap = {cp: names[cp] for cp in cmap_codepoints}
    report_glyphs = []
    space_width = int(round(float(np.mean([
        source.widths[0x20] for source in engine.sources
        if source.filename in {"AnnotationMono-VF.ttf", "ComicShannsMono-Regular.ttf", "routed-gothic.ttf"}
    ]))))
    for cp in cmap_codepoints:
        name = names[cp]
        path = geometry_for(cp)
        if path is None:
            glyphs[name] = empty_glyph()
            metrics[name] = (space_width, 0)
            continue
        contours = archived_contours(path)
        all_points = np.vstack([points for _, points in contours])
        width = float(np.ptp(all_points[:, 0]))
        desired_advance = mean_advance(engine, chr(cp))
        advance = int(math.ceil(max(desired_advance, width + 2 * MINIMUM_SIDEBEARING)))
        if cp == 0x00BF:
            glyph, lsb, fallback_detail = outline_glyph(contours, advance)
            detail = {
                "contours": [],
                "densePoints": sum(len(points) for _, points in contours),
                "makimaKnots": 0,
                "hardEvents": 0,
                "quadraticSegments": 0,
                "lineSegments": fallback_detail["outputPoints"],
                "maximumMasterError": 0.0,
                "maximumMasterNormalError": 0.0,
                "maximumCubicToQuadraticError": 0.0,
                "leftSidebearing": lsb,
                "rightSidebearing": advance - fallback_detail["xMax"],
                "toleranceOverride": None,
                "fallback": "protected polygonal outline; Makima changed a near-degenerate three-component neck",
            }
        else:
            glyph, lsb, detail = makima_outline_glyph(contours, advance)
        if glyph.numberOfContours != len(contours):
            raise ValueError(f"U+{cp:04X} contour count changed during compilation")
        glyphs[name] = glyph
        metrics[name] = (advance, lsb)
        report_glyphs.append({"codepoint": f"U+{cp:04X}", "character": chr(cp), **detail})

    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=850, descent=-250, lineGap=0)
    fb.setupNameTable({
        "familyName": "Portsmouth Makima Quadratic Test",
        "styleName": "Regular",
        "uniqueFontIdentifier": f"Portsmouth Makima Quadratic Test {EXPERIMENT_VERSION}",
        "fullName": "Portsmouth Makima Quadratic Test Regular",
        "psName": "PortsmouthMakimaQuadraticTest-Regular",
        "version": f"Version {EXPERIMENT_VERSION}",
        "copyright": "Isolated Portsmouth outline experiment; provenance in PROJECT.md",
        "licenseDescription": "Experimental personal and artistic evaluation build.",
    })
    target = engine.target_landmarks
    fb.setupOS2(
        sTypoAscender=850, sTypoDescender=-250, sTypoLineGap=0,
        usWinAscent=1050, usWinDescent=400,
        sxHeight=int(round(target.xheight)), sCapHeight=int(round(target.capheight)),
        usWeightClass=400, usWidthClass=5, fsType=0, fsSelection=0x40,
        achVendID="PMQ2", ulUnicodeRange1=0x00000003, ulCodePageRange1=0x00000001,
    )
    fb.setupPost(isFixedPitch=0)
    fb.setupMaxp()
    fb.font["head"].fontRevision = FONT_REVISION
    destination = PROJECT / "build" / "experimental" / f"Portsmouth-Quadratic-{EXPERIMENT_VERSION}.ttf"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fb.save(destination)
    font = TTFont(destination, lazy=False, recalcBBoxes=True)
    if len(font.getBestCmap()) != len(cmap):
        raise ValueError("Makima quadratic experiment cmap mismatch")
    font.close()
    source = PROJECT / "build" / f"Portsmouth-Regular-{SOURCE_VERSION}.ttf"
    q1 = PROJECT / "build" / "experimental" / "Portsmouth-Quadratic-0.015-q1.ttf"
    comparison = render_comparison(source, q1, destination)
    report = {
        "font": str(destination.relative_to(PROJECT)),
        "sourceMaster": str(source.relative_to(PROJECT)),
        "familyIsolation": "Portsmouth Makima Quadratic Test",
        "sourceVersion": SOURCE_VERSION,
        "experimentVersion": EXPERIMENT_VERSION,
        "method": [
            "cyclic_arc_length_parameterization",
            "structural_corner_and_extrema_events",
            "periodic_modified_Akima_piecewise_cubic_Hermite_master",
            "hard_event_one_sided_tangents",
            "tangent_intersection_cubic_to_quadratic_conversion",
            "adaptive_de_Casteljau_subdivision",
            "protected_outline_fallback_on_topology_change",
        ],
        "tolerances": {
            "initialSimplification": SIMPLIFICATION_TOLERANCE,
            "masterEuclidean": MASTER_TOLERANCE,
            "cornerDegrees": CORNER_DEGREES,
            "cubicToQuadratic": QUADRATIC_TOLERANCE,
            "lineFlatness": LINE_TOLERANCE,
        },
        "glyphCountIncludingNotdef": len(glyph_order),
        "outlineGlyphs": len(report_glyphs),
        "makimaGlyphs": sum("fallback" not in value for value in report_glyphs),
        "polygonalFallbacks": [
            {"codepoint": value["codepoint"], "character": value["character"], "reason": value["fallback"]}
            for value in report_glyphs if "fallback" in value
        ],
        "densePoints": sum(value["densePoints"] for value in report_glyphs),
        "makimaKnots": sum(value["makimaKnots"] for value in report_glyphs),
        "hardEvents": sum(value["hardEvents"] for value in report_glyphs),
        "quadraticSegments": sum(value["quadraticSegments"] for value in report_glyphs),
        "lineSegments": sum(value["lineSegments"] for value in report_glyphs),
        "maximumMasterError": max(value["maximumMasterError"] for value in report_glyphs),
        "maximumMasterNormalError": max(value["maximumMasterNormalError"] for value in report_glyphs),
        "maximumCubicToQuadraticError": max(value["maximumCubicToQuadraticError"] for value in report_glyphs),
        "fontBytes": destination.stat().st_size,
        "sourceFontBytes": source.stat().st_size,
        "rasterComparison": raster_metrics(source, destination),
        "comparison": str(comparison.relative_to(PROJECT)),
        "glyphs": report_glyphs,
    }
    report_path = PROJECT / "reports" / f"quadratic-experiment-{EXPERIMENT_VERSION}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "glyphs"}, indent=2))
    return destination, comparison


if __name__ == "__main__":
    build()
