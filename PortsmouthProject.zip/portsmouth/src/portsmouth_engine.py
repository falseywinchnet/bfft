#!/usr/bin/env python3
"""Core normalized Eikonal-field engine for the Portsmouth typeface.

The engine intentionally stops at raster geometry. Outline reconstruction is a
separate production stage so the barycenter can be inspected without hiding
its behavior behind curve fitting and optical cleanup.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import math
import unicodedata

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage
from fontTools.pens.boundsPen import BoundsPen
from fontTools.ttLib import TTFont


WORKSPACE = Path(__file__).resolve().parents[2]
PROJECT = WORKSPACE / "portsmouth"
SOURCE_FILES = (
    "AnnotationMono-VF.ttf",
    "ComicShannsMono-Regular.ttf",
    "SyneMono-Regular.ttf",
    "bedstead.otf",
    "routed-gothic.ttf",
)
ALWAYS_ON = {
    "AnnotationMono-VF.ttf",
    "ComicShannsMono-Regular.ttf",
    "routed-gothic.ttf",
}


@dataclass(frozen=True)
class Landmarks:
    descender: float
    baseline: float
    xheight: float
    capheight: float
    ascender: float

    def array(self) -> np.ndarray:
        return np.array(
            [self.descender, self.baseline, self.xheight,
             self.capheight, self.ascender],
            dtype=np.float64,
        )


@dataclass
class SourceFont:
    filename: str
    path: Path
    family: str
    upm: int
    cmap: dict[int, str]
    landmarks: Landmarks
    widths: dict[int, float]


@dataclass
class GlyphField:
    source: SourceFont
    character: str
    mask: np.ndarray
    sdf: np.ndarray
    advance: float
    bounds: tuple[float, float, float, float]


@dataclass
class MidpointGlyph:
    character: str
    sources: list[GlyphField]
    raw_field: np.ndarray
    raw_mask: np.ndarray
    mask: np.ndarray
    sdf: np.ndarray
    selected_level: float
    advance: float
    diagnostics: dict


def source_applies(filename: str, character: str) -> bool:
    category = unicodedata.category(character)
    if filename == "SyneMono-Regular.ttf":
        return category == "Lu"
    if filename == "bedstead.otf":
        return category == "Ll"
    return filename in ALWAYS_ON


def _name(font: TTFont, name_id: int) -> str:
    preferred = []
    fallback = []
    for record in font["name"].names:
        if record.nameID != name_id:
            continue
        try:
            value = record.toUnicode().strip()
        except UnicodeDecodeError:
            continue
        if not value:
            continue
        fallback.append(value)
        if record.langID in (0, 0x409):
            preferred.append(value)
    return (preferred or fallback or [""])[0]


def _glyph_bounds(font: TTFont, codepoint: int) -> tuple[float, float, float, float] | None:
    cmap = font.getBestCmap() or {}
    glyph_name = cmap.get(codepoint)
    if glyph_name is None:
        return None
    glyph_set = font.getGlyphSet()
    pen = BoundsPen(glyph_set)
    glyph_set[glyph_name].draw(pen)
    return pen.bounds


def _top(font: TTFont, characters: str) -> float:
    values = []
    for character in characters:
        bounds = _glyph_bounds(font, ord(character))
        if bounds is not None:
            values.append(bounds[3])
    if not values:
        raise ValueError(f"No measurable top landmark in {characters!r}")
    return float(np.median(values))


def _bottom(font: TTFont, characters: str) -> float:
    values = []
    for character in characters:
        bounds = _glyph_bounds(font, ord(character))
        if bounds is not None:
            values.append(bounds[1])
    if not values:
        raise ValueError(f"No measurable bottom landmark in {characters!r}")
    return float(np.median(values))


def inspect_source(path: Path) -> SourceFont:
    font = TTFont(path, lazy=False)
    upm = int(font["head"].unitsPerEm)
    scale = 1000.0 / upm
    cmap = font.getBestCmap() or {}
    x_bounds = _glyph_bounds(font, ord("x"))
    h_bounds = _glyph_bounds(font, ord("H"))
    if x_bounds is None or h_bounds is None:
        raise ValueError(f"{path.name} lacks x or H landmark glyphs")
    landmarks = Landmarks(
        descender=_bottom(font, "gjpqy") * scale,
        baseline=0.0,
        xheight=x_bounds[3] * scale,
        capheight=h_bounds[3] * scale,
        ascender=_top(font, "bdfhkl") * scale,
    )
    widths = {
        codepoint: font["hmtx"].metrics[glyph_name][0] * scale
        for codepoint, glyph_name in cmap.items()
    }
    result = SourceFont(
        filename=path.name,
        path=path,
        family=_name(font, 1),
        upm=upm,
        cmap=cmap,
        landmarks=landmarks,
        widths=widths,
    )
    font.close()
    return result


def load_sources() -> list[SourceFont]:
    return [inspect_source(WORKSPACE / filename) for filename in SOURCE_FILES]


def common_landmarks(sources: list[SourceFont]) -> Landmarks:
    values = np.array([source.landmarks.array() for source in sources])
    median = np.median(values, axis=0)
    return Landmarks(*map(float, median))


def _linear_extrapolated_interp(
    x: np.ndarray, xp: np.ndarray, fp: np.ndarray
) -> np.ndarray:
    result = np.interp(x, xp, fp)
    left = x < xp[0]
    right = x > xp[-1]
    if np.any(left):
        slope = (fp[1] - fp[0]) / (xp[1] - xp[0])
        result[left] = fp[0] + (x[left] - xp[0]) * slope
    if np.any(right):
        slope = (fp[-1] - fp[-2]) / (xp[-1] - xp[-2])
        result[right] = fp[-1] + (x[right] - xp[-1]) * slope
    return result


class EikonalMidpointEngine:
    """Produce equally weighted midpoint fields on a normalized font grid."""

    def __init__(
        self,
        sources: list[SourceFont] | None = None,
        *,
        pixels_per_unit: float = 1.0,
        x_min: float = -750.0,
        x_max: float = 750.0,
        y_min: float = -400.0,
        y_max: float = 1050.0,
        distance_band: float = 80.0,
        field_smoothing: float = 1.5,
        topology_margin: float = 5.0,
    ) -> None:
        self.sources = sources or load_sources()
        self.target_landmarks = common_landmarks(self.sources)
        self.pixels_per_unit = float(pixels_per_unit)
        self.x_min = float(x_min)
        self.x_max = float(x_max)
        self.y_min = float(y_min)
        self.y_max = float(y_max)
        self.distance_band = float(distance_band)
        self.field_smoothing = float(field_smoothing)
        self.topology_margin = float(topology_margin)
        self.width = int(round((self.x_max - self.x_min) * self.pixels_per_unit))
        self.height = int(round((self.y_max - self.y_min) * self.pixels_per_unit))
        self._font_cache: dict[Path, TTFont] = {}
        self._pillow_cache: dict[Path, ImageFont.FreeTypeFont] = {}
        self._landmark_mask_cache: dict[tuple[str, str], np.ndarray] = {}
        self._glyph_top_cache: dict[str, float] = {}
        if self.width < 2 or self.height < 2:
            raise ValueError("Eikonal grid must be at least 2x2")

    def active_sources(self, character: str) -> list[SourceFont]:
        codepoint = ord(character)
        return [
            source for source in self.sources
            if codepoint in source.cmap and source_applies(source.filename, character)
        ]

    def shared_codepoints(self) -> list[int]:
        return sorted(set.intersection(*(set(source.cmap) for source in self.sources)))

    def _normalized_bounds(
        self, source: SourceFont, character: str
    ) -> tuple[float, float, float, float]:
        font = self._font_cache.get(source.path)
        if font is None:
            font = TTFont(source.path, lazy=False)
            self._font_cache[source.path] = font
        bounds = _glyph_bounds(font, ord(character))
        if bounds is None:
            raise KeyError(f"{source.filename} lacks {character!r}")
        scale = 1000.0 / source.upm
        return tuple(float(value * scale) for value in bounds)

    def _uniform_mask(
        self,
        source: SourceFont,
        character: str,
        bounds: tuple[float, float, float, float],
    ) -> np.ndarray:
        image = Image.new("L", (self.width, self.height), 0)
        draw = ImageDraw.Draw(image)
        font_size = max(1, int(round(1000.0 * self.pixels_per_unit)))
        face = self._pillow_cache.get(source.path)
        if face is None or face.size != font_size:
            face = ImageFont.truetype(source.path, font_size)
            self._pillow_cache[source.path] = face
        ink_center = 0.5 * (bounds[0] + bounds[2])
        origin_x = (-self.x_min - ink_center) * self.pixels_per_unit
        baseline_y = self.y_max * self.pixels_per_unit
        draw.text(
            (origin_x, baseline_y),
            character,
            font=face,
            fill=255,
            anchor="ls",
        )
        return np.asarray(image, dtype=np.float64) / 255.0

    def _vertical_normalize(
        self, mask: np.ndarray, source: SourceFont, character: str
    ) -> np.ndarray:
        category = unicodedata.category(character)
        target = self.target_landmarks
        original = source.landmarks
        if category == "Lu":
            # Capitals are governed by baseline and cap height. Pulling a
            # lowercase ascender landmark into this map can fold overshoots
            # when cap height and ascender height are equal or reversed.
            target_anchors = np.array([target.baseline, target.capheight])
            source_anchors = np.array([original.baseline, original.capheight])
        elif category == "Ll":
            target_anchors = np.array([
                target.descender, target.baseline,
                target.xheight, target.ascender,
            ])
            source_anchors = np.array([
                original.descender, original.baseline,
                original.xheight, original.ascender,
            ])
        else:
            # Uncased glyphs receive em-scale vertical alignment around the
            # baseline/cap region. Their construction-specific extrema remain
            # part of the geometry rather than being mistaken for letters.
            target_anchors = np.array([
                target.descender, target.baseline, target.capheight,
            ])
            source_anchors = np.array([
                original.descender, original.baseline, original.capheight,
            ])
        if np.any(np.diff(target_anchors) <= 0) or np.any(np.diff(source_anchors) <= 0):
            raise ValueError(
                f"Non-monotone normalization anchors for {source.filename} "
                f"and {character!r}: {source_anchors.tolist()}"
            )
        target_y = self.y_max - (
            np.arange(self.height, dtype=np.float64) + 0.5
        ) / self.pixels_per_unit
        source_y = _linear_extrapolated_interp(
            target_y,
            target_anchors,
            source_anchors,
        )
        source_rows = (
            (self.y_max - source_y) * self.pixels_per_unit - 0.5
        )
        rows = np.broadcast_to(source_rows[:, None], mask.shape)
        cols = np.broadcast_to(
            np.arange(self.width, dtype=np.float64)[None, :], mask.shape
        )
        warped = ndimage.map_coordinates(
            mask, (rows, cols), order=1, mode="constant", cval=0.0,
            prefilter=False,
        )
        return warped >= 0.5

    def signed_distance(self, mask: np.ndarray) -> np.ndarray:
        if not np.any(mask):
            return np.full(mask.shape, self.distance_band, dtype=np.float64)
        sampling = 1.0 / self.pixels_per_unit
        outside = ndimage.distance_transform_edt(~mask, sampling=sampling)
        inside = ndimage.distance_transform_edt(mask, sampling=sampling)
        return outside - inside

    def _landmark_normalized_mask(
        self, source: SourceFont, character: str
    ) -> np.ndarray:
        key = (source.filename, character)
        cached = self._landmark_mask_cache.get(key)
        if cached is not None:
            return cached
        bounds = self._normalized_bounds(source, character)
        uniform = self._uniform_mask(source, character, bounds)
        mask = self._vertical_normalize(uniform, source, character)
        self._landmark_mask_cache[key] = mask
        return mask

    def _ink_top(self, mask: np.ndarray) -> float:
        rows = np.nonzero(mask)[0]
        if not len(rows):
            raise ValueError("Cannot measure an empty glyph")
        top_row = int(np.min(rows))
        return self.y_max - (top_row + 0.5) / self.pixels_per_unit

    def _maximum_height_normalize(
        self, mask: np.ndarray, character: str
    ) -> np.ndarray:
        """Give every active rendering of one letter the same ink top.

        The baseline is the fixed point.  A too-short source and a too-tall
        source are therefore corrected symmetrically without source selection.
        """
        if not unicodedata.category(character).startswith("L"):
            return mask
        target_top = self._glyph_top_cache.get(character)
        if target_top is None:
            tops = [
                self._ink_top(self._landmark_normalized_mask(source, character))
                for source in self.active_sources(character)
            ]
            target_top = float(np.median(tops))
            self._glyph_top_cache[character] = target_top
        source_top = self._ink_top(mask)
        if source_top <= 0.0 or target_top <= 0.0:
            return mask
        scale = target_top / source_top
        target_y = self.y_max - (
            np.arange(self.height, dtype=np.float64) + 0.5
        ) / self.pixels_per_unit
        source_y = target_y / scale  # scale about the shared y=0 baseline
        source_rows = (self.y_max - source_y) * self.pixels_per_unit - 0.5
        rows = np.broadcast_to(source_rows[:, None], mask.shape)
        columns = np.broadcast_to(
            np.arange(self.width, dtype=np.float64)[None, :], mask.shape
        )
        warped = ndimage.map_coordinates(
            mask.astype(np.float64), (rows, columns), order=1,
            mode="constant", cval=0.0, prefilter=False,
        )
        return warped >= 0.5

    def source_field(self, source: SourceFont, character: str) -> GlyphField:
        bounds = self._normalized_bounds(source, character)
        landmark_mask = self._landmark_normalized_mask(source, character)
        mask = self._maximum_height_normalize(landmark_mask, character)
        return GlyphField(
            source=source,
            character=character,
            mask=mask,
            sdf=self.signed_distance(mask),
            advance=source.widths[ord(character)],
            bounds=bounds,
        )

    @staticmethod
    def topology(mask: np.ndarray) -> dict[str, int]:
        structure = np.ones((3, 3), dtype=np.uint8)
        components = int(ndimage.label(mask, structure=structure)[1])
        outside_labels, outside_count = ndimage.label(~mask, structure=structure)
        border_labels = np.unique(np.concatenate((
            outside_labels[0], outside_labels[-1],
            outside_labels[:, 0], outside_labels[:, -1],
        )))
        holes = sum(
            label not in border_labels for label in range(1, outside_count + 1)
        )
        return {"components": components, "holes": int(holes)}

    def field_distance(self, a: np.ndarray, b: np.ndarray) -> float:
        band = self.distance_band
        clipped_a = np.clip(a, -band, band)
        clipped_b = np.clip(b, -band, band)
        relevant = (np.abs(a) < band) | (np.abs(b) < band)
        if not np.any(relevant):
            return 0.0
        return float(np.sqrt(np.mean((clipped_a[relevant] - clipped_b[relevant]) ** 2)))

    @staticmethod
    def consensus_topology(fields: list[GlyphField]) -> dict[str, int]:
        topologies = [EikonalMidpointEngine.topology(field.mask) for field in fields]
        pairs = [(item["components"], item["holes"]) for item in topologies]
        # Deterministic mode: prefer the most frequent topology, then the
        # simpler topology if frequencies tie.
        selected = min(set(pairs), key=lambda pair: (-pairs.count(pair), sum(pair), pair))
        return {"components": selected[0], "holes": selected[1]}

    def topology_constrained_level(
        self, raw: np.ndarray, fields: list[GlyphField]
    ) -> tuple[float, np.ndarray, dict[str, int]]:
        expected = self.consensus_topology(fields)
        target_area = float(np.mean([np.count_nonzero(field.mask) for field in fields]))
        candidates = []
        # Half-unit resolution at the default grid is substantially below the
        # eventual outline-fitting tolerance while remaining deterministic.
        for level in np.linspace(-self.distance_band, self.distance_band, 321):
            mask = raw <= level
            topology = self.topology(mask)
            if topology != expected:
                continue
            # A valid component must survive a small inward offset; otherwise
            # two lobes touching at a pixel would satisfy topology without
            # producing a manufacturable glyph. Counters must likewise survive
            # a small outward offset.
            inner = self.topology(raw <= level - self.topology_margin)
            outer = self.topology(raw <= level + self.topology_margin)
            if inner["components"] != expected["components"]:
                continue
            if outer["holes"] != expected["holes"]:
                continue
            area_error = abs(np.count_nonzero(mask) - target_area) / max(target_area, 1.0)
            level_penalty = 0.02 * abs(level) / self.distance_band
            candidates.append((area_error + level_penalty, abs(level), level, mask))
        if not candidates:
            return 0.0, raw <= 0.0, expected
        _, _, level, mask = min(candidates, key=lambda item: item[:3])
        return float(level), mask, expected

    def midpoint(self, character: str) -> MidpointGlyph:
        active = self.active_sources(character)
        if not active:
            raise ValueError(f"No active source contains {character!r}")
        fields = [self.source_field(source, character) for source in active]
        raw = np.mean([field.sdf for field in fields], axis=0)
        if self.field_smoothing > 0:
            raw = ndimage.gaussian_filter(
                raw,
                sigma=self.field_smoothing * self.pixels_per_unit,
                mode="nearest",
            )
        raw_mask = raw <= 0.0
        selected_level, mask, expected_topology = self.topology_constrained_level(raw, fields)
        reinitialized = self.signed_distance(mask)
        pairwise = []
        for i, left in enumerate(fields):
            for right in fields[i + 1:]:
                pairwise.append({
                    "left": left.source.filename,
                    "right": right.source.filename,
                    "distance": self.field_distance(left.sdf, right.sdf),
                })
        source_distances = {
            field.source.filename: self.field_distance(reinitialized, field.sdf)
            for field in fields
        }
        dominance = {}
        for field in fields:
            other_distances = [
                self.field_distance(field.sdf, other.sdf)
                for other in fields if other is not field
            ]
            reference = float(np.median(other_distances)) if other_distances else math.inf
            ratio = source_distances[field.source.filename] / reference
            dominance[field.source.filename] = {
                "ratio": ratio,
                "flag": bool(ratio < 0.35),
            }
        diagnostics = {
            "character": character,
            "codepoint": f"U+{ord(character):04X}",
            "activeSources": [field.source.filename for field in fields],
            "equalWeight": 1.0 / len(fields),
            "targetLandmarks": self.target_landmarks.__dict__,
            "advance": float(np.mean([field.advance for field in fields])),
            "sourceDistances": source_distances,
            "pairwiseDistances": pairwise,
            "dominance": dominance,
            "sourceTopology": {
                field.source.filename: self.topology(field.mask) for field in fields
            },
            "consensusTopology": expected_topology,
            "rawMidpointTopology": self.topology(raw_mask),
            "topologyConstrainedLevel": selected_level,
            "midpointTopology": self.topology(mask),
        }
        return MidpointGlyph(
            character=character,
            sources=fields,
            raw_field=raw,
            raw_mask=raw_mask,
            mask=mask,
            sdf=reinitialized,
            selected_level=selected_level,
            advance=diagnostics["advance"],
            diagnostics=diagnostics,
        )

    def write_engine_report(self, path: Path) -> None:
        report = {
            "sources": [
                {
                    "file": source.filename,
                    "family": source.family,
                    "unitsPerEm": source.upm,
                    "landmarksNormalizedTo1000UPM": source.landmarks.__dict__,
                }
                for source in self.sources
            ],
            "targetLandmarks": self.target_landmarks.__dict__,
            "grid": {
                "pixelsPerUnit": self.pixels_per_unit,
                "xMin": self.x_min,
                "xMax": self.x_max,
                "yMin": self.y_min,
                "yMax": self.y_max,
                "distanceBand": self.distance_band,
                "fieldSmoothing": self.field_smoothing,
                "topologyMargin": self.topology_margin,
            },
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2) + "\n")


def render_midpoint_study(result: MidpointGlyph, destination: Path) -> None:
    """Render source masks, raw zero set, and reinitialized midpoint."""
    tile_w, tile_h = 330, 360
    columns = 3
    entries = [(field.source.family, field.mask) for field in result.sources]
    entries.extend((
        ("Raw field ≤ 0", result.raw_mask),
        (f"Portsmouth · level {result.selected_level:+.1f}", result.mask),
    ))
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new(
        "RGB", (columns * tile_w + 80, rows * tile_h + 150), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    title_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 34
    )
    label_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 20
    )
    small_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 15
    )
    draw.text((40, 30), f"Portsmouth Eikonal midpoint — {result.character}", fill="#111", font=title_font)
    draw.text(
        (40, 78),
        f"{len(result.sources)} active sources · equal weight {1/len(result.sources):.3f}",
        fill="#56514a", font=small_font,
    )
    for index, (label, mask) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
            radius=10, fill="#fffdf8", outline="#d0cabf", width=2,
        )
        ys, xs = np.nonzero(mask)
        if len(xs):
            left, right = max(0, xs.min() - 20), min(mask.shape[1], xs.max() + 21)
            top, bottom = max(0, ys.min() - 20), min(mask.shape[0], ys.max() + 21)
            crop = (mask[top:bottom, left:right] * 255).astype(np.uint8)
            glyph = Image.fromarray(255 - crop, "L").convert("RGB")
            glyph.thumbnail((tile_w - 60, tile_h - 100), Image.Resampling.LANCZOS)
            gx = x0 + (tile_w - 20 - glyph.width) // 2
            gy = y0 + 62 + (tile_h - 100 - glyph.height) // 2
            canvas.paste(glyph, (gx, gy))
        draw.text((x0 + 16, y0 + 16), label, fill="#151515", font=label_font)
    destination.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(destination)
