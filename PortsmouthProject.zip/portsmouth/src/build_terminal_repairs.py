#!/usr/bin/env python3
"""Generate localized terminal repairs for Portsmouth J and numeral 1."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex, resample_closed
from outline_geometry import union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask
from vectorize import signed_area


def current(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            with np.load(path, allow_pickle=False) as archive:
                return max(
                    (archive[key].astype(float) for key in archive.files if key not in {"character", "unitsPerEm"}),
                    key=lambda points: abs(signed_area(points)),
                )
    raise FileNotFoundError(character)


def orient(points: np.ndarray) -> np.ndarray:
    return points if signed_area(points) > 0.0 else points[::-1]


def clip_y(points: np.ndarray, cut: float, *, keep_below: bool) -> np.ndarray:
    output = []
    previous = points[-1]
    previous_inside = previous[1] <= cut if keep_below else previous[1] >= cut
    for value in points:
        inside = value[1] <= cut if keep_below else value[1] >= cut
        if inside != previous_inside:
            fraction = (cut - previous[1]) / (value[1] - previous[1])
            output.append(previous + fraction * (value - previous))
        if inside:
            output.append(value)
        previous, previous_inside = value, inside
    result = np.asarray(output, dtype=float)
    if len(result) < 3:
        raise ValueError("Clipping collapsed terminal body")
    return orient(result)


def rectangle(x0: float, y0: float, x1: float, y1: float) -> np.ndarray:
    return np.asarray([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], dtype=float)


def horizontal_capsule(x0: float, y0: float, x1: float, y1: float, samples=96) -> np.ndarray:
    radius = 0.5 * (y1 - y0)
    left, right = x0 + radius, x1 - radius
    center_y = 0.5 * (y0 + y1)
    right_angles = np.linspace(-math.pi / 2, math.pi / 2, samples // 2, endpoint=False)
    left_angles = np.linspace(math.pi / 2, 3 * math.pi / 2, samples // 2, endpoint=False)
    points = np.vstack((
        np.column_stack((right + radius * np.cos(right_angles), center_y + radius * np.sin(right_angles))),
        np.column_stack((left + radius * np.cos(left_angles), center_y + radius * np.sin(left_angles))),
    ))
    return orient(points)


def union(paths):
    complex_ = union_contour_complex([orient(path) for path in paths], pixels_per_unit=5.0)
    outer = max(complex_.outer, key=lambda loop: loop.area)
    return resample_closed(outer.points, 10240)


def j_candidate(kind: str) -> np.ndarray:
    source = current("J")
    body = clip_y(source, 500.0, keep_below=True)
    stem = rectangle(92.0, 470.0, 208.0, 665.0)
    if kind == "stem":
        cap = horizontal_capsule(92.0, 620.0, 208.0, 700.0)
    elif kind == "restrained":
        cap = horizontal_capsule(-70.0, 620.0, 220.0, 700.0)
    elif kind == "full":
        cap = horizontal_capsule(-170.0, 620.0, 220.0, 700.0)
    else:
        raise ValueError(kind)
    return union([body, stem, cap])


def one_candidate(width: float) -> np.ndarray:
    source = current("1")
    body = clip_y(source, 125.0, keep_below=False)
    stem = rectangle(-43.0, 45.0, 49.0, 155.0)
    foot = horizontal_capsule(-width / 2.0, -8.0, width / 2.0, 72.0)
    return union([body, stem, foot])


def archive(character: str, label: str, points: np.ndarray) -> str:
    stem = f"{ord(character):04x}"
    path = PROJECT / "geometry" / f"terminal-repair-{stem}-{label}.npz"
    np.savez_compressed(
        path,
        outer_0=points.astype(np.float32),
        character=np.asarray(character),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    return str(path.relative_to(PROJECT))


def render(character: str, candidates, output):
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    entries = [("Current Portsmouth 0.015", current(character), "protected baseline")]
    entries += candidates
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label_font = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — localized terminal repair", fill="#111", font=title)
    draw.text((40, 78), "accepted body preserved · only the flagged terminal is reconstructed", fill="#575149", font=small)
    for index, (name, points, subtitle) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_w, 120 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        mask = rasterize_contour_complex(engine, [("outer", points)])
        glyph = _render_mask(mask, (tile_w - 70, tile_h - 105))
        canvas.paste(glyph, (x0 + (tile_w - 20 - glyph.width) // 2, y0 + 63 + (tile_h - 105 - glyph.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label_font)
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    canvas.save(output)


def main() -> None:
    j = [(kind, j_candidate(kind)) for kind in ("stem", "restrained", "full")]
    one = [(str(int(width)), one_candidate(width)) for width in (300.0, 360.0, 420.0)]
    report = {
        "J": [
            {"candidate": name, "geometry": archive("J", name, points)}
            for name, points in j
        ],
        "1": [
            {"candidate": name, "geometry": archive("1", name, points)}
            for name, points in one
        ],
        "replacesCurrentGeometry": False,
        "visualReview": None,
    }
    (PROJECT / "reports" / "terminal-repairs-J1.json").write_text(json.dumps(report, indent=2) + "\n")
    render("J", [(f"Candidate · {name}", points, "top terminal only") for name, points in j], PROJECT / "specimens" / "terminal-repair-004a.png")
    render("1", [(f"Candidate · {name}", points, "symmetric foot width") for name, points in one], PROJECT / "specimens" / "terminal-repair-0031.png")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
