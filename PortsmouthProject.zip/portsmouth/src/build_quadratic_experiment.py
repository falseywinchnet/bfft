#!/usr/bin/env python3
"""Build an isolated quadratic-outline experiment from Portsmouth geometry."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

from build_first_ttf import (
    GRAPHIC_CODEPOINTS,
    MINIMUM_SIDEBEARING,
    archived_contours,
    empty_glyph,
    geometry_for,
    glyph_name,
    mean_advance,
    notdef_glyph,
    simplify_closed,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from vectorize import signed_area


SOURCE_VERSION = "0.015"
EXPERIMENT_VERSION = "0.015-q1"
FONT_REVISION = 0.0151
KNOT_TOLERANCE = 2.2
SMOOTH_TURN_DEGREES = 32.0
MAXIMUM_CORNER_CUT = 16.0


def quadratic_outline_glyph(contours, advance: int):
    prepared = []
    original_points = 0
    for role, points in contours:
        original_points += len(points)
        contour = simplify_closed(points, KNOT_TOLERANCE)
        area = signed_area(contour)
        should_be_clockwise = role == "outer"
        if (area < 0.0) != should_be_clockwise:
            contour = contour[::-1]
        prepared.append((role, contour))
    minimum_x = min(float(np.min(points[:, 0])) for _, points in prepared)
    maximum_x = max(float(np.max(points[:, 0])) for _, points in prepared)
    shift = advance / 2.0
    pen = TTGlyphPen(None)
    on_curve = 0
    quadratic_controls = 0
    contour_count = 0
    for _, contour in prepared:
        points = contour + np.array([shift, 0.0])
        previous = np.roll(points, 1, axis=0)
        following = np.roll(points, -1, axis=0)
        incoming = points - previous
        outgoing = following - points
        in_length = np.linalg.norm(incoming, axis=1)
        out_length = np.linalg.norm(outgoing, axis=1)
        valid = (in_length > 1e-6) & (out_length > 1e-6)
        in_unit = incoming / np.maximum(in_length[:, None], 1e-9)
        out_unit = outgoing / np.maximum(out_length[:, None], 1e-9)
        turn = np.degrees(np.arccos(np.clip(np.sum(in_unit * out_unit, axis=1), -1.0, 1.0)))
        smooth = valid & (turn > 0.35) & (turn < SMOOTH_TURN_DEGREES)
        cut = np.minimum(
            np.minimum(0.22 * in_length, 0.22 * out_length), MAXIMUM_CORNER_CUT
        )
        cut = np.where(smooth, cut, 0.0)
        arrival = points - in_unit * cut[:, None]
        departure = points + out_unit * cut[:, None]
        arrival = np.rint(arrival).astype(np.int32)
        departure = np.rint(departure).astype(np.int32)
        controls = np.rint(points).astype(np.int32)
        start = tuple(map(int, departure[0]))
        pen.moveTo(start)
        current = start
        for index in list(range(1, len(points))) + [0]:
            incoming_point = tuple(map(int, arrival[index]))
            outgoing_point = tuple(map(int, departure[index]))
            control = tuple(map(int, controls[index]))
            if incoming_point != current:
                pen.lineTo(incoming_point)
                current = incoming_point
                on_curve += 1
            if smooth[index] and outgoing_point != current:
                pen.qCurveTo(control, outgoing_point)
                current = outgoing_point
                on_curve += 1
                quadratic_controls += 1
        pen.closePath()
        contour_count += 1
    left = int(math.floor(minimum_x + shift))
    right = int(math.ceil(maximum_x + shift))
    return pen.glyph(), left, {
        "originalPoints": original_points,
        "simplifiedKnots": sum(len(points) for _, points in prepared),
        "outputOnCurvePoints": on_curve,
        "quadraticControls": quadratic_controls,
        "contours": contour_count,
        "xMin": left,
        "xMax": right,
        "leftSidebearing": left,
        "rightSidebearing": advance - right,
    }


def render_comparison(current: Path, experiment: Path) -> Path:
    canvas = Image.new("RGB", (1800, 1320), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 17)
    draw.text((55, 30), "Portsmouth quadratic isolation test", fill="#111", font=title)
    draw.text((55, 78), "left: protected polygonal 0.015 · right: quadratic q1 · separate family and build path", fill="#5d574e", font=label)
    samples = [
        "Portsmouth / aquamarine quays",
        "a q æ m w S 8 @ Ø ø",
        "minimum",
    ]
    y = 135
    for size in (18, 28, 44, 72, 112):
        left = ImageFont.truetype(current, size)
        right = ImageFont.truetype(experiment, size)
        text = samples[min(len(samples) - 1, 0 if size < 40 else 1 if size < 90 else 2)]
        draw.text((70, y), text, fill="#171715", font=left)
        draw.text((920, y), text, fill="#171715", font=right)
        draw.text((70, y - 22), f"polygonal · {size}px", fill="#776f65", font=label)
        draw.text((920, y - 22), f"quadratic · {size}px", fill="#776f65", font=label)
        y += size + 82
    draw.line((875, 115, 875, 1260), fill="#c8c0b4", width=2)
    output = PROJECT / "specimens" / "experimental" / f"Portsmouth-Quadratic-{EXPERIMENT_VERSION}-comparison.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    return output


def build():
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    archived = [cp for cp in GRAPHIC_CODEPOINTS if geometry_for(cp) is not None]
    cmap_codepoints = sorted(set(archived) | {0x20, 0xA0})
    names = {cp: glyph_name(cp) for cp in cmap_codepoints}
    glyph_order = [".notdef"] + [names[cp] for cp in cmap_codepoints]
    glyphs = {".notdef": notdef_glyph()}
    metrics = {".notdef": (600, 55)}
    cmap = {cp: names[cp] for cp in cmap_codepoints}
    report_glyphs = []
    space_width = int(round(float(np.mean([
        source.widths[0x20] for source in engine.sources
        if source.filename in {
            "AnnotationMono-VF.ttf", "ComicShannsMono-Regular.ttf", "routed-gothic.ttf"
        }
    ]))))
    for cp in cmap_codepoints:
        name = names[cp]
        path = geometry_for(cp)
        if path is None:
            glyphs[name] = empty_glyph()
            metrics[name] = (space_width, 0)
            continue
        contours = archived_contours(path)
        all_points = np.vstack([points for _, points in contours])
        width = float(np.ptp(all_points[:, 0]))
        desired_advance = mean_advance(engine, chr(cp))
        advance = int(math.ceil(max(desired_advance, width + 2 * MINIMUM_SIDEBEARING)))
        glyph, lsb, detail = quadratic_outline_glyph(contours, advance)
        glyphs[name] = glyph
        metrics[name] = (advance, lsb)
        report_glyphs.append({"codepoint": f"U+{cp:04X}", "character": chr(cp), **detail})

    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=850, descent=-250, lineGap=0)
    fb.setupNameTable({
        "familyName": "Portsmouth Quadratic Test",
        "styleName": "Regular",
        "uniqueFontIdentifier": f"Portsmouth Quadratic Test {EXPERIMENT_VERSION}",
        "fullName": "Portsmouth Quadratic Test Regular",
        "psName": "PortsmouthQuadraticTest-Regular",
        "version": f"Version {EXPERIMENT_VERSION}",
        "copyright": "Isolated Portsmouth outline experiment; provenance in PROJECT.md",
        "licenseDescription": "Experimental personal and artistic evaluation build.",
    })
    target = engine.target_landmarks
    fb.setupOS2(
        sTypoAscender=850, sTypoDescender=-250, sTypoLineGap=0,
        usWinAscent=1050, usWinDescent=400,
        sxHeight=int(round(target.xheight)), sCapHeight=int(round(target.capheight)),
        usWeightClass=400, usWidthClass=5, fsType=0, fsSelection=0x40,
        achVendID="PRTQ", ulUnicodeRange1=0x00000003, ulCodePageRange1=0x00000001,
    )
    fb.setupPost(isFixedPitch=0)
    fb.setupMaxp()
    fb.font["head"].fontRevision = FONT_REVISION
    destination = PROJECT / "build" / "experimental" / f"Portsmouth-Quadratic-{EXPERIMENT_VERSION}.ttf"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fb.save(destination)
    font = TTFont(destination, lazy=False, recalcBBoxes=True)
    if len(font.getBestCmap()) != len(cmap):
        raise ValueError("Quadratic experiment cmap mismatch")
    font.close()
    current = PROJECT / "build" / f"Portsmouth-Regular-{SOURCE_VERSION}.ttf"
    comparison = render_comparison(current, destination)
    report = {
        "font": str(destination.relative_to(PROJECT)),
        "sourceMaster": str(current.relative_to(PROJECT)),
        "familyIsolation": "Portsmouth Quadratic Test",
        "sourceVersion": SOURCE_VERSION,
        "experimentVersion": EXPERIMENT_VERSION,
        "knotTolerance": KNOT_TOLERANCE,
        "smoothTurnThresholdDegrees": SMOOTH_TURN_DEGREES,
        "maximumCornerCut": MAXIMUM_CORNER_CUT,
        "glyphCountIncludingNotdef": len(glyph_order),
        "glyphs": report_glyphs,
        "comparison": str(comparison.relative_to(PROJECT)),
    }
    report_path = PROJECT / "reports" / f"quadratic-experiment-{EXPERIMENT_VERSION}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "glyphs"}, indent=2))
    return destination, comparison


if __name__ == "__main__":
    build()
