#!/usr/bin/env python3
"""Periodic event-aware Makima masters and adaptive quadratic compilation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.interpolate import Akima1DInterpolator
from scipy.spatial import cKDTree

from build_first_ttf import simplify_closed


@dataclass(frozen=True)
class CubicSegment:
    points: np.ndarray
    hard_start: bool
    hard_end: bool


@dataclass(frozen=True)
class QuadraticSegment:
    start: np.ndarray
    control: np.ndarray | None
    end: np.ndarray
    error: float


@dataclass(frozen=True)
class MakimaMaster:
    dense: np.ndarray
    knot_indices: np.ndarray
    hard_indices: frozenset[int]
    cubics: tuple[CubicSegment, ...]
    maximum_error: float
    maximum_normal_error: float
    refinement_passes: int


def _arc_parameter(points: np.ndarray) -> tuple[np.ndarray, float]:
    closing = np.vstack((points, points[0]))
    lengths = np.linalg.norm(np.diff(closing, axis=0), axis=1)
    lengths = np.maximum(lengths, 1e-9)
    parameter = np.concatenate(([0.0], np.cumsum(lengths[:-1])))
    return parameter, float(np.sum(lengths))


def _turn_degrees(points: np.ndarray) -> np.ndarray:
    incoming = points - np.roll(points, 1, axis=0)
    outgoing = np.roll(points, -1, axis=0) - points
    incoming /= np.maximum(np.linalg.norm(incoming, axis=1)[:, None], 1e-9)
    outgoing /= np.maximum(np.linalg.norm(outgoing, axis=1)[:, None], 1e-9)
    return np.degrees(np.arccos(np.clip(np.sum(incoming * outgoing, axis=1), -1.0, 1.0)))


def _initial_knots(
    points: np.ndarray,
    *,
    simplification_tolerance: float,
    corner_degrees: float,
) -> tuple[np.ndarray, frozenset[int]]:
    simplified = simplify_closed(points, simplification_tolerance)
    tree = cKDTree(points)
    indices = set(map(int, tree.query(simplified)[1]))
    indices.update({
        0,
        int(np.argmin(points[:, 0])),
        int(np.argmax(points[:, 0])),
        int(np.argmin(points[:, 1])),
        int(np.argmax(points[:, 1])),
    })
    ordered = np.asarray(sorted(indices), dtype=np.int32)
    knot_points = points[ordered]
    turns = _turn_degrees(knot_points)
    hard = frozenset(int(index) for index, turn in zip(ordered, turns) if turn >= corner_degrees)
    return ordered, hard


def _periodic_makima_derivatives(
    knot_parameter: np.ndarray,
    knot_points: np.ndarray,
    perimeter: float,
) -> np.ndarray:
    count = len(knot_points)
    reach = min(3, count)
    extended_s = np.concatenate((
        knot_parameter[-reach:] - perimeter,
        knot_parameter,
        knot_parameter[:reach] + perimeter,
    ))
    extended_points = np.vstack((knot_points[-reach:], knot_points, knot_points[:reach]))
    derivatives = []
    for dimension in range(2):
        interpolator = Akima1DInterpolator(
            extended_s,
            extended_points[:, dimension],
            method="makima",
            extrapolate=True,
        )
        derivatives.append(interpolator.derivative()(knot_parameter))
    return np.column_stack(derivatives)


def _cubic_segments(
    points: np.ndarray,
    parameter: np.ndarray,
    perimeter: float,
    knot_indices: np.ndarray,
    hard_indices: frozenset[int],
) -> tuple[CubicSegment, ...]:
    knot_s = parameter[knot_indices]
    knot_points = points[knot_indices]
    derivatives = _periodic_makima_derivatives(knot_s, knot_points, perimeter)
    segments = []
    count = len(knot_indices)
    for position in range(count):
        following = (position + 1) % count
        start_index = int(knot_indices[position])
        end_index = int(knot_indices[following])
        start_s = float(knot_s[position])
        end_s = float(knot_s[following]) + (perimeter if following == 0 else 0.0)
        span = end_s - start_s
        start = knot_points[position]
        end = knot_points[following]
        chord_derivative = (end - start) / max(span, 1e-9)
        start_derivative = chord_derivative if start_index in hard_indices else derivatives[position]
        end_derivative = chord_derivative if end_index in hard_indices else derivatives[following]
        cubic = np.vstack((
            start,
            start + start_derivative * span / 3.0,
            end - end_derivative * span / 3.0,
            end,
        ))
        segments.append(CubicSegment(
            points=cubic,
            hard_start=start_index in hard_indices,
            hard_end=end_index in hard_indices,
        ))
    return tuple(segments)


def evaluate_cubic(control: np.ndarray, t: np.ndarray) -> np.ndarray:
    t = np.asarray(t, dtype=np.float64)
    omt = 1.0 - t
    return (
        omt[:, None] ** 3 * control[0]
        + 3.0 * omt[:, None] ** 2 * t[:, None] * control[1]
        + 3.0 * omt[:, None] * t[:, None] ** 2 * control[2]
        + t[:, None] ** 3 * control[3]
    )


def _master_error(
    points: np.ndarray,
    parameter: np.ndarray,
    perimeter: float,
    knot_indices: np.ndarray,
    cubics: tuple[CubicSegment, ...],
) -> tuple[float, float, list[tuple[float, int]]]:
    tangent = np.roll(points, -4, axis=0) - np.roll(points, 4, axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1)[:, None], 1e-9)
    normal = np.column_stack((-tangent[:, 1], tangent[:, 0]))
    maxima = []
    maximum = maximum_normal = 0.0
    for position, cubic in enumerate(cubics):
        start = int(knot_indices[position])
        end = int(knot_indices[(position + 1) % len(knot_indices)])
        if end > start:
            indices = np.arange(start, end + 1)
            sample_s = parameter[indices]
            start_s, end_s = parameter[start], parameter[end]
        else:
            indices = np.concatenate((np.arange(start, len(points)), np.arange(0, end + 1)))
            sample_s = np.concatenate((parameter[start:], parameter[:end + 1] + perimeter))
            start_s, end_s = parameter[start], parameter[end] + perimeter
        t = (sample_s - start_s) / max(end_s - start_s, 1e-9)
        fitted = evaluate_cubic(cubic.points, t)
        delta = fitted - points[indices]
        error = np.linalg.norm(delta, axis=1)
        normal_error = np.abs(np.sum(delta * normal[indices], axis=1))
        local = int(np.argmax(error))
        maxima.append((float(error[local]), int(indices[local])))
        maximum = max(maximum, float(np.max(error)))
        maximum_normal = max(maximum_normal, float(np.max(normal_error)))
    return maximum, maximum_normal, maxima


def periodic_makima_master(
    dense: np.ndarray,
    *,
    simplification_tolerance: float = 1.15,
    master_tolerance: float = 0.65,
    corner_degrees: float = 24.0,
    maximum_passes: int = 12,
) -> MakimaMaster:
    points = np.asarray(dense, dtype=np.float64)
    if len(points) > 1 and np.allclose(points[0], points[-1]):
        points = points[:-1]
    parameter, perimeter = _arc_parameter(points)
    knots, hard = _initial_knots(
        points,
        simplification_tolerance=simplification_tolerance,
        corner_degrees=corner_degrees,
    )
    passes = 0
    for passes in range(maximum_passes + 1):
        cubics = _cubic_segments(points, parameter, perimeter, knots, hard)
        maximum, maximum_normal, maxima = _master_error(points, parameter, perimeter, knots, cubics)
        additions = {
            index for error, index in maxima
            if error > master_tolerance and index not in set(map(int, knots))
        }
        if not additions:
            break
        knots = np.asarray(sorted(set(map(int, knots)) | additions), dtype=np.int32)
    else:
        raise ValueError("Makima master did not converge within its refinement budget")
    return MakimaMaster(
        dense=points,
        knot_indices=knots,
        hard_indices=hard,
        cubics=cubics,
        maximum_error=maximum,
        maximum_normal_error=maximum_normal,
        refinement_passes=passes,
    )


def _split_cubic(control: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = 0.5 * (control[0] + control[1])
    b = 0.5 * (control[1] + control[2])
    c = 0.5 * (control[2] + control[3])
    d = 0.5 * (a + b)
    e = 0.5 * (b + c)
    midpoint = 0.5 * (d + e)
    return np.vstack((control[0], a, d, midpoint)), np.vstack((midpoint, e, c, control[3]))


def _tangent_intersection(control: np.ndarray) -> np.ndarray:
    start, end = control[0], control[3]
    first = control[1] - start
    last = control[2] - end
    matrix = np.column_stack((first, -last))
    determinant = float(np.linalg.det(matrix))
    chord = max(float(np.linalg.norm(end - start)), 1e-9)
    if abs(determinant) > 1e-8 * chord * chord:
        factors = np.linalg.solve(matrix, end - start)
        candidate = start + factors[0] * first
        if np.linalg.norm(candidate - 0.5 * (start + end)) <= 5.0 * chord:
            return candidate
    from_start = (3.0 * control[1] - start) / 2.0
    from_end = (3.0 * control[2] - end) / 2.0
    return 0.5 * (from_start + from_end)


def _quadratic_error(control: np.ndarray, quadratic_control: np.ndarray) -> float:
    t = np.linspace(0.0, 1.0, 25)
    cubic = evaluate_cubic(control, t)
    omt = 1.0 - t
    quadratic = (
        omt[:, None] ** 2 * control[0]
        + 2.0 * omt[:, None] * t[:, None] * quadratic_control
        + t[:, None] ** 2 * control[3]
    )
    return float(np.max(np.linalg.norm(cubic - quadratic, axis=1)))


def _line_error(control: np.ndarray) -> float:
    chord = control[3] - control[0]
    denominator = max(float(np.dot(chord, chord)), 1e-9)
    errors = []
    for point in control[1:3]:
        fraction = np.clip(float(np.dot(point - control[0], chord)) / denominator, 0.0, 1.0)
        errors.append(float(np.linalg.norm(point - (control[0] + fraction * chord))))
    return max(errors)


def cubic_to_quadratics(
    control: np.ndarray,
    *,
    tolerance: float = 0.42,
    line_tolerance: float = 0.10,
    maximum_depth: int = 12,
) -> list[QuadraticSegment]:
    result: list[QuadraticSegment] = []

    def visit(cubic: np.ndarray, depth: int) -> None:
        if _line_error(cubic) <= line_tolerance:
            result.append(QuadraticSegment(cubic[0], None, cubic[3], _line_error(cubic)))
            return
        quadratic_control = _tangent_intersection(cubic)
        error = _quadratic_error(cubic, quadratic_control)
        if error <= tolerance:
            result.append(QuadraticSegment(cubic[0], quadratic_control, cubic[3], error))
            return
        if depth >= maximum_depth:
            raise ValueError(f"Quadratic subdivision exceeded depth {maximum_depth}: {error}")
        left, right = _split_cubic(cubic)
        visit(left, depth + 1)
        visit(right, depth + 1)

    visit(np.asarray(control, dtype=np.float64), 0)
    return result


def compile_master(
    master: MakimaMaster,
    *,
    quadratic_tolerance: float = 0.42,
    line_tolerance: float = 0.10,
) -> list[QuadraticSegment]:
    result = []
    for cubic in master.cubics:
        result.extend(cubic_to_quadratics(
            cubic.points,
            tolerance=quadratic_tolerance,
            line_tolerance=line_tolerance,
        ))
    return result
