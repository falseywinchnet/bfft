#!/usr/bin/env python3
"""Render the unresolved Portsmouth Latin-1 source topologies for review."""

from __future__ import annotations

import argparse
import json
import math
import unicodedata

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


ORIGINAL_CONFLICTS = "@àáâãåèéêñõ"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predecision", action="store_true")
    arguments = parser.parse_args()
    audit = json.loads((PROJECT / "reports" / "first256-coverage-audit.json").read_text())
    if arguments.predecision:
        conflicts = [{
            "character": character,
            "codepoint": f"U+{ord(character):04X}",
            "name": unicodedata.name(character),
        } for character in ORIGINAL_CONFLICTS]
    else:
        conflicts = audit["unresolvedTopologyConflicts"]
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    source_columns = [
        "AnnotationMono-VF.ttf",
        "ComicShannsMono-Regular.ttf",
        "bedstead.otf",
        "routed-gothic.ttf",
    ]
    column_width, row_height = 270, 255
    width = 240 + len(source_columns) * column_width
    height = 175 + len(conflicts) * row_height
    canvas = Image.new("RGB", (width, height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 32)
    label = ImageFont.truetype(ui, 16)
    small = ImageFont.truetype(ui, 13)
    draw.text((30, 24), "Portsmouth · unresolved Latin-1 topology", fill="#111", font=title)
    draw.text(
        (30, 72),
        "Rendered source behavior after normalization · blanks mean that source is not routed",
        fill="#5c554c",
        font=small,
    )
    for column, filename in enumerate(source_columns):
        short = filename.replace("-Regular", "").replace(".ttf", "").replace(".otf", "")
        draw.text((230 + column * column_width, 125), short, fill="#252321", font=label)
    source_by_name = {source.filename: source for source in engine.sources}
    for row, conflict in enumerate(conflicts):
        character = conflict["character"]
        y0 = 165 + row * row_height
        draw.line((25, y0, width - 25, y0), fill="#cfc7bb", width=1)
        draw.text((35, y0 + 25), repr(character), fill="#111", font=title)
        draw.text((35, y0 + 70), conflict["codepoint"], fill="#625b52", font=small)
        draw.text((35, y0 + 94), conflict["name"], fill="#625b52", font=small)
        for column, filename in enumerate(source_columns):
            source = source_by_name[filename]
            if ord(character) not in source.cmap or source not in engine.active_sources(character):
                continue
            field = engine.source_field(source, character)
            image = _render_mask(field.mask, (170, 185))
            x = 230 + column * column_width + (170 - image.width) // 2
            y = y0 + 42 + (185 - image.height) // 2
            canvas.paste(image, (x, y))
            topology = engine.topology(field.mask)
            draw.text(
                (225 + column * column_width, y0 + 225),
                f"{topology['components']} component(s) · {topology['holes']} hole(s)",
                fill="#625b52",
                font=small,
            )
    filename = (
        "latin1-topology-conflicts-predecision.png"
        if arguments.predecision else "latin1-topology-conflicts.png"
    )
    output = PROJECT / "specimens" / filename
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
