#!/usr/bin/env python3
"""Render a programming specimen for standalone Portsmouth Mono 1.0."""

from __future__ import annotations

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT


BLOCKS = (
    ("PYTHON / STRUCTURE", (
        "from dataclasses import dataclass",
        "",
        "@dataclass(frozen=True)",
        "class Glyph:",
        "    codepoint: int",
        "    advance: float = 575.0",
        "",
        "def classify(mark: str) -> str:",
        "    if mark in {\"1\", \"l\", \"I\", \"|\"}:",
        "        return f\"{mark!r}: distinct\"",
        "    return \"ordinary\"",
    )),
    ("TYPESCRIPT / PUNCTUATION", (
        "type Result<T> = { ok: true; value: T }",
        "               | { ok: false; error: Error };",
        "",
        "const range = (start: number, end: number) =>",
        "  Array.from({ length: end - start }, (_, i) => i + start);",
        "",
        "for (const cp of range(0x20, 0x100)) {",
        "  console.log(`U+${cp.toString(16).padStart(4, \"0\")}`);",
        "}",
    )),
    ("SHELL / TERMINAL", (
        "$ git diff --stat",
        " src/build_portsmouth_family.py | 18 +++++++++---",
        "",
        "if [[ -n \"$PORTSMOUTH\" ]]; then",
        "  printf '%s\\n' \"family ready — mono separate\"",
        "fi",
    )),
)


def main() -> None:
    width, height = 2300, 2050
    canvas = Image.new("RGB", (width, height), "#101318")
    draw = ImageDraw.Draw(canvas)
    ui_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui_path, 46)
    ui = ImageFont.truetype(ui_path, 18)
    mono_path = PROJECT / "build/mono/PortsmouthMono.ttf"
    code = ImageFont.truetype(mono_path, 34)
    display = ImageFont.truetype(mono_path, 60)
    draw.text((70, 45), "Portsmouth Mono 1.0 — programming specimen", font=title, fill="#f2eee5")
    draw.text((73, 111), "575-unit cells · literal punctuation · no kerning · no contextual substitutions", font=ui, fill="#9fa8b5")
    draw.text((72, 162), "1lI|  0OØø  {}[]()  != == =>  ::  //  /* */  --  ++  &&  ||", font=display, fill="#e8c98e")
    y = 275
    line_height = 48
    for heading, lines in BLOCKS:
        block_height = 82 + len(lines) * line_height
        draw.rounded_rectangle((55, y, width - 55, y + block_height), radius=12, fill="#171c23", outline="#39414c", width=2)
        draw.text((82, y + 25), heading, font=ui, fill="#d0806e")
        for index, line in enumerate(lines, 1):
            baseline = y + 70 + index * line_height
            draw.text((84, baseline), f"{index:>2}", font=code, fill="#596575", anchor="ls")
            draw.text((165, baseline), line, font=code, fill="#e6e1d8", anchor="ls")
        y += block_height + 34
    output = PROJECT / "specimens/Portsmouth-Mono-1.0-programming.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
