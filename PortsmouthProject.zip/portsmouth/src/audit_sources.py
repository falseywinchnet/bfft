#!/usr/bin/env python3
"""Record source-font metadata and exact shared Unicode coverage."""

from __future__ import annotations

import json
from pathlib import Path

from fontTools.ttLib import TTFont


ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / "portsmouth" / "reports" / "source-audit.json"
SOURCES = (
    "AnnotationMono-VF.ttf",
    "ComicShannsMono-Regular.ttf",
    "SyneMono-Regular.ttf",
    "bedstead.otf",
    "routed-gothic.ttf",
)


def name_values(font: TTFont, name_id: int) -> list[str]:
    values: list[str] = []
    for record in font["name"].names:
        if record.nameID != name_id:
            continue
        try:
            value = record.toUnicode().strip()
        except UnicodeDecodeError:
            continue
        if value and value not in values:
            values.append(value)
    return values


def inspect(path: Path) -> tuple[dict, set[int]]:
    font = TTFont(path, lazy=True)
    cmap = font.getBestCmap() or {}
    os2 = font.get("OS/2")
    hhea = font["hhea"]
    head = font["head"]
    if "glyf" in font:
        outline = "glyf"
    elif "CFF2" in font:
        outline = "CFF2"
    elif "CFF " in font:
        outline = "CFF"
    else:
        outline = "unknown"
    record = {
        "file": path.name,
        "names": {
            str(name_id): name_values(font, name_id)
            for name_id in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13, 14)
        },
        "outline": outline,
        "variable": "fvar" in font,
        "axes": [
            {
                "tag": axis.axisTag,
                "minimum": axis.minValue,
                "default": axis.defaultValue,
                "maximum": axis.maxValue,
            }
            for axis in font["fvar"].axes
        ] if "fvar" in font else [],
        "unitsPerEm": head.unitsPerEm,
        "hhea": {"ascender": hhea.ascent, "descender": hhea.descent},
        "os2": None if os2 is None else {
            "typoAscender": os2.sTypoAscender,
            "typoDescender": os2.sTypoDescender,
            "typoLineGap": os2.sTypoLineGap,
            "xHeight": getattr(os2, "sxHeight", None),
            "capHeight": getattr(os2, "sCapHeight", None),
            "weightClass": os2.usWeightClass,
            "widthClass": os2.usWidthClass,
        },
        "glyphCount": len(font.getGlyphOrder()),
        "unicodeCount": len(cmap),
        "codepoints": sorted(cmap),
    }
    font.close()
    return record, set(cmap)


def main() -> None:
    records = []
    coverage = []
    for filename in SOURCES:
        record, codepoints = inspect(ROOT / filename)
        records.append(record)
        coverage.append(codepoints)
    shared = sorted(set.intersection(*coverage))
    payload = {
        "project": "Portsmouth",
        "sourceRoutes": {
            "AnnotationMono-VF.ttf": "all shared glyphs",
            "ComicShannsMono-Regular.ttf": "all shared glyphs",
            "SyneMono-Regular.ttf": "uppercase letters only",
            "bedstead.otf": "lowercase letters only",
            "routed-gothic.ttf": "all shared glyphs",
        },
        "sources": records,
        "sharedCodepointCount": len(shared),
        "sharedCodepoints": shared,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
