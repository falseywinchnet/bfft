#!/usr/bin/env python3
"""Render normalized source drawings beside current Portsmouth geometry."""

from __future__ import annotations

import argparse
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


def current(character: str):
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            with np.load(path, allow_pickle=False) as archive:
                return [
                    ("hole" if key.startswith("hole") else "outer", archive[key])
                    for key in archive.files
                    if key not in {"character", "unitsPerEm"}
                ]
    raise FileNotFoundError(character)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("character")
    arguments = parser.parse_args()
    if len(arguments.character) != 1:
        raise ValueError("Expected exactly one character")
    character = arguments.character
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    entries = []
    for source in engine.sources:
        if ord(character) in source.cmap:
            field = engine.source_field(source, character)
            entries.append((source.family, field.mask, "normalized source"))
    output_contours = current(character)
    output_mask = rasterize_contour_complex(engine, output_contours)
    entries.append(("Current Portsmouth 0.015", output_mask, str(engine.topology(output_mask))))
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — current construction", fill="#111", font=title)
    draw.text((40, 78), "all normalized sources · current protected outline", fill="#575149", font=small)
    for index, (name, mask, subtitle) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_w, 120 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        glyph = _render_mask(mask, (tile_w - 70, tile_h - 105))
        canvas.paste(glyph, (x0 + (tile_w - 20 - glyph.width) // 2, y0 + 63 + (tile_h - 105 - glyph.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    output = PROJECT / "specimens" / f"current-source-review-{ord(character):04x}.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
