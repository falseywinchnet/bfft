#!/usr/bin/env python3
"""Compose the next Eastern/central Latin set from accepted Portsmouth bodies."""

from __future__ import annotations

import json
import unicodedata

import numpy as np

from build_first_ttf import archived_contours, geometry_for
from family_geometry import mask_topology, rasterize_local
from portsmouth_engine import EikonalMidpointEngine, PROJECT


TARGETS = "ćĈĉčďěĜĝĥķńňŕřśšťůźž"
TEMPLATES = {
    0x0301: ("Á", "á"),
    0x0302: ("Â", "â"),
    0x030A: ("Å", "å"),
    # Lowercase caron candidates are the very set being added here; reuse the
    # accepted fused uppercase caron at a lowercase optical scale.
    0x030C: ("Š", "Š"),
    0x0327: ("Ş", "ş"),
}
SIDE_CARON = {"ď", "ť"}
PARENT_MEDIAN_ACUTE_GAPS = {"ń": 42.3, "ŕ": 42.3, "ś": 39.0}


def contains(points, point):
    x, y = map(float, point)
    x0, y0 = points[:, 0], points[:, 1]
    x1, y1 = np.roll(x0, -1), np.roll(y0, -1)
    divisor = np.where(np.abs(y1 - y0) > 1e-12, y1 - y0, 1.0)
    crossings = ((y0 > y) != (y1 > y)) & (x < (x1 - x0) * (y - y0) / divisor + x0)
    return bool(np.count_nonzero(crossings) % 2)


def area(contours):
    total = 0.0
    for role, points in contours:
        x, y = points[:, 0], points[:, 1]
        value = 0.5 * abs(float(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1))))
        total += value if role == "outer" else -value
    return total


def components(contours):
    outer_indices = [i for i, (role, _) in enumerate(contours) if role == "outer"]
    groups = {i: [contours[i]] for i in outer_indices}
    for role, points in contours:
        if role != "hole":
            continue
        owners = [i for i in outer_indices if contains(contours[i][1], np.mean(points, axis=0))]
        owner = min(owners, key=lambda i: area([contours[i]]))
        groups[owner].append((role, points))
    return list(groups.values())


def bounds(contours):
    points = np.vstack([points for _, points in contours])
    return np.min(points, axis=0), np.max(points, axis=0)


def load(character):
    return [(role, points.astype(np.float64)) for role, points in archived_contours(geometry_for(ord(character)))]


def mark_from_template(template_character):
    groups = components(load(template_character))
    body_index = int(np.argmax([area(group) for group in groups]))
    return groups[body_index], [group for i, group in enumerate(groups) if i != body_index]


def position_marks(character, base, template_body, mark_groups, combining_mark):
    base_min, base_max = bounds(base)
    template_min, template_max = bounds(template_body)
    all_marks = [contour for group in mark_groups for contour in group]
    mark_min, mark_max = bounds(all_marks)
    if combining_mark == 0x0327:
        shift = np.array([
            0.5 * (base_min[0] + base_max[0]) - 0.5 * (mark_min[0] + mark_max[0]),
            base_min[1] - 18.0 - mark_max[1],
        ])
        placement = "centered_below_with_18_unit_gap"
    else:
        gap = PARENT_MEDIAN_ACUTE_GAPS.get(character, 24.0)
        shift = np.array([
            0.5 * (base_min[0] + base_max[0]) - 0.5 * (mark_min[0] + mark_max[0]),
            base_max[1] + gap - mark_min[1],
        ])
        placement = f"centered_above_with_{gap:g}_unit_gap"
    return [
        (role, points + shift)
        for role, points in all_marks
    ], placement, shift


def side_apostrophe(base):
    mark = load("’")[0][1].copy()
    minimum, maximum = np.min(mark, axis=0), np.max(mark, axis=0)
    mark[:, 0] = (mark[:, 0] - minimum[0]) * (95.3 / (maximum[0] - minimum[0]))
    mark[:, 1] = (mark[:, 1] - maximum[1]) * (220.0 / (maximum[1] - minimum[1]))
    base_min, base_max = bounds(base)
    mark[:, 0] += base_max[0] + 26.0
    mark[:, 1] += base_max[1] + 5.0
    return [("outer", mark)], "parent_median_apostrophe_side_caron", np.array([26.0, 5.0])


def main():
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    results = []
    for character in TARGETS:
        decomposition = unicodedata.normalize("NFD", character)
        base_character = decomposition[0]
        mark = ord(decomposition[1])
        base = load(base_character)
        if character in SIDE_CARON:
            template_character = "’"
        elif character == "ķ":
            # Latvian lowercase ķ conventionally takes the same comma-below
            # construction as Ģ rather than an attached cedilla tail.
            template_character = "Ģ"
        else:
            template_character = TEMPLATES[mark][0 if character.isupper() else 1]
        if character in SIDE_CARON:
            marks, placement, shift = side_apostrophe(base)
        else:
            template_body, mark_groups = mark_from_template(template_character)
            if mark == 0x030C and character.islower():
                mark_points = np.vstack([points for group in mark_groups for _, points in group])
                mark_center = 0.5 * (np.min(mark_points, axis=0) + np.max(mark_points, axis=0))
                mark_groups = [
                    [(role, (points - mark_center) * 0.72 + mark_center) for role, points in group]
                    for group in mark_groups
                ]
            marks, placement, shift = position_marks(
                character, base, template_body, mark_groups, mark
            )
        output = base + marks
        mask, _, _ = rasterize_local(output, pixels_per_unit=3.0, padding=12.0)
        topology = mask_topology(mask)
        cp = ord(character)
        path = PROJECT / "geometry" / f"letter-extension-{cp:04x}.npz"
        arrays = {
            f"{role}_{index}": points.astype(np.float32)
            for index, (role, points) in enumerate(output)
        }
        arrays["character"] = np.asarray(character)
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(path, **arrays)
        source_files = [source.filename for source in engine.sources if cp in source.cmap]
        routed_files = [source.filename for source in engine.active_sources(character) if cp in source.cmap]
        report = {
            "character": character,
            "codepoint": f"U+{cp:04X}",
            "name": unicodedata.name(character),
            "status": "experimental_promoted_eastern_latin_composition",
            "baseCharacter": base_character,
            "combiningMark": f"U+{mark:04X}",
            "templateCharacter": template_character,
            "method": "accepted_base_plus_reusable_fused_mark",
            "placement": placement,
            "markShift": shift.tolist(),
            "sourceSupport": source_files,
            "routedSourceSupport": routed_files,
            "topology": topology,
            "geometryArtifact": str(path.relative_to(PROJECT)),
        }
        (PROJECT / "reports" / f"letter-extension-{cp:04x}.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        results.append(report)
    summary = {
        "count": len(results),
        "characters": TARGETS,
        "rawSupportAtLeastThree": all(len(item["sourceSupport"]) >= 3 for item in results),
        "routedSupportAtLeastTwo": all(len(item["routedSourceSupport"]) >= 2 for item in results),
        "entries": results,
    }
    path = PROJECT / "reports" / "eastern-latin-extensions.json"
    path.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: summary[key] for key in ("count", "characters", "rawSupportAtLeastThree", "routedSupportAtLeastTwo")}, indent=2))


if __name__ == "__main__":
    main()
