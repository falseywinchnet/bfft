#!/usr/bin/env python3
"""Compare routed parent material with the Portsmouth Regular Eastern forms."""

import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


def regular_mask(font, character):
    image = Image.new("L", (1400, 1400), 0)
    ImageDraw.Draw(image).text((420, 900), character, font=font, fill=255, anchor="ls")
    return np.asarray(image) >= 128


def main():
    report = json.loads((PROJECT / "reports/eastern-latin-extensions.json").read_text())
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    sources = list(engine.sources)
    label_width, column_width, row_height = 300, 255, 250
    width = label_width + (len(sources) + 1) * column_width + 45
    height = 175 + len(report["entries"]) * row_height
    canvas = Image.new("RGB", (width, height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 16)
    small = ImageFont.truetype(ui, 12)
    draw.text((30, 22), f"Portsmouth {FAMILY_VERSION} — Eastern Latin source material and Regular", font=title, fill="#111")
    draw.text(
        (30, 72),
        "White = routed contributor · gray = encoded but excluded by case route · final column = accepted base + fused mark in Portsmouth Regular",
        font=small, fill="#5d574e",
    )
    columns = sources + [None]
    for index, source in enumerate(columns):
        name = "PORTSMOUTH REGULAR" if source is None else source.filename.replace("-Regular", "").replace(".ttf", "").replace(".otf", "")
        draw.text((label_width + index * column_width, 130), name, fill="#252321", font=label)
    regular = ImageFont.truetype(PROJECT / "build/family/Portsmouth.ttf", 1000)
    for row, entry in enumerate(report["entries"]):
        character = entry["character"]
        y0 = 160 + row * row_height
        draw.line((25, y0, width - 25, y0), fill="#cfc7bb", width=1)
        draw.text((35, y0 + 20), f"{character}  {entry['codepoint']}", fill="#111", font=label)
        words = entry["name"].replace("LATIN ", "").replace("LETTER ", "")
        draw.text((35, y0 + 50), words, fill="#625b52", font=small)
        draw.text((35, y0 + 78), entry["placement"].replace("_", " "), fill="#985848", font=small)
        active = engine.active_sources(character)
        for column, source in enumerate(columns):
            x0 = label_width + column * column_width - 12
            if source is None:
                fill = "#f6efe3"
                outline = "#985848"
                mask = regular_mask(regular, character)
                footer = "PORTSMOUTH REGULAR"
            else:
                if ord(character) not in source.cmap:
                    draw.text((x0 + 95, y0 + 105), "—", fill="#aaa49a", font=label)
                    continue
                routed = source in active
                fill = "#fffdf8" if routed else "#dedbd5"
                outline = "#c8c0b4"
                mask = engine.source_field(source, character).mask
                footer = "routed" if routed else "case-excluded"
            draw.rounded_rectangle(
                (x0, y0 + 10, x0 + column_width - 18, y0 + row_height - 12),
                radius=8, fill=fill, outline=outline, width=2 if source is None else 1,
            )
            glyph = _render_mask(mask, (150, 160))
            canvas.paste(glyph, (x0 + (column_width - 18 - glyph.width) // 2, y0 + 34))
            draw.text((x0 + 12, y0 + 210), footer, fill="#5f584f", font=small)
    output = PROJECT / "specimens" / f"Eastern-Latin-Sources-Regular-{FAMILY_VERSION}.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
