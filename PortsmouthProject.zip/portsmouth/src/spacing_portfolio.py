#!/usr/bin/env python3
"""Portfolio spacing solver for Portsmouth letter outlines."""

from __future__ import annotations

import unicodedata

import numpy as np

from family_geometry import content_aware_mono


TARGET_LOWER_PAIR_GAP = 140.0
TARGET_UPPER_PAIR_GAP = 145.0
LOWER_CONTRIBUTION = TARGET_LOWER_PAIR_GAP / 2.0
CAPITAL_CONTRIBUTION = TARGET_UPPER_PAIR_GAP / 2.0
CAPITAL_EXTRA_PER_SIDE = CAPITAL_CONTRIBUTION - LOWER_CONTRIBUTION
MONO_MAXIMUM_EXPANSION = 1.12


def is_letter(character: str) -> bool:
    return unicodedata.category(character).startswith("L")


def sidebearing_contribution(character: str) -> float:
    if unicodedata.category(character) == "Lu":
        return CAPITAL_CONTRIBUTION
    return LOWER_CONTRIBUTION


def _bounds(contours):
    stacked = np.vstack([points for _, points in contours])
    return float(np.min(stacked[:, 0])), float(np.max(stacked[:, 0]))


def _recenter(contours):
    x_min, x_max = _bounds(contours)
    center = 0.5 * (x_min + x_max)
    return [
        (role, points.astype(np.float64) - np.asarray([center, 0.0]))
        for role, points in contours
    ], x_max - x_min


def solve_proportional(contours, character: str):
    """Give every letter its case contribution on both geometric sides."""
    centered, ink_width = _recenter(contours)
    target = sidebearing_contribution(character)
    advance = int(round(ink_width + 2.0 * target))
    actual = 0.5 * (advance - ink_width)
    return centered, advance, {
        "method": "separable_equal-gap_portfolio",
        "targetLowerPairGap": TARGET_LOWER_PAIR_GAP,
        "capitalExtraPerSide": CAPITAL_EXTRA_PER_SIDE,
        "targetSidebearingContribution": target,
        "actualGeometricSidebearing": actual,
        "inkWidth": ink_width,
        "advance": advance,
    }


def solve_mono(contours, character: str, *, advance: float = 575.0):
    """Minimize equal-gap error while preserving a strict fixed-pitch cell.

    Wide letters receive the existing content-aware compression. Narrow letters
    may expand by at most twelve percent; this is the portfolio optimum under a
    shape-preservation bound and avoids turning i/l into unnaturally broad bars.
    """
    target = sidebearing_contribution(character)
    transformed, content_detail = content_aware_mono(
        contours, advance=advance, sidebearing=target
    )
    centered, output_width = _recenter(transformed)
    desired_width = advance - 2.0 * target
    expansion = min(
        desired_width / max(output_width, 1e-9),
        MONO_MAXIMUM_EXPANSION,
    )
    if expansion > 1.0:
        centered = [
            (role, points * np.asarray([expansion, 1.0]))
            for role, points in centered
        ]
        output_width *= expansion
    actual = 0.5 * (advance - output_width)
    return centered, {
        **content_detail,
        "method": "bounded_fixed-pitch_spacing_portfolio",
        "targetLowerPairGap": TARGET_LOWER_PAIR_GAP,
        "capitalExtraPerSide": CAPITAL_EXTRA_PER_SIDE,
        "targetSidebearingContribution": target,
        "actualGeometricSidebearing": actual,
        "desiredInkWidth": desired_width,
        "outputInkWidth": output_width,
        "maximumExpansion": MONO_MAXIMUM_EXPANSION,
        "appliedExpansion": expansion,
    }
