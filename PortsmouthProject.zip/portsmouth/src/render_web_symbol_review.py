#!/usr/bin/env python3
"""Render the promoted lower-web symbols and terminal repairs in context."""

from __future__ import annotations

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT


def main() -> None:
    font_path = PROJECT / "build" / "Portsmouth-Regular-0.016.ttf"
    canvas = Image.new("RGB", (1800, 1420), "#f4f0e8")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 46)
    label = ImageFont.truetype(ui, 20)
    display = ImageFont.truetype(font_path, 122)
    text = ImageFont.truetype(font_path, 64)
    small = ImageFont.truetype(font_path, 46)
    draw.text((60, 35), "Portsmouth Regular 0.016 — lower web review", fill="#171715", font=title)
    draw.text((62, 95), "actual installed TrueType outlines", fill="#71695f", font=label)

    glyphs = "© ª \u00ad ® ¶ º ½ ¾"
    draw.text((65, 145), glyphs, fill="#111", font=display)
    draw.line((60, 305, 1740, 305), fill="#cabfb0", width=2)

    rows = [
        "© 2026 Portsmouth®   1ª edição · 2º lugar",
        "½ cup + ¾ cup = 1¼ cups   § 3 ¶ 2",
        "JULY 1 · JOIN 101 · J1 JI Il 1i",
        "https://portsmouth.example/a?q=1&ref=©",
        "user@example.com   #type   $19.99   100%",
        "¿Qué?  «café»  [draft]  {final}  /path/to/file",
    ]
    y = 350
    for row in rows:
        draw.text((65, y), row, fill="#171715", font=text)
        y += 135

    draw.line((60, 1165, 1740, 1165), fill="#cabfb0", width=2)
    draw.text((65, 1200), "U+00A0–U+00BF", fill="#71695f", font=label)
    draw.text((65, 1240), " ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿", fill="#171715", font=small)
    output = PROJECT / "specimens" / "Portsmouth-Regular-0.016-web-review.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
