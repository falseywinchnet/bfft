#!/usr/bin/env python3
"""Build the canonical Makima-derived Portsmouth family and 575-unit Mono."""

from __future__ import annotations

import copy
import json
import math
import unicodedata
import zipfile
from pathlib import Path

import numpy as np
from fontTools.fontBuilder import FontBuilder
from fontTools.ttLib import TTCollection, TTFont
from PIL import Image, ImageDraw, ImageFont

from build_first_ttf import (
    PRODUCTION_CODEPOINTS,
    MINIMUM_SIDEBEARING,
    archived_contours,
    empty_glyph,
    geometry_for,
    glyph_name,
    mean_advance,
    notdef_glyph,
    outline_glyph,
)
from build_makima_quadratic_experiment import makima_outline_glyph
from family_geometry import (
    eikonal_bold,
    eikonal_light,
    mask_topology,
    rasterize_local,
    wind_warp,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from spacing_portfolio import (
    CAPITAL_EXTRA_PER_SIDE,
    TARGET_LOWER_PAIR_GAP,
    TARGET_UPPER_PAIR_GAP,
    is_letter,
    solve_mono,
    solve_proportional,
)


FAMILY_VERSION = "1.0"
MONO_ADVANCE = 575
ITALIC_ANGLE = 13.0
REGULAR_TARGET_RADIUS = 13.875
LIGHT_TARGET_RADIUS = 18.5
OUTPUT = PROJECT / "build" / "family"
MONO_OUTPUT = PROJECT / "build" / "mono"


STYLES = (
    {
        "key": "regular", "family": "Portsmouth", "style": "Regular",
        "filename": "Portsmouth.ttf", "fullName": "Portsmouth", "psName": "Portsmouth",
        "weight": 400, "italic": False, "bold": False, "mono": False,
    },
    {
        "key": "light", "family": "Portsmouth", "style": "Light",
        "filename": "Portsmouth-Light.ttf", "fullName": "Portsmouth Light", "psName": "Portsmouth-Light",
        "weight": 300, "italic": False, "bold": False, "mono": False,
    },
    {
        "key": "italic", "family": "Portsmouth", "style": "Italic",
        "filename": "Portsmouth-Italic.ttf", "fullName": "Portsmouth Italic", "psName": "Portsmouth-Italic",
        "weight": 400, "italic": True, "bold": False, "mono": False,
    },
    {
        "key": "bold", "family": "Portsmouth", "style": "Bold",
        "filename": "Portsmouth-Bold.ttf", "fullName": "Portsmouth Bold", "psName": "Portsmouth-Bold",
        "weight": 700, "italic": False, "bold": True, "mono": False,
    },
    {
        "key": "bold_italic", "family": "Portsmouth", "style": "Bold Italic",
        "filename": "Portsmouth-BoldItalic.ttf", "fullName": "Portsmouth Bold Italic", "psName": "Portsmouth-BoldItalic",
        "weight": 700, "italic": True, "bold": True, "mono": False,
    },
    {
        "key": "mono", "family": "Portsmouth Mono", "style": "Regular",
        "filename": "PortsmouthMono.ttf", "fullName": "Portsmouth Mono", "psName": "PortsmouthMono-Regular",
        "weight": 400, "italic": False, "bold": False, "mono": True,
    },
)


def base_advance(engine, character: str, contours) -> int:
    points = np.vstack([value for _, value in contours])
    width = float(np.ptp(points[:, 0]))
    return int(math.ceil(max(mean_advance(engine, character), width + 2 * MINIMUM_SIDEBEARING)))


def contour_ink_area(contours) -> float:
    """Signed geometric ink area, used to keep constrained weights monotonic."""
    total = 0.0
    for role, points in contours:
        x, y = points[:, 0], points[:, 1]
        area = 0.5 * abs(float(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1))))
        total += area if role == "outer" else -area
    return total


def _contains(points: np.ndarray, point: np.ndarray) -> bool:
    x, y = map(float, point)
    x0, y0 = points[:, 0], points[:, 1]
    x1, y1 = np.roll(x0, -1), np.roll(y0, -1)
    divisor = np.where(np.abs(y1 - y0) > 1e-12, y1 - y0, 1.0)
    crossings = ((y0 > y) != (y1 > y)) & (x < (x1 - x0) * (y - y0) / divisor + x0)
    return bool(np.count_nonzero(crossings) % 2)


def contour_components(contours):
    """Group each black outer with the counters it owns."""
    outer_indices = [index for index, (role, _) in enumerate(contours) if role == "outer"]
    groups = {index: [contours[index]] for index in outer_indices}
    for role, points in contours:
        if role != "hole":
            continue
        centroid = np.mean(points, axis=0)
        owners = [
            index for index in outer_indices
            if _contains(contours[index][1], centroid)
        ]
        if not owners:
            raise ValueError("counter has no containing component")
        owner = min(owners, key=lambda index: contour_ink_area([contours[index]]))
        groups[owner].append((role, points))
    return list(groups.values())


def _bounds(contours):
    points = np.vstack([value for _, value in contours])
    return np.min(points, axis=0), np.max(points, axis=0)


def componentwise_diacritic_transform(contours, codepoint, transform, *, bold=False):
    """Weight detached marks independently so they cannot throttle a letter body."""
    decomposition = unicodedata.normalize("NFD", chr(codepoint))
    groups = contour_components(contours)
    if len(decomposition) <= 1 or len(groups) <= 1:
        return transform(contours)
    body_index = int(np.argmax([contour_ink_area(group) for group in groups]))
    transformed = [transform(group) for group in groups]
    shifts = [np.zeros(2, dtype=np.float64) for _ in groups]
    if bold:
        original_body_min, original_body_max = _bounds(groups[body_index])
        body_min, body_max = _bounds(transformed[body_index][0])
        body_center = 0.5 * (original_body_min + original_body_max)
        minimum_gap = 8.0
        for index, group in enumerate(groups):
            if index == body_index:
                continue
            original_min, original_max = _bounds(group)
            mark_min, mark_max = _bounds(transformed[index][0])
            mark_center = 0.5 * (original_min + original_max)
            direction = mark_center - body_center
            # Choose the dominant normalized displacement from the body. This
            # handles above/below marks as well as side carons consistently.
            body_size = np.maximum(original_body_max - original_body_min, 1.0)
            normalized = direction / body_size
            axis = int(np.argmax(np.abs(normalized)))
            if direction[axis] >= 0:
                boundary = body_max[axis] + minimum_gap
                shifts[index][axis] = max(0.0, boundary - mark_min[axis])
            else:
                boundary = body_min[axis] - minimum_gap
                shifts[index][axis] = min(0.0, boundary - mark_max[axis])
            if np.any(shifts[index]):
                transformed[index] = (
                    [(role, points + shifts[index]) for role, points in transformed[index][0]],
                    transformed[index][1],
                )
    output = [contour for group, _ in transformed for contour in group]
    details = [detail for _, detail in transformed]
    output_mask, _, _ = rasterize_local(output, pixels_per_unit=2.0, padding=20.0)
    return output, {
        "requestedRadius": details[0].get("requestedRadius"),
        "appliedRadius": min(detail.get("appliedRadius", 0.0) for detail in details),
        "topologyConstrained": any(detail.get("topologyConstrained", False) for detail in details),
        "componentWiseDiacriticWeighting": True,
        "componentCount": len(groups),
        "bodyComponent": body_index,
        "boldSeparationShifts": [shift.tolist() for shift in shifts],
        "componentDetails": details,
        "outputTopology": mask_topology(output_mask),
    }


def attached_mark_transform(base_result, mark_contours, transform):
    """Keep an attached ogonek from throttling the already weighted base."""
    mark_result, mark_detail = transform(mark_contours)
    base_contours, base_detail = base_result
    output = base_contours + mark_result
    output_mask, _, _ = rasterize_local(output, pixels_per_unit=2.0, padding=20.0)
    output_topology = mask_topology(output_mask)
    expected_topology = base_detail.get("outputTopology")
    attachment_shift = np.zeros(2, dtype=np.float64)
    # Independent erosion can open a minute white pocket at the seam between
    # a base and an attached ogonek. Retuck the mark toward the body by the
    # smallest even-unit displacement that restores the base topology.
    if expected_topology is not None and output_topology != expected_topology:
        body_min, body_max = _bounds(base_contours)
        mark_min, mark_max = _bounds(mark_result)
        toward_body = np.sign(
            0.5 * (body_min + body_max) - 0.5 * (mark_min + mark_max)
        )
        candidates = []
        for x_amount in range(0, 26, 2):
            for y_amount in range(0, 26, 2):
                if x_amount == 0 and y_amount == 0:
                    continue
                shift = toward_body * np.array([x_amount, y_amount], dtype=np.float64)
                shifted_mark = [(role, points + shift) for role, points in mark_result]
                candidate = base_contours + shifted_mark
                candidate_mask, _, _ = rasterize_local(
                    candidate, pixels_per_unit=2.0, padding=20.0
                )
                if mask_topology(candidate_mask) == expected_topology:
                    candidates.append((float(np.linalg.norm(shift)), x_amount + y_amount, shift))
        if candidates:
            _, _, attachment_shift = min(candidates, key=lambda value: (value[0], value[1]))
            # Leave a small overlap reserve for the later Makima-to-quadratic
            # approximation; a merely tangent source join can reopen as a
            # persistent pinhole in the compiled TTF.
            active_axes = attachment_shift != 0.0
            attachment_shift = attachment_shift + toward_body * active_axes * 4.0
            mark_result = [(role, points + attachment_shift) for role, points in mark_result]
            output = base_contours + mark_result
            output_mask, _, _ = rasterize_local(
                output, pixels_per_unit=2.0, padding=20.0
            )
            output_topology = mask_topology(output_mask)
    return output, {
        "requestedRadius": base_detail.get("requestedRadius"),
        "appliedRadius": base_detail.get("appliedRadius"),
        "topologyConstrained": base_detail.get("topologyConstrained", False),
        "componentWiseAttachedMarkWeighting": True,
        "baseDetail": base_detail,
        "markDetail": mark_detail,
        "attachmentRetuckShift": attachment_shift.tolist(),
        "outputTopology": output_topology,
    }


def transformed_geometry(style, base, regular_cache, light_cache, bold_cache, codepoint):
    key = style["key"]
    if key == "regular":
        contours, detail = regular_cache[codepoint]
        return contours, {"transform": "half-Light topology-constrained Eikonal radius erosion", **detail}
    if key == "light":
        contours, detail = light_cache[codepoint]
        return contours, {"transform": "topology-constrained Eikonal radius erosion", **detail}
    if key == "italic":
        regular, regular_detail = regular_cache[codepoint]
        contours, wind_detail = wind_warp(regular, angle_degrees=ITALIC_ANGLE)
        return contours, {
            "transform": "half-Light Eikonal radius erosion followed by baseline-anchored nonlinear wind field",
            "regular": regular_detail,
            "wind": wind_detail,
        }
    if key == "bold":
        contours, detail = bold_cache[codepoint]
        return contours, {"transform": "topology-constrained Eikonal radius inflation", **detail}
    if key == "bold_italic":
        bold, bold_detail = bold_cache[codepoint]
        contours, wind_detail = wind_warp(bold, angle_degrees=ITALIC_ANGLE)
        return contours, {
            "transform": "Eikonal radius inflation followed by nonlinear wind field",
            "bold": bold_detail,
            "wind": wind_detail,
        }
    if key == "mono":
        if is_letter(chr(codepoint)):
            contours, detail = solve_mono(base, chr(codepoint), advance=MONO_ADVANCE)
        else:
            from family_geometry import content_aware_mono
            contours, detail = content_aware_mono(base, advance=MONO_ADVANCE)
        return contours, {"transform": "content-aware horizontal compression to 575-unit advance", **detail}
    raise ValueError(key)


def compile_geometry(style, character, contours, advance):
    # A handful of compound bold-italic contours are safer as protected lines:
    # their bold raster geometry is sound, but quadratic tangent intersections
    # can self-intersect after the nonlinear wind deformation.
    polygonal_fallbacks = {
        # Detached cedillas at the first monotonic Light radius are valid but
        # too compact for periodic tangent estimation; preserve their exact
        # Eikonal boundary as protected quadratic lines.
        "light": {0x0146, 0x0157, 0x2014},
        "bold_italic": {0x00B6, 0x00BE, 0x00E0, 0x00E1, 0x00E9, 0x00F5, 0x015C},
    }
    fallback = ord(character) in polygonal_fallbacks.get(style["key"], set())
    if fallback:
        # The Eikonal paragraph body carries subpixel raster stair events after
        # a 13-degree shear. A two-unit protected simplification minimizes them
        # without changing the visible silhouette or its genuine counter.
        tolerance = 2.0 if ord(character) == 0x00B6 else 0.15
        glyph, lsb, detail = outline_glyph(
            contours, advance, simplification_tolerance=tolerance
        )
        return glyph, lsb, {
            "compiler": "protected_polygonal_fallback",
            "fallbackReason": "compound bold-wind contour changes topology under integer quadratic conversion",
            "outputPoints": detail["outputPoints"],
            "contours": detail["contours"],
        }
    glyph, lsb, detail = makima_outline_glyph(contours, advance)
    return glyph, lsb, {"compiler": "periodic_event_aware_makima_to_quadratic", **detail}


def build_face(style, engine, base_geometry, regular_cache, light_cache, bold_cache, cmap_codepoints, names):
    glyph_order = [".notdef"] + [names[cp] for cp in cmap_codepoints]
    glyphs = {".notdef": notdef_glyph()}
    metrics = {".notdef": (MONO_ADVANCE if style["mono"] else 600, 55)}
    cmap = {cp: names[cp] for cp in cmap_codepoints}
    glyph_reports = []
    space_width = MONO_ADVANCE if style["mono"] else int(round(float(np.mean([
        source.widths[0x20] for source in engine.sources
        if source.filename in {"AnnotationMono-VF.ttf", "ComicShannsMono-Regular.ttf", "routed-gothic.ttf"}
    ]))))
    for cp in cmap_codepoints:
        name = names[cp]
        if cp in {0x20, 0xA0}:
            glyphs[name] = empty_glyph()
            metrics[name] = (space_width, 0)
            continue
        base = base_geometry[cp]
        contours, transform_detail = transformed_geometry(
            style, base, regular_cache, light_cache, bold_cache, cp
        )
        character = chr(cp)
        spacing_detail = None
        if style["mono"]:
            advance = MONO_ADVANCE
        elif is_letter(character):
            contours, advance, spacing_detail = solve_proportional(contours, character)
        else:
            regular_advance = base_advance(engine, character, base)
            transformed_width = float(np.ptp(np.vstack([points for _, points in contours])[:, 0]))
            advance = regular_advance
            if style["bold"]:
                advance = int(math.ceil(max(regular_advance, transformed_width + 2 * MINIMUM_SIDEBEARING)))
        try:
            glyph, lsb, compile_detail = compile_geometry(style, chr(cp), contours, advance)
        except Exception as error:
            raise RuntimeError(f"failed to compile {style['key']} U+{cp:04X}") from error
        glyphs[name] = glyph
        metrics[name] = (advance, lsb)
        glyph_reports.append({
            "codepoint": f"U+{cp:04X}",
            "character": chr(cp),
            "advance": advance,
            "transform": transform_detail,
            "spacing": spacing_detail,
            "compile": compile_detail,
        })

    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    caret_run = int(round(math.tan(math.radians(ITALIC_ANGLE)) * 1000.0)) if style["italic"] else 0
    fb.setupHorizontalHeader(
        ascent=850, descent=-250, lineGap=0,
        caretSlopeRise=1000, caretSlopeRun=caret_run,
    )
    fb.setupNameTable({
        "familyName": style["family"],
        "styleName": style["style"],
        "typographicFamily": style["family"],
        "typographicSubfamily": style["style"],
        "wwsFamilyName": style["family"],
        "wwsSubfamilyName": style["style"],
        "uniqueFontIdentifier": f"{style['fullName']} {FAMILY_VERSION}",
        "fullName": style["fullName"],
        "psName": style["psName"],
        "version": f"Version {FAMILY_VERSION}",
        "copyright": "Portsmouth Makima-derived family; provenance in PROJECT.md",
        "description": "Makima-mastered Portsmouth family derived from the protected Portsmouth geometry.",
        "licenseDescription": "Experimental personal and artistic evaluation build; source provenance in PROJECT.md.",
    })
    target = engine.target_landmarks
    fs_selection = (0x20 if style["bold"] else 0) | (0x01 if style["italic"] else 0)
    if style["key"] in {"regular", "mono"}:
        fs_selection |= 0x40
    fb.setupOS2(
        sTypoAscender=850, sTypoDescender=-250, sTypoLineGap=0,
        usWinAscent=1050, usWinDescent=400,
        sxHeight=int(round(target.xheight)), sCapHeight=int(round(target.capheight)),
        usWeightClass=style["weight"], usWidthClass=5,
        fsType=0, fsSelection=fs_selection,
        achVendID="PRTS", ulUnicodeRange1=0x00000003, ulCodePageRange1=0x00000001,
    )
    fb.setupPost(
        isFixedPitch=1 if style["mono"] else 0,
        italicAngle=-ITALIC_ANGLE if style["italic"] else 0.0,
    )
    fb.setupMaxp()
    fb.font["head"].fontRevision = float(FAMILY_VERSION)
    fb.font["head"].macStyle = (0x01 if style["bold"] else 0) | (0x02 if style["italic"] else 0)
    destination = (MONO_OUTPUT if style["mono"] else OUTPUT) / style["filename"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    fb.save(destination)
    font = TTFont(destination, lazy=False, recalcBBoxes=True)
    if len(font.getBestCmap()) != len(cmap):
        raise ValueError(f"{style['fullName']} cmap mismatch")
    if style["mono"] and (
        font["post"].isFixedPitch != 1
        or set(width for width, _ in font["hmtx"].metrics.values()) != {MONO_ADVANCE}
    ):
        raise ValueError("Portsmouth Mono metrics are not uniformly 575 units")
    font.close()
    report = {
        "font": str(destination.relative_to(PROJECT)),
        "family": style["family"],
        "style": style["style"],
        "version": FAMILY_VERSION,
        "sourceGeometry": "Portsmouth Regular 1.0 dense protected geometry",
        "master": "periodic event-aware modified Akima cubic Hermite",
        "glyphCountIncludingNotdef": len(glyph_order),
        "encodedCharacters": len(cmap),
        "fontBytes": destination.stat().st_size,
        "glyphs": glyph_reports,
    }
    report_path = PROJECT / "reports" / f"family-{style['key']}-{FAMILY_VERSION}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    return destination, report


def render_family(fonts: dict[str, Path]) -> Path:
    canvas = Image.new("RGB", (2100, 2075), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 42)
    label = ImageFont.truetype(ui, 17)
    draw.text((55, 30), f"Portsmouth — Makima family {FAMILY_VERSION}", fill="#111", font=title)
    draw.text((58, 84), f"true-shape Regular · Courier-calibrated Light · {ITALIC_ANGLE:g}° wind Italic · Eikonal Bold · content-aware 575 Mono", fill="#5d574e", font=label)
    rows = [
        ("regular", "REGULAR", "Portsmouth makes ordinary language feel natural."),
        ("light", "LIGHT / EIKONAL EROSION", "Quiet pages hold their shape with less ink."),
        ("italic", "ITALIC / WIND FIELD", "Aquamarine quays bend quietly in the wind."),
        ("bold", "BOLD / EIKONAL INFLATION", "Broad counters hold their ground."),
        ("bold_italic", "BOLD ITALIC", "Structure moves without losing weight."),
        ("mono", "MONO / 575 UNITS", "minimum rhythm  J1 Il  0123456789  @/©/½"),
    ]
    y = 145
    for key, name, sample in rows:
        draw.text((60, y), name, fill="#8a5145", font=label)
        display = ImageFont.truetype(fonts[key], 74)
        body = ImageFont.truetype(fonts[key], 34)
        draw.text((55, y + 28), sample, fill="#171715", font=display)
        draw.text((58, y + 135), "JULY 1 · a q æ m w S 8 @ Ø ø · © ® ½ ¾ ¶ ¿Qué?", fill="#292724", font=body)
        draw.line((55, y + 225, 2045, y + 225), fill="#c8c0b4", width=2)
        y += 305
    output = PROJECT / "specimens" / f"Portsmouth-Family-{FAMILY_VERSION}.png"
    canvas.save(output)
    return output


def bundle(
    family_paths: list[Path], mono_path: Path, legacy_regular_path: Path
) -> tuple[Path, Path, Path]:
    collection_path = OUTPUT / "Portsmouth-Family.ttc"
    collection = TTCollection()
    collection.fonts = [TTFont(path) for path in family_paths]
    collection.save(collection_path)
    for font in collection.fonts:
        font.close()
    zip_path = OUTPUT / f"Portsmouth-Family-{FAMILY_VERSION}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in family_paths + [
            mono_path, legacy_regular_path, collection_path, PROJECT / "PROJECT.md"
        ]:
            archive.write(path, arcname=path.name)
    mono_zip_path = MONO_OUTPUT / f"Portsmouth-Mono-{FAMILY_VERSION}.zip"
    with zipfile.ZipFile(mono_zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in [mono_path, PROJECT / "PROJECT.md"]:
            archive.write(path, arcname=path.name)
    return collection_path, zip_path, mono_zip_path


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    archived = [cp for cp in PRODUCTION_CODEPOINTS if geometry_for(cp) is not None]
    cmap_codepoints = sorted(set(archived) | {0x20, 0xA0})
    names = {cp: glyph_name(cp) for cp in cmap_codepoints}
    base_geometry = {
        cp: [(role, points.astype(np.float64)) for role, points in archived_contours(geometry_for(cp))]
        for cp in archived
    }
    # The inherited inverted-question outline contains a pinched neck that
    # fractures under curve compilation. Resolve it canonically as a 180-degree
    # rotation of Portsmouth's accepted question mark, aligned to the former
    # inverted-question center before deriving every family style.
    if 0x003F in base_geometry and 0x00BF in base_geometry:
        question = base_geometry[0x003F]
        former = np.vstack([points for _, points in base_geometry[0x00BF]])
        source = np.vstack([points for _, points in question])
        former_center = 0.5 * (np.min(former, axis=0) + np.max(former, axis=0))
        rotated_center = -0.5 * (np.min(source, axis=0) + np.max(source, axis=0))
        translation = former_center - rotated_center
        base_geometry[0x00BF] = [
            (role, -points + translation)
            for role, points in question
        ]
    regular_cache = {}
    light_cache = {}
    bold_cache = {}
    attached_marks = {}
    for cp in (0x0105, 0x0173):
        path = PROJECT / "geometry" / f"letter-repair-mark-{cp:04x}.npz"
        if path.exists():
            attached_marks[cp] = archived_contours(path)
    attached_bases = {0x0105: ord("a"), 0x0173: ord("u")}
    for cp in archived:
        if cp in attached_marks:
            base_cp = attached_bases[cp]
            regular_cache[cp] = attached_mark_transform(
                regular_cache[base_cp], attached_marks[cp],
                lambda contours: eikonal_light(contours, target_radius=REGULAR_TARGET_RADIUS),
            )
            light_cache[cp] = attached_mark_transform(
                light_cache[base_cp], attached_marks[cp],
                lambda contours: eikonal_light(contours, target_radius=LIGHT_TARGET_RADIUS),
            )
        else:
            regular_cache[cp] = componentwise_diacritic_transform(
                base_geometry[cp], cp,
                lambda contours: eikonal_light(contours, target_radius=REGULAR_TARGET_RADIUS),
            )
            light_cache[cp] = componentwise_diacritic_transform(
                base_geometry[cp], cp,
                lambda contours: eikonal_light(contours, target_radius=LIGHT_TARGET_RADIUS),
            )
        # Very small detached accents can make the topology limiter choose a
        # numerically non-monotonic radius. Search its stable radius events so
        # Light remains genuinely lighter than the new midweight Regular.
        if contour_ink_area(light_cache[cp][0]) >= contour_ink_area(regular_cache[cp][0]):
            if cp in attached_marks:
                base_cp = attached_bases[cp]
                candidates = [light_cache[cp]] + [
                    attached_mark_transform(
                        eikonal_light(base_geometry[base_cp], target_radius=radius),
                        attached_marks[cp],
                        lambda contours, radius=radius: eikonal_light(
                            contours, target_radius=radius
                        ),
                    )
                    for radius in np.linspace(2.5, LIGHT_TARGET_RADIUS, 33)
                ]
            else:
                candidates = [light_cache[cp]] + [
                    componentwise_diacritic_transform(
                        base_geometry[cp], cp,
                        lambda contours, radius=radius: eikonal_light(
                            contours, target_radius=radius
                        ),
                    )
                    for radius in np.linspace(2.5, LIGHT_TARGET_RADIUS, 33)
                ]
            lighter = [
                candidate for candidate in candidates
                if contour_ink_area(candidate[0]) < contour_ink_area(regular_cache[cp][0])
            ]
            if lighter:
                # Candidates are ordered from the least intervention upward;
                # retain the first monotonic event so detached accents do not
                # become mathematically present but too degenerate to compile.
                light_cache[cp] = lighter[0]
        if cp in attached_marks:
            bold_cache[cp] = attached_mark_transform(
                bold_cache[attached_bases[cp]], attached_marks[cp], eikonal_bold
            )
        else:
            bold_cache[cp] = componentwise_diacritic_transform(
                base_geometry[cp], cp, eikonal_bold, bold=True
            )
    fonts, reports = {}, {}
    for style in STYLES:
        path, report = build_face(
            style, engine, base_geometry, regular_cache, light_cache, bold_cache,
            cmap_codepoints, names,
        )
        fonts[style["key"]] = path
        reports[style["key"]] = report
    specimen = render_family(fonts)
    family_paths = [fonts[key] for key in ("regular", "light", "italic", "bold", "bold_italic")]
    legacy_regular = PROJECT / "build" / "Portsmouth-Regular-1.0.ttf"
    collection, archive, mono_archive = bundle(
        family_paths, fonts["mono"], legacy_regular
    )
    constrained = [
        cp for cp, (_, detail) in bold_cache.items() if detail["topologyConstrained"]
    ]
    light_constrained = [
        cp for cp, (_, detail) in light_cache.items() if detail["topologyConstrained"]
    ]
    summary = {
        "version": FAMILY_VERSION,
        "legacyNonMakimaRegularRetained": "build/Portsmouth-Regular-1.0.ttf",
        "faces": {
            key: str(fonts[key].relative_to(PROJECT))
            for key in ("regular", "light", "italic", "bold", "bold_italic")
        },
        "standaloneMono": str(fonts["mono"].relative_to(PROJECT)),
        "standaloneMonoBundle": str(mono_archive.relative_to(PROJECT)),
        "collection": str(collection.relative_to(PROJECT)),
        "bundle": str(archive.relative_to(PROJECT)),
        "specimen": str(specimen.relative_to(PROJECT)),
        "monoAdvance": MONO_ADVANCE,
        "italicAngleDegrees": ITALIC_ANGLE,
        "regularRequestedErosionRadius": REGULAR_TARGET_RADIUS,
        "spacingPortfolio": {
            "lowercasePairGap": TARGET_LOWER_PAIR_GAP,
            "uppercasePairGap": TARGET_UPPER_PAIR_GAP,
            "capitalExtraPerSide": CAPITAL_EXTRA_PER_SIDE,
        },
        "lightRequestedErosionRadius": LIGHT_TARGET_RADIUS,
        "lightTopologyConstrainedGlyphs": [f"U+{cp:04X}" for cp in light_constrained],
        "boldRequestedRadius": 22.0,
        "boldTopologyConstrainedGlyphs": [f"U+{cp:04X}" for cp in constrained],
    }
    (PROJECT / "reports" / f"family-build-{FAMILY_VERSION}.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
