#!/usr/bin/env python3
"""Render all twenty raw Latin Extended source-topology conflicts."""

from __future__ import annotations

import json

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


def main() -> None:
    audit = json.loads(
        (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
    )
    conflicts = [
        entry for entry in audit["entries"]
        if not entry["production"] and not entry["compatiblePersistentTopology"]
    ]
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    columns = list(engine.sources)
    label_width, column_width, row_height = 285, 255, 245
    width = label_width + len(columns) * column_width + 45
    height = 175 + len(conflicts) * row_height
    canvas = Image.new("RGB", (width, height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 32)
    label = ImageFont.truetype(ui, 16)
    small = ImageFont.truetype(ui, 12)
    draw.text((30, 22), "Portsmouth — 20 raw Latin Extended conflicts", fill="#111", font=title)
    draw.text(
        (30, 68),
        "White tile = routed contributor · gray tile = font encodes glyph but project case routing excludes it",
        fill="#5d574e", font=small,
    )
    draw.text(
        (30, 92),
        "Three conflicts disappear under routing; seventeen still require a topology decision.",
        fill="#985848", font=small,
    )
    for index, source in enumerate(columns):
        short = source.filename.replace("-Regular", "").replace(".ttf", "").replace(".otf", "")
        draw.text((label_width + index * column_width, 135), short, fill="#252321", font=label)

    routed_conflicts = 0
    for row, entry in enumerate(conflicts):
        character = entry["character"]
        active = engine.active_sources(character)
        active_topologies = [
            engine.topology(engine.source_field(source, character).mask)
            for source in active
        ]
        routed_conflict = len({
            (value["components"], value["holes"]) for value in active_topologies
        }) > 1
        routed_conflicts += routed_conflict
        y0 = 165 + row * row_height
        draw.line((25, y0, width - 25, y0), fill="#cfc7bb", width=1)
        draw.text((35, y0 + 20), f"{character}  {entry['codepoint']}", fill="#111", font=label)
        draw.text((35, y0 + 50), entry["name"], fill="#625b52", font=small)
        draw.text(
            (35, y0 + 79),
            "ROUTED CONFLICT" if routed_conflict else "RESOLVED BY ROUTING",
            fill="#a44d3f" if routed_conflict else "#52745a",
            font=small,
        )
        for column, source in enumerate(columns):
            if ord(character) not in source.cmap:
                continue
            is_active = source in active
            x0 = label_width + column * column_width - 12
            draw.rounded_rectangle(
                (x0, y0 + 10, x0 + column_width - 18, y0 + row_height - 12),
                radius=8,
                fill="#fffdf8" if is_active else "#dedbd5",
                outline="#c8c0b4",
            )
            field = engine.source_field(source, character)
            glyph = _render_mask(field.mask, (145, 155))
            canvas.paste(
                glyph,
                (x0 + (column_width - 18 - glyph.width) // 2, y0 + 35),
            )
            topology = engine.topology(field.mask)
            draw.text(
                (x0 + 12, y0 + 205),
                f"{topology['components']} comp · {topology['holes']} hole · "
                f"{'routed' if is_active else 'excluded'}",
                fill="#5f584f", font=small,
            )
    output = PROJECT / "specimens" / "latin-extended-topology-conflicts-0.103.png"
    canvas.save(output)
    report = PROJECT / "reports" / "latin-extended-topology-conflicts-0.103.json"
    report.write_text(json.dumps({
        "rawConflicts": len(conflicts),
        "routedConflicts": routed_conflicts,
        "resolvedByRouting": len(conflicts) - routed_conflicts,
        "characters": [entry["character"] for entry in conflicts],
        "specimen": str(output.relative_to(PROJECT)),
    }, indent=2) + "\n")
    print(output)
    print(report)


if __name__ == "__main__":
    main()
