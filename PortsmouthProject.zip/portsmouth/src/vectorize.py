#!/usr/bin/env python3
"""Convert Portsmouth midpoint level sets into deterministic polygon outlines."""

from __future__ import annotations

import numpy as np
import contourpy

from portsmouth_engine import EikonalMidpointEngine, MidpointGlyph


def _point_line_distance(points: np.ndarray, start: np.ndarray, end: np.ndarray) -> np.ndarray:
    direction = end - start
    denominator = float(np.dot(direction, direction))
    if denominator == 0:
        return np.linalg.norm(points - start, axis=1)
    t = np.clip(((points - start) @ direction) / denominator, 0.0, 1.0)
    projection = start + t[:, None] * direction
    return np.linalg.norm(points - projection, axis=1)


def rdp(points: np.ndarray, tolerance: float) -> np.ndarray:
    """Ramer–Douglas–Peucker simplification for an open polyline."""
    if len(points) <= 2:
        return points
    distances = _point_line_distance(points[1:-1], points[0], points[-1])
    if not len(distances):
        return points[[0, -1]]
    index = int(np.argmax(distances)) + 1
    if distances[index - 1] <= tolerance:
        return points[[0, -1]]
    left = rdp(points[:index + 1], tolerance)
    right = rdp(points[index:], tolerance)
    return np.vstack((left[:-1], right))


def simplify_closed(points: np.ndarray, tolerance: float) -> np.ndarray:
    """Simplify a closed contour without privileging its marching-squares start."""
    if len(points) > 1 and np.allclose(points[0], points[-1]):
        points = points[:-1]
    if len(points) < 4:
        return points
    first = int(np.argmin(points[:, 0] + 1e-6 * points[:, 1]))
    distances = np.linalg.norm(points - points[first], axis=1)
    opposite = int(np.argmax(distances))
    if first > opposite:
        first, opposite = opposite, first
    arc_a = points[first:opposite + 1]
    arc_b = np.vstack((points[opposite:], points[:first + 1]))
    simple_a = rdp(arc_a, tolerance)
    simple_b = rdp(arc_b, tolerance)
    combined = np.vstack((simple_a[:-1], simple_b[:-1]))
    if len(combined) < 3:
        return points
    return combined


def contours_from_midpoint(
    engine: EikonalMidpointEngine,
    result: MidpointGlyph,
    *,
    tolerance: float = 1.5,
) -> list[np.ndarray]:
    """Extract y-up, centered contours from a reinitialized midpoint SDF."""
    x = engine.x_min + (
        np.arange(engine.width, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit
    y = engine.y_min + (
        np.arange(engine.height, dtype=np.float64) + 0.5
    ) / engine.pixels_per_unit
    generator = contourpy.contour_generator(x=x, y=y, z=result.sdf[::-1])
    contours = []
    for line in generator.lines(0.0):
        simple = simplify_closed(np.asarray(line), tolerance)
        if len(simple) >= 3:
            contours.append(simple)
    return contours


def signed_area(contour: np.ndarray) -> float:
    following = np.roll(contour, -1, axis=0)
    return float(0.5 * np.sum(
        contour[:, 0] * following[:, 1] - following[:, 0] * contour[:, 1]
    ))

