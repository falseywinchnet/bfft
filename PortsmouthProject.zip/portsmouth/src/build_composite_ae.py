#!/usr/bin/env python3
"""Construct Portsmouth æ from accepted Portsmouth a and e bodies."""

from __future__ import annotations

import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex, resample_closed
from outline_geometry import union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask
from vectorize import signed_area


SHIFTS = (125.0, 145.0, 165.0)


def archived(character: str):
    stem = f"{ord(character):04x}"
    with np.load(PROJECT / "geometry" / f"multicontour-trace-{stem}.npz", allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key].astype(float))
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def signed(points: np.ndarray, role: str) -> np.ndarray:
    area = signed_area(points)
    positive = role == "outer"
    return points if (area > 0.0) == positive else points[::-1]


def candidate(shift: float):
    paths = []
    for character, offset in (("a", -shift), ("e", shift)):
        for role, points in archived(character):
            moved = points + np.array([offset, 0.0])
            paths.append(signed(moved, role))
    complex_ = union_contour_complex(paths, pixels_per_unit=5.0)
    contours = [
        (loop.role, resample_closed(loop.points, 10240)) for loop in complex_.loops
    ]
    return contours


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    results = []
    for shift in SHIFTS:
        contours = candidate(shift)
        topology = engine.topology(rasterize_contour_complex(engine, contours))
        width = max(np.max(points[:, 0]) for _, points in contours) - min(
            np.min(points[:, 0]) for _, points in contours
        )
        results.append((shift, contours, topology, float(width)))
        path = PROJECT / "geometry" / f"composite-ae-00e6-shift{int(shift)}.npz"
        arrays = {
            f"{role}_{index}": points.astype(np.float32)
            for index, (role, points) in enumerate(contours)
        }
        arrays["character"] = np.asarray("æ")
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(path, **arrays)

    old = archived("æ")
    entries = [("Current fused æ", old, engine.topology(rasterize_contour_complex(engine, old)))]
    entries += [(f"Composite · ±{int(shift)}", contours, topology) for shift, contours, topology, _ in results]
    canvas = Image.new("RGB", (1640, 920), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), "Portsmouth æ — explicit ligature seam", fill="#111", font=title)
    draw.text((40, 78), "accepted Portsmouth a + e · controlled overlap · body union · both counters retained", fill="#575149", font=small)
    for index, (name, contours, topology) in enumerate(entries):
        column, row = index % 3, index // 3
        x0, y0 = 40 + column * 520, 120 + row * 390
        draw.rounded_rectangle((x0, y0, x0 + 480, y0 + 350), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        mask = rasterize_contour_complex(engine, contours)
        glyph = _render_mask(mask, (380, 255))
        canvas.paste(glyph, (x0 + (480 - glyph.width) // 2, y0 + 64 + (255 - glyph.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), str(topology), fill="#655f57", font=small)
    specimen = PROJECT / "specimens" / "composite-ae-00e6.png"
    canvas.save(specimen)
    report = {
        "character": "æ",
        "status": "candidate_explicit_ligature_seam",
        "construction": "accepted Portsmouth a and e with controlled overlap and contour union",
        "candidates": [
            {"halfCenterSeparation": shift, "topology": topology, "inkWidth": width}
            for shift, _, topology, width in results
        ],
        "replacesCurrentGeometry": False,
        "visualReview": None,
    }
    (PROJECT / "reports" / "composite-ae-00e6.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(specimen)


if __name__ == "__main__":
    main()
