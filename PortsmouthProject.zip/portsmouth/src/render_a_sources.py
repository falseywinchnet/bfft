#!/usr/bin/env python3
"""Render every source drawing for a construction-family decision."""

from __future__ import annotations

import argparse
import math

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("character", nargs="?", default="a")
    arguments = parser.parse_args()
    if len(arguments.character) != 1:
        raise ValueError("Expected exactly one character")
    character = arguments.character
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    entries = []
    for source in engine.sources:
        if ord(character) not in source.cmap:
            continue
        field = engine.source_field(source, character)
        entries.append((source, field.mask, engine.topology(field.mask)))
    tile_width, tile_height, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new(
        "RGB", (80 + columns * tile_width, 155 + rows * tile_height), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — construction decision", fill="#111", font=title)
    draw.text(
        (40, 78),
        "all normalized source drawings · construction similarity is judged visually",
        fill="#575149",
        font=small,
    )
    for index, (source, mask, topology) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_width, 120 + row * tile_height
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_width - 20, y0 + tile_height - 20),
            radius=10,
            fill="#fffdf8",
            outline="#aaa39a",
            width=2,
        )
        image = _render_mask(mask, (tile_width - 70, tile_height - 120))
        canvas.paste(
            image,
            (
                x0 + (tile_width - 20 - image.width) // 2,
                y0 + 70 + (tile_height - 120 - image.height) // 2,
            ),
        )
        draw.text((x0 + 15, y0 + 15), source.family, fill="#151515", font=label)
        draw.text(
            (x0 + 15, y0 + tile_height - 55),
            f"{topology['components']} component · {topology['holes']} hole(s)",
            fill="#655f57",
            font=small,
        )
    output = PROJECT / "specimens" / f"{ord(character):04x}-all-sources.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
