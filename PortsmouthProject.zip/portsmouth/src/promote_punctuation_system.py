#!/usr/bin/env python3
"""Promote the principled semicolon, hyphen, curly quotes, and U+2014 thought break."""

from __future__ import annotations

import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

from build_first_ttf import archived_contours, geometry_for
from family_geometry import contours_from_mask, mask_topology
from portsmouth_engine import PROJECT


def bounds_center_y(contour: np.ndarray) -> float:
    return 0.5 * float(np.min(contour[:, 1]) + np.max(contour[:, 1]))


def save_geometry(codepoint: int, contours, report: dict) -> None:
    stem = f"{codepoint:04x}"
    path = PROJECT / "geometry" / f"punctuation-repair-{stem}.npz"
    arrays = {
        f"{role}_{index}": points.astype(np.float32)
        for index, (role, points) in enumerate(contours)
    }
    arrays["character"] = np.asarray(chr(codepoint))
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(path, **arrays)
    report["geometryArtifact"] = str(path.relative_to(PROJECT))
    (PROJECT / "reports" / f"punctuation-repair-{stem}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )


def promote_semicolon() -> dict:
    comma = archived_contours(geometry_for(ord(",")))
    colon = archived_contours(geometry_for(ord(":")))
    semicolon = archived_contours(geometry_for(ord(";")))
    comma_center = bounds_center_y(comma[0][1])
    colon_lower = min(colon, key=lambda item: bounds_center_y(item[1]))
    colon_center = bounds_center_y(colon_lower[1])
    target = 0.5 * (comma_center + colon_center)
    lower_index = min(range(len(semicolon)), key=lambda i: bounds_center_y(semicolon[i][1]))
    former = bounds_center_y(semicolon[lower_index][1])
    shift = target - former
    repaired = []
    for index, (role, points) in enumerate(semicolon):
        moved = points.astype(np.float64).copy()
        if index == lower_index:
            moved[:, 1] += shift
        repaired.append((role, moved))
    report = {
        "character": ";",
        "status": "experimental_promoted_principled_semicolon",
        "operator": "lower_tomoe_vertical_translation",
        "commaDotBoundsCenter": comma_center,
        "colonLowerDotBoundsCenter": colon_center,
        "exactMidpointTarget": target,
        "formerSemicolonLowerCenter": former,
        "verticalShift": shift,
        "upperDotUnchanged": True,
    }
    save_geometry(ord(";"), repaired, report)
    return report


def promote_hyphen() -> dict:
    hyphen = archived_contours(geometry_for(ord("-")))
    plus = archived_contours(geometry_for(ord("+")))
    former = bounds_center_y(hyphen[0][1])
    # Portsmouth's plus is vertically symmetric, so its overall bounds center
    # is exactly the crossbar center demanded by the design rule.
    plus_crossbar = bounds_center_y(plus[0][1])
    shift = plus_crossbar - former
    repaired = []
    for role, points in hyphen:
        moved = points.astype(np.float64).copy()
        moved[:, 1] += shift
        repaired.append((role, moved))
    report = {
        "character": "-",
        "status": "experimental_promoted_plus_aligned_hyphen",
        "operator": "whole_glyph_vertical_translation",
        "formerHyphenCenter": former,
        "plusCrossbarCenter": plus_crossbar,
        "verticalShift": shift,
    }
    save_geometry(ord("-"), repaired, report)
    return report


def ellipse_mask(draw: ImageDraw.ImageDraw, minimum, maximum, ppu, cx, cy, rx, ry, fill=1):
    x0 = (cx - rx - minimum[0]) * ppu
    x1 = (cx + rx - minimum[0]) * ppu
    y0 = (maximum[1] - (cy + ry)) * ppu
    y1 = (maximum[1] - (cy - ry)) * ppu
    draw.ellipse((x0, y0, x1, y1), fill=fill)


def thought_cloud() -> tuple[list[tuple[str, np.ndarray]], dict, np.ndarray]:
    ppu = 4.0
    minimum = np.array([-410.0, 165.0])
    maximum = np.array([365.0, 720.0])
    width = int(round((maximum[0] - minimum[0]) * ppu)) + 1
    height = int(round((maximum[1] - minimum[1]) * ppu)) + 1
    body_image = Image.new("1", (width, height), 0)
    draw = ImageDraw.Draw(body_image)
    lobes = [
        (-190, 430, 125, 112), (-125, 525, 125, 112),
        (15, 570, 148, 120), (170, 535, 125, 112),
        (245, 440, 105, 108), (155, 365, 140, 112),
        (0, 350, 150, 112), (-155, 365, 120, 108),
        (25, 445, 245, 150),
    ]
    for values in lobes:
        ellipse_mask(draw, minimum, maximum, ppu, *values)
    body = np.asarray(body_image, dtype=bool)
    distance = ndimage.distance_transform_edt(body)
    hole = distance > 68.0 * ppu
    labels, count = ndimage.label(hole, np.ones((3, 3), dtype=np.uint8))
    if count:
        sizes = np.bincount(labels.ravel())
        hole = labels == int(np.argmax(sizes[1:]) + 1)
    final = body & ~hole
    dot_image = Image.fromarray(final)
    dots = ImageDraw.Draw(dot_image)
    ellipse_mask(dots, minimum, maximum, ppu, -290, 270, 43, 35)
    ellipse_mask(dots, minimum, maximum, ppu, -348, 205, 24, 21)
    final = np.asarray(dot_image, dtype=bool)
    contours = contours_from_mask(final, minimum, maximum, pixels_per_unit=ppu)
    # The construction mask is intentionally generous so its topology is
    # stable. Fit it nearly edge-to-edge in an em-dash advance while retaining
    # its full vertical presence and slight rightward bias. Relative to 0.108,
    # this is approximately twice the visible ink area.
    compact = []
    for role, points in contours:
        adjusted = points.copy()
        adjusted[:, 0] = adjusted[:, 0] * 0.91 + 24.0
        adjusted[:, 1] = (adjusted[:, 1] - 184.0) * 1.00 + 180.0
        compact.append((role, adjusted))
    contours = compact
    report = {
        "character": "—",
        "codepoint": "U+2014",
        "status": "experimental_promoted_thought_break",
        "semantics": "AI-specific epistemic rupture without truth or importance polarity",
        "inputPolicy": "direct Unicode U+2014 only; host software owns any double-hyphen conversion",
        "openTypeSubstitution": False,
        "position": "above midline, upward-balanced toward capital height with a slight rightward bias",
        "construction": "scalloped Eikonal-compatible outline with two descending thought bubbles",
        "compactTransform": {"horizontalScale": 0.91, "verticalScale": 1.0, "xShift": 24.0, "newMinimumY": 180.0},
        "revisionIntent": "approximately twice the 0.108 ink area; side-to-side measure matches an em dash",
        "topology": mask_topology(final),
        "pixelsPerUnit": ppu,
        "advancePolicy": "mean active-source U+2014 advance; Mono uses its existing 575-unit content-aware fit",
    }
    return contours, report, final


def promote_quotes() -> list[dict]:
    results = []
    for cp in (0x2018, 0x2019, 0x201C, 0x201D):
        path = PROJECT / "reports" / f"multicontour-trace-{cp:04x}.json"
        report = json.loads(path.read_text())
        report["status"] = "experimental_promoted_curly_quote"
        report["promotion"] = "equal-third uncased punctuation route"
        path.write_text(json.dumps(report, indent=2) + "\n")
        results.append({"codepoint": f"U+{cp:04X}", "geometry": report["geometryArtifact"]})
    return results


def render_review(summary: dict) -> None:
    canvas = Image.new("RGB", (2100, 1080), "#f2ede3")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 40)
    label = ImageFont.truetype(ui, 20)
    draw.text((55, 35), "Portsmouth punctuation decisions — geometric promotion", font=title, fill="#171715")
    draw.text((58, 95), "No kerning · no GSUB · U+2014 is directly encoded as a thought break", font=label, fill="#6a6258")
    rows = [
        ("Semicolon", f"tomoe +{summary['semicolon']['verticalShift']:.2f} · exact comma/colon midpoint"),
        ("Hyphen", f"+{summary['hyphen']['verticalShift']:.2f} · exact plus-crossbar center"),
        ("Curly quotes", "three-source uncased fusion · one/two component topology retained"),
        ("Thought break", "Unicode U+2014 · broad cloud above midline · two thought bubbles"),
    ]
    y = 175
    for name, note in rows:
        draw.text((65, y), name.upper(), font=label, fill="#985848")
        draw.text((300, y), note, font=label, fill="#514b44")
        draw.line((55, y + 45, 2045, y + 45), fill="#cfc6b8", width=2)
        y += 90
    # Show the canonical cloud directly from archived geometry coordinates.
    cloud = archived_contours(PROJECT / "geometry/punctuation-repair-2014.npz")
    scale, ox, oy = 1.05, 880, 930
    for role, points in cloud:
        polygon = [(ox + x * scale, oy - y * scale) for x, y in points]
        draw.polygon(polygon, fill="#171715" if role == "outer" else "#f2ede3")
    draw.line((100, 930, 2000, 930), fill="#557b9d", width=2)
    draw.line((100, 930 - 350 * scale, 2000, 930 - 350 * scale), fill="#75947b", width=2)
    draw.line((100, 930 - 700 * scale, 2000, 930 - 700 * scale), fill="#c96e5c", width=2)
    draw.text((120, 825), "AI — SPECIES — SENTIMENT", font=ImageFont.truetype(ui, 38), fill="#514b44")
    output = PROJECT / "specimens/punctuation-system-promotion.png"
    canvas.save(output)


def main() -> None:
    semicolon = promote_semicolon()
    hyphen = promote_hyphen()
    quotes = promote_quotes()
    cloud, cloud_report, _ = thought_cloud()
    save_geometry(0x2014, cloud, cloud_report)
    summary = {"semicolon": semicolon, "hyphen": hyphen, "quotes": quotes, "thoughtBreak": cloud_report}
    (PROJECT / "reports/punctuation-system-promotion.json").write_text(json.dumps(summary, indent=2) + "\n")
    render_review(summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
