#!/usr/bin/env python3
"""Render a high-resolution contextual punctuation and case-alignment audit."""

from __future__ import annotations

import json
from pathlib import Path

from fontTools.pens.boundsPen import BoundsPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import PROJECT


W, H = 3400, 5600
BG = "#f3efe6"
INK = "#171715"
MUTED = "#665f56"
ACCENT = "#985848"
RULE = "#c8bfb2"
CAP_RULE = "#c96e5c"
X_RULE = "#75947b"
BASE_RULE = "#557b9d"

FACES = {
    "Regular": PROJECT / "build/family/Portsmouth.ttf",
    "Light": PROJECT / "build/family/Portsmouth-Light.ttf",
    "Italic": PROJECT / "build/family/Portsmouth-Italic.ttf",
    "Bold": PROJECT / "build/family/Portsmouth-Bold.ttf",
    "Bold Italic": PROJECT / "build/family/Portsmouth-BoldItalic.ttf",
    "Mono 575": PROJECT / "build/mono/PortsmouthMono.ttf",
}


def ui_font(size: int, bold: bool = False):
    name = "Arial Bold.ttf" if bold else "Arial.ttf"
    return ImageFont.truetype(Path("/System/Library/Fonts/Supplemental") / name, size)


def heading(draw, y: int, title: str, note: str = "") -> None:
    draw.text((90, y), title, font=ui_font(30, True), fill=ACCENT)
    if note:
        draw.text((90, y + 42), note, font=ui_font(22), fill=MUTED)


def guide_line(draw, x0, x1, y, color, label=""):
    draw.line((x0, y, x1, y), fill=color, width=2)
    if label:
        draw.text((x1 + 8, y - 13), label, font=ui_font(17), fill=color)


def font_bounds(path: Path, character: str):
    font = TTFont(path)
    cmap = font.getBestCmap()
    glyph_name = cmap[ord(character)]
    pen = BoundsPen(font.getGlyphSet())
    font.getGlyphSet()[glyph_name].draw(pen)
    advance, lsb = font["hmtx"][glyph_name]
    bounds = pen.bounds
    font.close()
    return glyph_name, advance, lsb, bounds


def pair_gap(path: Path, left: str, right: str) -> float:
    _, left_advance, _, left_bounds = font_bounds(path, left)
    _, _, _, right_bounds = font_bounds(path, right)
    return float(left_advance - left_bounds[2] + right_bounds[0])


def anatomy_grid(draw, path: Path, x: int, y: int, title: str):
    draw.text((x, y), title, font=ui_font(25, True), fill=INK)
    characters = [".", ",", ";", ":", "(", ")", "[", "]", "{", "}", "<", ">", "/", "\\", "|"]
    cell_w, cell_h = 294, 310
    size = 210
    face = ImageFont.truetype(path, size)
    scale = size / 1000.0
    for index, character in enumerate(characters):
        row, col = divmod(index, 5)
        cx, cy = x + col * cell_w, y + 54 + row * cell_h
        baseline = cy + 208
        draw.rounded_rectangle((cx, cy, cx + cell_w - 16, cy + cell_h - 16), 10, outline=RULE, width=2)
        guide_line(draw, cx + 10, cx + cell_w - 26, baseline - 700 * scale, CAP_RULE)
        guide_line(draw, cx + 10, cx + cell_w - 26, baseline - 500 * scale, X_RULE)
        guide_line(draw, cx + 10, cx + cell_w - 26, baseline, BASE_RULE)
        glyph_name, advance, _, bounds = font_bounds(path, character)
        origin = cx + (cell_w - 16 - advance * scale) / 2
        draw.line((origin, cy + 12, origin, cy + cell_h - 30), fill="#b7afa3", width=1)
        draw.line((origin + advance * scale, cy + 12, origin + advance * scale, cy + cell_h - 30), fill="#b7afa3", width=1)
        if bounds:
            x0, y0, x1, y1 = bounds
            draw.rectangle(
                (origin + x0 * scale, baseline - y1 * scale, origin + x1 * scale, baseline - y0 * scale),
                outline="#d09a55", width=2,
            )
        draw.text((origin, baseline), character, font=face, fill=INK, anchor="ls")
        draw.text((cx + 12, cy + 10), f"{character!r}  {glyph_name}", font=ui_font(17), fill=MUTED)


def guided_text(draw, path: Path, text: str, x: int, baseline: int, size: int, width: int, label: str):
    face = ImageFont.truetype(path, size)
    scale = size / 1000.0
    draw.text((x, baseline - 700 * scale - 38), label, font=ui_font(19, True), fill=MUTED)
    guide_line(draw, x, x + width, baseline - 700 * scale, CAP_RULE, "CAP")
    guide_line(draw, x, x + width, baseline - 500 * scale, X_RULE, "x")
    guide_line(draw, x, x + width, baseline, BASE_RULE, "BASE")
    draw.text((x, baseline), text, font=face, fill=INK, anchor="ls")


def main() -> None:
    canvas = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(canvas)
    draw.text((90, 58), f"Portsmouth {FAMILY_VERSION} — punctuation typesetting audit", font=ui_font(52, True), fill=INK)
    draw.text(
        (92, 128),
        "Default glyphs only · no OpenType case feature currently present · red cap height · green x-height · blue baseline",
        font=ui_font(24), fill=MUTED,
    )

    heading(draw, 205, "1 · Context across the family", "Dense punctuation sequences reveal weight, rhythm, collision, and baseline behavior.")
    stress = "Wait... really? Yes; (mostly), [carefully], {exactly}: <well-formed> — `code`;"
    y = 295
    for label, path in FACES.items():
        face = ImageFont.truetype(path, 55)
        draw.text((95, y + 3), label.upper(), font=ui_font(18, True), fill=ACCENT)
        draw.text((330, y), stress, font=face, fill=INK)
        y += 98

    heading(draw, 910, "2 · Punctuation anatomy", "Orange boxes are ink bounds; gray verticals are advance boundaries. Both faces use the same 1,000-unit vertical metrics.")
    anatomy_grid(draw, FACES["Regular"], 90, 1000, "PORTSMOUTH REGULAR")
    anatomy_grid(draw, FACES["Mono 575"], 1760, 1000, "PORTSMOUTH MONO 575")

    heading(draw, 2070, "3 · Capitals and case-sensitive alignment", "Current defaults shown. Compare delimiter and operator optical centers with the red cap-height band.")
    cap_text = "H(A)[B]{C}<D> / E\\F | G-H+I=J:K;L.M,N!"
    guided_text(draw, FACES["Regular"], cap_text, 110, 2345, 92, 3000, "REGULAR · ALL CAPS")
    guided_text(draw, FACES["Mono 575"], cap_text, 110, 2590, 82, 3000, "MONO · ALL CAPS / CODE")

    heading(draw, 2760, "4 · Code bracketing and punctuation", "Nested delimiters, terminal punctuation, member access, paths, comparisons, and escaped strings.")
    code = [
        "function parse<T>(input: string): Result<T> {",
        "  const pair = [tokens[i], tokens[i + 1]];",
        "  if (pair[0] !== '{' && pair[1] !== '}') {",
        "    map.set(`key.${name}`, { value, index: i });",
        "  } else if (path === '/usr/local/bin') {",
        "    console.warn(\"empty; expected: [a, b, c].\");",
        "  }",
        "  return ok({ data: input?.trim(), ratio: 1.25 });",
        "}",
        "SELECT a.id, b.name FROM a JOIN b ON (a.id = b.id);",
    ]
    mono = ImageFont.truetype(FACES["Mono 575"], 61)
    y = 2845
    for line in code:
        guide_line(draw, 110, 3270, y + 53, "#d7d0c5")
        draw.text((115, y + 53), line, font=mono, fill=INK, anchor="ls")
        y += 82

    heading(draw, 3715, "5 · Prose punctuation", "Sentence terminals, abbreviations, decimal points, quotations, parentheses, dashes, ellipsis, and semicolon cadence.")
    prose = [
        ("Regular", "Dr. Vale paused, then said, “No—wait... is 3.14 correct?” It was; barely."),
        ("Light", "A quiet clause (set aside) can clarify a sentence; it should not fracture it."),
        ("Italic", "‘Perhaps,’ she wrote, ‘the comma needs less weight, or a longer tail.’"),
        ("Bold", "Warning: arrays [ ], objects { }, and calls ( ) must remain distinct."),
    ]
    y = 3805
    for label, text in prose:
        draw.text((100, y), label.upper(), font=ui_font(18, True), fill=ACCENT)
        draw.text((330, y - 8), text, font=ImageFont.truetype(FACES[label], 58), fill=INK)
        y += 112

    heading(draw, 4285, "6 · Micro-rhythm and adjacency", "The requested marks are repeated beside round, vertical, diagonal, narrow, and wide forms.")
    micro = [
        "a.a  o.o  i.i  l.l  M.M  W.W     a,a  o,o  i,i  l,l  M,M  W,W",
        "a;a  o;o  i;i  l;l  M;M  W;W     a:a  o:o  i:i  l:l  M:M  W:W",
        "(a) (o) (i) (l) (M) (W)     [a] [o] [i] [l] [M] [W]",
        "{a} {o} {i} {l} {M} {W}     <a> <o> <i> <l> <M> <W>",
        "foo.bar, baz.qux;  obj[key].call(arg);  [[({<code>})]]",
    ]
    y = 4380
    for line in micro:
        draw.text((110, y), line, font=ImageFont.truetype(FACES["Regular"], 62), fill=INK)
        y += 100

    heading(draw, 4920, "7 · Complete ASCII punctuation inventory", "Regular above, Mono below; paired marks are kept adjacent to expose symmetry.")
    inventory = "! \" # $ % & ' ( ) * + , - . / : ; < = > ? @ [ \\ ] ^ _ ` { | } ~"
    draw.text((110, 5015), inventory, font=ImageFont.truetype(FACES["Regular"], 70), fill=INK)
    draw.text((110, 5140), inventory, font=ImageFont.truetype(FACES["Mono 575"], 64), fill=INK)
    draw.text((110, 5280), "CAP PAIRS:  (H) [H] {H} <H>  H-H H+H H=H H:H H;H H.H H,H", font=ImageFont.truetype(FACES["Regular"], 66), fill=INK)

    output = PROJECT / "specimens" / f"Portsmouth-Punctuation-Typesetting-{FAMILY_VERSION}.png"
    canvas.save(output, optimize=True)

    measured = {}
    pair_sequences = ["a.a", "a,a", "a;a", "a:a", "(A)", "[A]", "{A}", "<A>", "H-H", "H+H", "H=H"]
    tables = {}
    chars = ".,;:()[]{}<>/\\|+-="
    for face_name in ("Regular", "Mono 575"):
        path = FACES[face_name]
        face_values = {}
        for character in chars:
            glyph_name, advance, lsb, bounds = font_bounds(path, character)
            x0, y0, x1, y1 = bounds
            face_values[character] = {
                "glyph": glyph_name,
                "advance": advance,
                "leftSidebearing": lsb,
                "bounds": [x0, y0, x1, y1],
                "verticalInkCenter": 0.5 * (y0 + y1),
                "offsetFromCapBandCenter": 0.5 * (y0 + y1) - 350.0,
            }
        measured[face_name] = {
            "glyphMetrics": face_values,
            "adjacencyGaps": {
                sequence: [pair_gap(path, left, right) for left, right in zip(sequence, sequence[1:])]
                for sequence in pair_sequences
            },
        }
    for face_name, path in FACES.items():
        font = TTFont(path)
        tables[face_name] = [tag for tag in ("GSUB", "GPOS", "kern") if tag in font]
        font.close()
    report = {
        "version": FAMILY_VERSION,
        "image": str(output.relative_to(PROJECT)),
        "openTypeTables": tables,
        "caseFeaturePresent": False,
        "capHeight": 700,
        "xHeight": 500,
        "baseline": 0,
        "metrics": measured,
    }
    report_path = PROJECT / "reports" / f"punctuation-typesetting-audit-{FAMILY_VERSION}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(output)
    print(report_path)


if __name__ == "__main__":
    main()
