#!/usr/bin/env python3
"""Build and render a small installable Portsmouth outline prototype."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from vectorize import contours_from_midpoint


CHARACTERS = " HMm"


def empty_glyph():
    return TTGlyphPen(None).glyph()


def notdef_glyph():
    pen = TTGlyphPen(None)
    pen.moveTo((50, 0))
    pen.lineTo((550, 0))
    pen.lineTo((550, 700))
    pen.lineTo((50, 700))
    pen.closePath()
    pen.moveTo((130, 80))
    pen.lineTo((130, 620))
    pen.lineTo((470, 620))
    pen.lineTo((470, 80))
    pen.closePath()
    return pen.glyph()


def build() -> Path:
    engine = EikonalMidpointEngine(pixels_per_unit=1.0)
    glyph_order = [".notdef", "space", "H", "M", "m"]
    glyphs = {".notdef": notdef_glyph(), "space": empty_glyph()}
    metrics = {".notdef": (600, 50), "space": (500, 0)}
    cmap = {ord(" "): "space"}
    for character in "HMm":
        result = engine.midpoint(character)
        contours = contours_from_midpoint(engine, result, tolerance=1.5)
        advance = int(round(result.advance))
        pen = TTGlyphPen(None)
        shift = advance / 2.0
        for contour in contours:
            points = [
                (int(round(x + shift)), int(round(y))) for x, y in contour
            ]
            if len(points) < 3:
                continue
            pen.moveTo(points[0])
            for point in points[1:]:
                pen.lineTo(point)
            pen.closePath()
        glyphs[character] = pen.glyph()
        x_min = min((point[0] for contour in contours for point in contour), default=0)
        metrics[character] = (advance, int(round(x_min + shift)))
        cmap[ord(character)] = character

    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=850, descent=-250, lineGap=0)
    fb.setupNameTable({
        "familyName": "Portsmouth",
        "styleName": "Regular",
        "uniqueFontIdentifier": "Portsmouth Regular research prototype 0.001",
        "fullName": "Portsmouth Regular",
        "psName": "Portsmouth-Regular",
        "version": "Version 0.001",
        "copyright": "Portsmouth research prototype; source provenance in PROJECT.md",
        "licenseDescription": "Research prototype for personal and artistic evaluation; not for redistribution.",
    })
    target = engine.target_landmarks
    fb.setupOS2(
        sTypoAscender=850,
        sTypoDescender=-250,
        sTypoLineGap=0,
        usWinAscent=900,
        usWinDescent=300,
        sxHeight=int(round(target.xheight)),
        sCapHeight=int(round(target.capheight)),
        usWeightClass=400,
        usWidthClass=5,
    )
    fb.setupPost(isFixedPitch=0)
    fb.setupMaxp()
    destination = PROJECT / "build" / "Portsmouth-Prototype.ttf"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fb.save(destination)
    return destination


def render(font_path: Path) -> Path:
    image = Image.new("RGB", (1600, 720), "#eee9df")
    draw = ImageDraw.Draw(image)
    label = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 28
    )
    face = ImageFont.truetype(font_path, 360)
    draw.text((60, 45), "Portsmouth · first outline prototype", fill="#222", font=label)
    draw.line((60, 530, 1540, 530), fill="#d9513c", width=2)
    draw.text((80, 530), "HMm", font=face, fill="#111", anchor="ls")
    output = PROJECT / "specimens" / "prototype-font.png"
    image.save(output)
    return output


if __name__ == "__main__":
    path = build()
    specimen = render(path)
    print(path)
    print(specimen)
