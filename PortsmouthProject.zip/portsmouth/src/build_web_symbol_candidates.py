#!/usr/bin/env python3
"""Build isolated modal-topology candidates for lower web symbols."""

from portsmouth_engine import EikonalMidpointEngine
from run_multicontour_trace_experiment import run_character


CHARACTERS = "©ª®º½¾"
SOURCE_NAMES = (
    "AnnotationMono-VF.ttf",
    "SyneMono-Regular.ttf",
    "routed-gothic.ttf",
)


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    source_by_name = {source.filename: source for source in engine.sources}
    sources = [source_by_name[name] for name in SOURCE_NAMES]
    for character in CHARACTERS:
        run_character(
            engine,
            character,
            10240,
            selected_sources=sources,
            output_prefix="web-symbol-candidate",
            status_override="experimental_web_symbol_candidate",
            source_selection_policy=(
                "modal topology: equal Annotation Mono, Syne Mono, and Routed Gothic; "
                "Bedstead excluded because its component topology conflicts"
            ),
        )


if __name__ == "__main__":
    main()
