#!/usr/bin/env python3
"""Build Portsmouth @ from Annotation/Routed structure at Comic Shanns ratios."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import annealed_boundary_barycenter, boundary_cloud, rasterize_contour_complex
from outline_geometry import normalized_source_contours, union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import (
    _render_mask,
    component_fields,
    medial_basis,
    retain_persistent_loops,
)


STRUCTURE = ("AnnotationMono-VF.ttf", "routed-gothic.ttf")
PROPORTION_REFERENCE = "ComicShannsMono-Regular.ttf"


def bounds(points: np.ndarray) -> tuple[float, float, float, float]:
    minimum, maximum = np.min(points, axis=0), np.max(points, axis=0)
    return float(minimum[0]), float(minimum[1]), float(maximum[0]), float(maximum[1])


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    character = "@"
    source_by_name = {source.filename: source for source in engine.sources}
    fields = [engine.source_field(source_by_name[name], character) for name in STRUCTURE]
    comic_field = engine.source_field(source_by_name[PROPORTION_REFERENCE], character)
    raw = normalized_source_contours(engine, character)
    complexes = [
        retain_persistent_loops(
            union_contour_complex(raw[field.source.filename], pixels_per_unit=5.0),
            engine.topology(field.mask),
        )[0]
        for field in fields
    ]
    comic_complex = retain_persistent_loops(
        union_contour_complex(raw[PROPORTION_REFERENCE], pixels_per_unit=5.0),
        engine.topology(comic_field.mask),
    )[0]

    tops = [max(float(np.max(loop.points[:, 1])) for loop in value.outer) for value in complexes]
    target_top = float(np.median(tops))
    for complex_, top in zip(complexes, tops):
        scale = target_top / top
        for value in complex_.loops:
            value.points[:, 1] *= scale
            value.centroid[1] *= scale
            value.area *= scale

    outer_group = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    hole_group = [max(value.holes, key=lambda loop: loop.area) for value in complexes]
    body_fields = component_fields(engine, fields, outer_group, [hole_group])
    output = []
    contour_reports = []
    for role, group in (("outer", outer_group), ("hole", hole_group)):
        measures, median, median_info = medial_basis(engine, body_fields)
        clouds = [
            boundary_cloud(
                engine,
                field,
                measure,
                median,
                plan,
                count=10240,
                source_contour=value.points,
            )
            for field, measure, plan, value in zip(
                body_fields, measures, median.plans, group
            )
        ]
        contour, annealing = annealed_boundary_barycenter(clouds)
        output.append((role, contour))
        contour_reports.append({
            "role": role,
            "medianSkeleton": median_info,
            "annealing": annealing,
        })

    comic_outer = max(comic_complex.outer, key=lambda loop: loop.area)
    comic_x0, comic_y0, comic_x1, comic_y1 = bounds(comic_outer.points)
    comic_aspect = (comic_x1 - comic_x0) / (comic_y1 - comic_y0)
    fused_x0, fused_y0, fused_x1, fused_y1 = bounds(output[0][1])
    fused_aspect = (fused_x1 - fused_x0) / (fused_y1 - fused_y0)
    horizontal_scale = comic_aspect / fused_aspect
    center_x = 0.5 * (fused_x0 + fused_x1)
    for _, contour in output:
        contour[:, 0] = (contour[:, 0] - center_x) * horizontal_scale

    output_width = float(np.max(output[0][1][:, 0]) - np.min(output[0][1][:, 0]))
    comic_advance_to_ink = comic_field.advance / (comic_x1 - comic_x0)
    target_advance = output_width * comic_advance_to_ink
    mask = rasterize_contour_complex(engine, output)
    expected = {"components": 1, "holes": 1}
    actual = engine.topology(mask)
    if actual != expected:
        raise ValueError(f"Constrained @ topology {actual}, expected {expected}")

    geometry = PROJECT / "geometry" / "multicontour-trace-0040.npz"
    np.savez_compressed(
        geometry,
        outer_0=output[0][1].astype(np.float32),
        hole_1=output[1][1].astype(np.float32),
        character=np.asarray(character),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    report = {
        "character": character,
        "status": "experimental_user_directed_constrained_at",
        "designConstraint": "Annotation/Routed structure at Comic Shanns proportions",
        "pipeline": [
            "closed_counter_structure_selection",
            "equal_weight_annotation_routed_transport",
            "comic_shanns_width_height_ratio_constraint",
            "comic_shanns_advance_ink_ratio_constraint",
        ],
        "structureSources": list(STRUCTURE),
        "structureSourceWeight": 0.5,
        "proportionReference": PROPORTION_REFERENCE,
        "proportionReferenceGeometryWeight": 0.0,
        "sources": list(STRUCTURE),
        "equalSourceWeight": 0.5,
        "comicAspectRatio": comic_aspect,
        "preConstraintAspectRatio": fused_aspect,
        "horizontalConstraintScale": horizontal_scale,
        "comicAdvanceToInkRatio": comic_advance_to_ink,
        "targetAdvance": target_advance,
        "pointsPerContour": 10240,
        "expectedTopology": expected,
        "outputTopology": actual,
        "contours": contour_reports,
        "geometryArtifact": str(geometry.relative_to(PROJECT)),
        "visualReview": None,
    }
    report_path = PROJECT / "reports" / "multicontour-trace-0040.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")

    entries = [
        (source_by_name[name].family, engine.source_field(source_by_name[name], character).mask, "structural ½")
        for name in STRUCTURE
    ]
    entries.insert(1, (comic_field.source.family, comic_field.mask, "proportion reference"))
    entries.append(("Portsmouth constrained @", mask, str(actual)))
    tile_width, tile_height, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_width, 150 + rows * tile_height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), "Portsmouth @ — constrained construction", fill="#111", font=title)
    draw.text((40, 78), "Annotation + Routed structure · Comic Shanns proportions · closed counter", fill="#575149", font=small)
    for index, (name, source_mask, subtitle) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_width, 120 + row * tile_height
        draw.rounded_rectangle((x0, y0, x0 + tile_width - 20, y0 + tile_height - 20), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        image = _render_mask(source_mask, (tile_width - 70, tile_height - 105))
        canvas.paste(image, (x0 + (tile_width - 20 - image.width) // 2, y0 + 63 + (tile_height - 105 - image.height) // 2))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    specimen = PROJECT / "specimens" / "multicontour-trace-0040.png"
    canvas.save(specimen)
    print(json.dumps({key: value for key, value in report.items() if key != "contours"}, indent=2))
    print(specimen)


if __name__ == "__main__":
    main()
