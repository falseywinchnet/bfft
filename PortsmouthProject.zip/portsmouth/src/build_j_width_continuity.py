#!/usr/bin/env python3
"""Build a localized width-continuity correction for capital J."""

from __future__ import annotations

import json

import numpy as np

from build_terminal_repairs import clip_y, current, horizontal_capsule, rectangle, render, union
from portsmouth_engine import PROJECT


def candidate() -> np.ndarray:
    accepted = current("J")
    # The first repair introduced a 116-unit return above a roughly 86-unit
    # accepted stem. Rejoin below that intervention and continue the observed
    # local stem width into the accepted restrained cap.
    body = clip_y(accepted, 430.0, keep_below=True)
    stem = rectangle(105.0, 400.0, 191.0, 665.0)
    cap = horizontal_capsule(-70.0, 620.0, 220.0, 700.0)
    return union([body, stem, cap])


def main() -> None:
    points = candidate()
    geometry = PROJECT / "geometry" / "terminal-repair-004a-width-continuous.npz"
    np.savez_compressed(
        geometry,
        outer_0=points.astype(np.float32),
        character=np.asarray("J"),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    report = {
        "character": "J",
        "status": "experimental_width_continuity_candidate",
        "designConstraint": "restrained top retained; vertical return matched to the stem below",
        "previousReturnWidth": 116.0,
        "acceptedStemWidth": 86.0,
        "candidateReturnWidth": 86.0,
        "joinY": 430.0,
        "geometryArtifact": str(geometry.relative_to(PROJECT)),
    }
    report_path = PROJECT / "reports" / "terminal-repair-004a-width-continuous.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    render(
        "J",
        [("Width-continuous candidate", points, "86-unit return · restrained cap retained")],
        PROJECT / "specimens" / "terminal-repair-004a-width-continuous.png",
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
