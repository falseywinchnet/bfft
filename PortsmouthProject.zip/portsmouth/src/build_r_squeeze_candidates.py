#!/usr/bin/env python3
"""Render shoulder-only squeeze candidates for lowercase r."""

from __future__ import annotations

import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import rasterize_contour_complex
from build_first_ttf import archived_contours, geometry_for
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask


SCALES = (1.0, 0.94, 0.92, 0.90, 0.88)


def squeeze(contours, shoulder_scale: float):
    points = np.vstack([value for _, value in contours])
    stem_band = points[(points[:, 1] >= 50.0) & (points[:, 1] <= 250.0)]
    anchor = float(np.max(stem_band[:, 0]))
    old_center = 0.5 * (float(np.min(points[:, 0])) + float(np.max(points[:, 0])))
    transformed = []
    for role, source in contours:
        value = source.astype(np.float64).copy()
        right = value[:, 0] > anchor
        value[right, 0] = anchor + shoulder_scale * (value[right, 0] - anchor)
        transformed.append((role, value))
    stacked = np.vstack([value for _, value in transformed])
    new_center = 0.5 * (float(np.min(stacked[:, 0])) + float(np.max(stacked[:, 0])))
    recenter = old_center - new_center
    for _, value in transformed:
        value[:, 0] += recenter
    final = np.vstack([value for _, value in transformed])
    return transformed, {
        "shoulderScale": shoulder_scale,
        "stemRightAnchor": anchor,
        "recenter": recenter,
        "sourceInkWidth": float(np.ptp(points[:, 0])),
        "outputInkWidth": float(np.ptp(final[:, 0])),
        "widthReduction": float(np.ptp(points[:, 0]) - np.ptp(final[:, 0])),
    }


def main() -> None:
    contours = archived_contours(geometry_for(ord("r")))
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    columns, tile_width, tile_height = len(SCALES), 330, 430
    canvas = Image.new("RGB", (60 + columns * tile_width, 565), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((35, 25), "Portsmouth lowercase r — shoulder squeeze", fill="#111", font=title)
    draw.text(
        (35, 75),
        "stem width preserved · only geometry beyond the stem's right edge contracts · ink recentered",
        fill="#5e5850",
        font=small,
    )
    reports = []
    for index, scale in enumerate(SCALES):
        candidate, detail = squeeze(contours, scale)
        reports.append(detail)
        x0 = 30 + index * tile_width
        draw.rounded_rectangle(
            (x0, 115, x0 + tile_width - 20, 535), radius=12,
            fill="#fffdf8", outline="#cfc7bb", width=2,
        )
        mask = rasterize_contour_complex(engine, candidate)
        glyph = _render_mask(mask, (235, 295))
        canvas.paste(glyph, (x0 + (tile_width - 20 - glyph.width) // 2, 180))
        name = "CURRENT" if scale == 1.0 else f"{scale:.2f} SHOULDER"
        draw.text((x0 + 15, 132), name, fill="#985848", font=label)
        draw.text(
            (x0 + 15, 158),
            f"ink {detail['outputInkWidth']:.1f} · −{detail['widthReduction']:.1f}",
            fill="#655f57", font=small,
        )
    output = PROJECT / "specimens" / "lowercase-r-squeeze-candidates.png"
    canvas.save(output)
    report = PROJECT / "reports" / "lowercase-r-squeeze-candidates.json"
    report.write_text(json.dumps({"character": "r", "candidates": reports}, indent=2) + "\n")
    print(output)
    print(report)


if __name__ == "__main__":
    main()
