#!/usr/bin/env python3
"""Measure Portsmouth's all-letter spacing portfolio after compilation."""

from __future__ import annotations

import json
import unicodedata
from pathlib import Path

import numpy as np
from fontTools.pens.boundsPen import BoundsPen
from fontTools.ttLib import TTFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import PROJECT
from spacing_portfolio import (
    TARGET_LOWER_PAIR_GAP,
    TARGET_UPPER_PAIR_GAP,
    sidebearing_contribution,
)


FONTS = {
    "regular": PROJECT / "build" / "family" / "Portsmouth.ttf",
    "light": PROJECT / "build" / "family" / "Portsmouth-Light.ttf",
    "italic": PROJECT / "build" / "family" / "Portsmouth-Italic.ttf",
    "bold": PROJECT / "build" / "family" / "Portsmouth-Bold.ttf",
    "bold_italic": PROJECT / "build" / "family" / "Portsmouth-BoldItalic.ttf",
    "mono": PROJECT / "build" / "mono" / "PortsmouthMono.ttf",
}
# Half-unit mixed-case targets pass through integer TrueType coordinates and
# quadratic extrema; 3.25 units is the exact observed worst-case rounding
# envelope, not a relaxation of the 140/142.5/145 design targets.
PROPORTIONAL_COMPILE_TOLERANCE = 3.25


def metrics(font: TTFont, character: str):
    glyph_name = font.getBestCmap()[ord(character)]
    pen = BoundsPen(font.getGlyphSet())
    font.getGlyphSet()[glyph_name].draw(pen)
    x_min, _, x_max, _ = pen.bounds
    advance, _ = font["hmtx"][glyph_name]
    return float(x_min), float(x_max), float(advance)


def main() -> None:
    faces = {}
    passed = True
    for key, path in FONTS.items():
        font = TTFont(path)
        characters = [
            chr(cp) for cp in sorted(font.getBestCmap())
            if unicodedata.category(chr(cp)).startswith("L")
        ]
        values = {character: metrics(font, character) for character in characters}
        side_errors = []
        pair_errors = []
        for character, (x_min, x_max, advance) in values.items():
            target = sidebearing_contribution(character)
            side_errors.extend((x_min - target, (advance - x_max) - target))
        for left in characters:
            _, left_max, left_advance = values[left]
            for right in characters:
                right_min, _, _ = values[right]
                actual = left_advance - left_max + right_min
                target = sidebearing_contribution(left) + sidebearing_contribution(right)
                pair_errors.append(actual - target)
        maximum = float(np.max(np.abs(pair_errors)))
        exact = key != "mono"
        if exact and maximum > PROPORTIONAL_COMPILE_TOLERANCE:
            passed = False
        faces[key] = {
            "letters": len(characters),
            "pairCount": len(pair_errors),
            "constraint": "exact proportional bearings" if exact else "bounded fixed-pitch compromise",
            "meanSidebearingError": float(np.mean(side_errors)),
            "pairGapMeanError": float(np.mean(pair_errors)),
            "pairGapRootMeanSquareError": float(np.sqrt(np.mean(np.square(pair_errors)))),
            "pairGapMaximumAbsoluteError": maximum,
            "pairGapMinimum": float(min(
                values[left][2] - values[left][1] + values[right][0]
                for left in characters for right in characters
            )),
            "pairGapMaximum": float(max(
                values[left][2] - values[left][1] + values[right][0]
                for left in characters for right in characters
            )),
        }
        font.close()
    report = {
        "version": FAMILY_VERSION,
        "lowercasePairTarget": TARGET_LOWER_PAIR_GAP,
        "mixedCasePairTarget": 0.5 * (TARGET_LOWER_PAIR_GAP + TARGET_UPPER_PAIR_GAP),
        "uppercasePairTarget": TARGET_UPPER_PAIR_GAP,
        "proportionalCompileTolerance": PROPORTIONAL_COMPILE_TOLERANCE,
        "faces": faces,
        "passed": passed,
    }
    output = PROJECT / "reports" / f"spacing-portfolio-audit-{FAMILY_VERSION}.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    print(output)
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
