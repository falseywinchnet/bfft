#!/usr/bin/env python3
"""Geometry transforms for the Makima-derived Portsmouth family."""

from __future__ import annotations

import math

import contourpy
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

from vectorize import signed_area


def mask_topology(mask: np.ndarray) -> dict[str, int]:
    structure = np.ones((3, 3), dtype=np.uint8)
    _, components = ndimage.label(mask, structure=structure)
    background, count = ndimage.label(~mask, structure=structure)
    border = set(map(int, np.unique(np.concatenate((
        background[0], background[-1], background[:, 0], background[:, -1]
    )))))
    holes = sum(label not in border for label in range(1, count + 1))
    return {"components": int(components), "holes": int(holes)}


def rasterize_local(
    contours: list[tuple[str, np.ndarray]],
    *,
    pixels_per_unit: float,
    padding: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    stacked = np.vstack([points for _, points in contours])
    minimum = np.min(stacked, axis=0) - padding
    maximum = np.max(stacked, axis=0) + padding
    width = int(np.ceil((maximum[0] - minimum[0]) * pixels_per_unit)) + 1
    height = int(np.ceil((maximum[1] - minimum[1]) * pixels_per_unit)) + 1
    winding = np.zeros((height, width), dtype=np.int16)
    for role, contour in contours:
        layer = Image.new("1", (width, height), 0)
        pixels = [
            (
                float((x - minimum[0]) * pixels_per_unit),
                float((maximum[1] - y) * pixels_per_unit),
            )
            for x, y in contour
        ]
        ImageDraw.Draw(layer).polygon(pixels, fill=1)
        winding += (1 if role == "outer" else -1) * np.asarray(layer, dtype=np.int16)
    return winding != 0, minimum, maximum


def contours_from_mask(
    mask: np.ndarray,
    minimum: np.ndarray,
    maximum: np.ndarray,
    *,
    pixels_per_unit: float,
) -> list[tuple[str, np.ndarray]]:
    x = minimum[0] + np.arange(mask.shape[1]) / pixels_per_unit
    y = minimum[1] + np.arange(mask.shape[0]) / pixels_per_unit
    generator = contourpy.contour_generator(x=x, y=y, z=mask[::-1].astype(np.float64))
    lines = [np.asarray(line, dtype=np.float64) for line in generator.lines(0.5)]
    if not lines:
        raise ValueError("Mask vectorization produced no contours")
    areas = np.asarray([signed_area(line) for line in lines])
    outer_sign = 1.0 if areas[int(np.argmax(np.abs(areas)))] >= 0.0 else -1.0
    result = []
    for line, area in zip(lines, areas):
        role = "outer" if area * outer_sign > 0.0 else "hole"
        result.append((role, line))
    return result


def eikonal_bold(
    contours: list[tuple[str, np.ndarray]],
    *,
    target_radius: float = 22.0,
    pixels_per_unit: float = 2.0,
) -> tuple[list[tuple[str, np.ndarray]], dict]:
    padding = target_radius + 14.0
    mask, minimum, maximum = rasterize_local(
        contours,
        pixels_per_unit=pixels_per_unit,
        padding=padding,
    )
    expected = mask_topology(mask)
    outside_distance = ndimage.distance_transform_edt(~mask)

    def inflated(radius: float) -> np.ndarray:
        return mask | (outside_distance <= radius * pixels_per_unit)

    candidate = inflated(target_radius)
    actual = mask_topology(candidate)
    radius = target_radius
    constrained = actual != expected
    if constrained:
        lower, upper = 0.0, target_radius
        for _ in range(14):
            middle = 0.5 * (lower + upper)
            trial = inflated(middle)
            if mask_topology(trial) == expected:
                lower = middle
            else:
                upper = middle
        # Leave a real post-quantization clearance reserve. A merely valid
        # raster threshold can still merge after Makima fitting and integer
        # TrueType rounding, especially between detached accents and bodies.
        radius = max(0.0, lower - 3.0)
        candidate = inflated(radius)
        actual = mask_topology(candidate)
    result = contours_from_mask(
        candidate,
        minimum,
        maximum,
        pixels_per_unit=pixels_per_unit,
    )
    return result, {
        "requestedRadius": target_radius,
        "appliedRadius": radius,
        "topologyConstrained": constrained,
        "expectedTopology": expected,
        "outputTopology": actual,
        "pixelsPerUnit": pixels_per_unit,
    }


def eikonal_light(
    contours: list[tuple[str, np.ndarray]],
    *,
    target_radius: float = 18.5,
    pixels_per_unit: float = 2.0,
) -> tuple[list[tuple[str, np.ndarray]], dict]:
    """Reduce stroke radius while preserving the source contour topology."""
    padding = target_radius + 14.0
    mask, minimum, maximum = rasterize_local(
        contours,
        pixels_per_unit=pixels_per_unit,
        padding=padding,
    )
    expected = mask_topology(mask)
    inside_distance = ndimage.distance_transform_edt(mask)

    def eroded(radius: float) -> np.ndarray:
        return mask & (inside_distance > radius * pixels_per_unit)

    candidate = eroded(target_radius)
    actual = mask_topology(candidate)
    radius = target_radius
    constrained = actual != expected or not np.any(candidate)
    if constrained:
        lower, upper = 0.0, target_radius
        for _ in range(14):
            middle = 0.5 * (lower + upper)
            trial = eroded(middle)
            if np.any(trial) and mask_topology(trial) == expected:
                lower = middle
            else:
                upper = middle
        # Preserve clearance from the first topology-changing threshold so
        # curve fitting and TrueType integer rounding cannot erase a fine join.
        radius = max(0.0, lower - 2.0)
        candidate = eroded(radius)
        actual = mask_topology(candidate)
    result = contours_from_mask(
        candidate,
        minimum,
        maximum,
        pixels_per_unit=pixels_per_unit,
    )
    return result, {
        "requestedRadius": target_radius,
        "appliedRadius": radius,
        "topologyConstrained": constrained,
        "expectedTopology": expected,
        "outputTopology": actual,
        "pixelsPerUnit": pixels_per_unit,
    }


def wind_warp(
    contours: list[tuple[str, np.ndarray]],
    *,
    angle_degrees: float = 13.0,
    gust_units: float = 14.0,
) -> tuple[list[tuple[str, np.ndarray]], dict]:
    tangent = math.tan(math.radians(angle_degrees))
    result = []
    for role, source in contours:
        points = source.astype(np.float64).copy()
        y = points[:, 1]
        cap_t = np.clip(y / 700.0, 0.0, 1.0)
        gust = gust_units * np.sin(np.pi * cap_t) * np.sin(0.5 * np.pi * cap_t)
        descender_factor = np.where(y < 0.0, 0.86, 1.0)
        points[:, 0] += tangent * y * descender_factor + gust
        result.append((role, points))
    return result, {
        "angleDegrees": angle_degrees,
        "gustUnits": gust_units,
        "baselineAnchored": True,
        "capShift": tangent * 700.0,
    }


def content_aware_mono(
    contours: list[tuple[str, np.ndarray]],
    *,
    advance: float = 575.0,
    sidebearing: float = 35.0,
    pixels_per_unit: float = 1.0,
) -> tuple[list[tuple[str, np.ndarray]], dict]:
    stacked = np.vstack([points for _, points in contours])
    x_min, x_max = float(np.min(stacked[:, 0])), float(np.max(stacked[:, 0]))
    source_width = x_max - x_min
    target_width = advance - 2.0 * sidebearing
    if source_width <= target_width:
        center = 0.5 * (x_min + x_max)
        result = []
        for role, source in contours:
            points = source.astype(np.float64).copy()
            points[:, 0] -= center
            result.append((role, points))
        return result, {
            "advance": advance,
            "sourceInkWidth": source_width,
            "outputInkWidth": source_width,
            "compressed": False,
            "contentAware": False,
        }

    mask, minimum, maximum = rasterize_local(
        contours,
        pixels_per_unit=pixels_per_unit,
        padding=2.0,
    )
    density = np.mean(mask, axis=0).astype(np.float64)
    edge = np.zeros(mask.shape[1], dtype=np.float64)
    if mask.shape[1] > 1:
        changes = np.mean(mask[:, 1:] != mask[:, :-1], axis=0)
        edge[1:] += changes
        edge[:-1] += changes
    if np.max(density) > 0:
        density /= np.max(density)
    if np.max(edge) > 0:
        edge /= np.max(edge)
    importance = ndimage.gaussian_filter1d(0.18 + 0.80 * density + 1.35 * edge, sigma=2.0)
    sample_x = minimum[0] + np.arange(mask.shape[1]) / pixels_per_unit
    selected = (sample_x >= x_min) & (sample_x <= x_max)
    sample_x = sample_x[selected]
    importance = importance[selected]
    desired_ratio = target_width / source_width
    floor = 0.50

    def derivative(lam: float) -> np.ndarray:
        return np.clip(1.0 - lam / np.maximum(importance, 1e-6), floor, 1.0)

    lower, upper = 0.0, 4.0
    for _ in range(50):
        middle = 0.5 * (lower + upper)
        if float(np.mean(derivative(middle))) > desired_ratio:
            lower = middle
        else:
            upper = middle
    local_scale = derivative(upper)
    dx = np.diff(sample_x)
    cumulative = np.concatenate((
        [0.0],
        np.cumsum(0.5 * (local_scale[:-1] + local_scale[1:]) * dx),
    ))
    cumulative *= target_width / max(float(cumulative[-1]), 1e-9)
    result = []
    for role, source in contours:
        points = source.astype(np.float64).copy()
        points[:, 0] = np.interp(points[:, 0], sample_x, cumulative) - target_width / 2.0
        result.append((role, points))
    return result, {
        "advance": advance,
        "sourceInkWidth": source_width,
        "outputInkWidth": target_width,
        "compressed": True,
        "contentAware": True,
        "meanHorizontalScale": desired_ratio,
        "minimumLocalScale": float(np.min(local_scale)),
        "maximumLocalScale": float(np.max(local_scale)),
    }
