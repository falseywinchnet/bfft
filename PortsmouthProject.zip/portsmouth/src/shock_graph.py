#!/usr/bin/env python3
"""Discrete Eikonal shock-graph primitives for Portsmouth.

The skeleton is the discrete shock set of a filled glyph: locations where
inward boundary characteristics meet. Radius values are sampled from the
Euclidean distance transform and make the representation reconstructive rather
than merely descriptive.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage


@dataclass
class ShockGraph:
    skeleton: np.ndarray
    radius: np.ndarray
    degree: np.ndarray
    endpoints: np.ndarray
    junctions: np.ndarray


def _neighbors(image: np.ndarray) -> tuple[np.ndarray, ...]:
    padded = np.pad(image, 1, mode="constant")
    return (
        padded[:-2, 1:-1],   # north
        padded[:-2, 2:],     # northeast
        padded[1:-1, 2:],    # east
        padded[2:, 2:],      # southeast
        padded[2:, 1:-1],    # south
        padded[2:, :-2],     # southwest
        padded[1:-1, :-2],   # west
        padded[:-2, :-2],    # northwest
    )


def thin(mask: np.ndarray, *, maximum_iterations: int = 2048) -> np.ndarray:
    """Topology-preserving Zhang–Suen thinning of a binary glyph."""
    image = np.asarray(mask, dtype=bool).copy()
    for _ in range(maximum_iterations):
        changed = False
        for phase in (0, 1):
            neighbors = _neighbors(image)
            count = sum(neighbor.astype(np.uint8) for neighbor in neighbors)
            sequence = neighbors + (neighbors[0],)
            transitions = sum(
                ((~sequence[index]) & sequence[index + 1]).astype(np.uint8)
                for index in range(8)
            )
            n, _ne, e, _se, s, _sw, w, _nw = neighbors
            removable = image & (count >= 2) & (count <= 6) & (transitions == 1)
            if phase == 0:
                removable &= ~(n & e & s)
                removable &= ~(e & s & w)
            else:
                removable &= ~(n & e & w)
                removable &= ~(n & s & w)
            if np.any(removable):
                image[removable] = False
                changed = True
        if not changed:
            return image
    raise RuntimeError("Skeleton thinning did not converge")


def extract(mask: np.ndarray, *, pixels_per_unit: float = 1.0) -> ShockGraph:
    skeleton = thin(mask)
    radius_field = ndimage.distance_transform_edt(
        mask, sampling=1.0 / pixels_per_unit
    )
    radius = np.where(skeleton, radius_field, 0.0)
    neighbors = _neighbors(skeleton)
    degree = sum(neighbor.astype(np.uint8) for neighbor in neighbors)
    endpoints = skeleton & (degree == 1)
    junctions = skeleton & (degree >= 3)
    return ShockGraph(
        skeleton=skeleton,
        radius=radius,
        degree=degree,
        endpoints=endpoints,
        junctions=junctions,
    )


def statistics(graph: ShockGraph) -> dict[str, float | int]:
    junction_regions = ndimage.label(
        graph.junctions, structure=np.ones((3, 3), dtype=np.uint8)
    )[1]
    radii = graph.radius[graph.skeleton]
    return {
        "skeletonPixels": int(np.count_nonzero(graph.skeleton)),
        "endpoints": int(np.count_nonzero(graph.endpoints)),
        "junctionRegions": int(junction_regions),
        "medianRadius": float(np.median(radii)) if len(radii) else 0.0,
        "maximumRadius": float(np.max(radii)) if len(radii) else 0.0,
    }

