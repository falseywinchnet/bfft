#!/usr/bin/env python3
"""Compose lower web symbols from accepted Portsmouth geometry."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import resample_closed
from build_first_ttf import archived_contours, geometry_for
from outline_geometry import union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import _render_mask
from vectorize import signed_area


def load(character: str) -> list[tuple[str, np.ndarray]]:
    path = geometry_for(ord(character))
    if path is None:
        raise ValueError(f"No accepted geometry for {character!r}")
    return [(role, points.astype(np.float64)) for role, points in archived_contours(path)]


def transform(
    contours: list[tuple[str, np.ndarray]],
    *,
    scale: float = 1.0,
    x: float = 0.0,
    y: float = 0.0,
    mirror_x: bool = False,
) -> list[tuple[str, np.ndarray]]:
    result = []
    for role, source in contours:
        points = source.copy()
        points[:, 0] *= -1.0 if mirror_x else 1.0
        points *= scale
        points += np.asarray([x, y])
        result.append((role, points))
    return result


def positive(points: np.ndarray) -> np.ndarray:
    return points if signed_area(points) >= 0.0 else points[::-1]


def capsule_stem() -> np.ndarray:
    center, radius = 60.0, 42.0
    top, bottom = 390.0, -8.0
    left = np.asarray([[center - radius, top], [center - radius, bottom + radius]])
    angles = np.linspace(math.pi, 2.0 * math.pi, 96)
    cap = np.column_stack((center + radius * np.cos(angles), bottom + radius * np.sin(angles)))
    right = np.asarray([[center + radius, top]])
    return positive(np.vstack((left, cap, right)))


def oriented_for_union(contours: list[tuple[str, np.ndarray]]) -> list[np.ndarray]:
    return [positive(points) if role == "outer" else positive(points)[::-1] for role, points in contours]


def unite(contours: list[tuple[str, np.ndarray]]) -> list[tuple[str, np.ndarray]]:
    complex_ = union_contour_complex(oriented_for_union(contours), pixels_per_unit=5.0)
    return [
        (loop.role, resample_closed(loop.points, 10240))
        for loop in complex_.loops
    ]


def nonzero_mask(engine, contours: list[tuple[str, np.ndarray]]) -> np.ndarray:
    winding = np.zeros((engine.height, engine.width), dtype=np.int16)
    for role, contour in contours:
        layer = Image.new("1", (engine.width, engine.height), 0)
        points = [
            (
                float((x - engine.x_min) * engine.pixels_per_unit - 0.5),
                float((engine.y_max - y) * engine.pixels_per_unit - 0.5),
            )
            for x, y in contour
        ]
        ImageDraw.Draw(layer).polygon(points, fill=1)
        winding += (1 if role == "outer" else -1) * np.asarray(layer, dtype=np.int16)
    return winding != 0


def copyright_ring() -> list[tuple[str, np.ndarray]]:
    path = PROJECT / "geometry" / "web-symbol-candidate-00a9.npz"
    with np.load(path, allow_pickle=False) as archive:
        return [
            ("outer", archive["outer_0"].astype(np.float64)),
            ("hole", archive["hole_2"].astype(np.float64)),
        ]


def constructions() -> dict[str, tuple[list[tuple[str, np.ndarray]], list[str], str]]:
    ring = copyright_ring()
    paragraph = transform(load("P"), mirror_x=True)
    paragraph.append(("outer", capsule_stem()))
    return {
        "©": (
            unite(ring + transform(load("C"), scale=0.42, y=207.0)),
            ["modal three-source ring", "accepted Portsmouth C"],
            "nested copyright composition",
        ),
        "ª": (
            unite(transform(load("a"), scale=0.58, y=400.0)),
            ["accepted Portsmouth a"],
            "raised ordinal composition",
        ),
        "\u00ad": (
            unite(load("-")),
            ["accepted Portsmouth hyphen"],
            "discretionary-hyphen semantic alias",
        ),
        "®": (
            unite(ring + transform(load("R"), scale=0.42, y=205.0)),
            ["modal three-source ring", "accepted Portsmouth R"],
            "nested registered-mark composition",
        ),
        "¶": (
            unite(paragraph),
            ["mirrored accepted Portsmouth P", "Portsmouth secondary stem"],
            "family-derived pilcrow construction",
        ),
        "º": (
            unite(transform(load("o"), scale=0.58, y=403.0)),
            ["accepted Portsmouth o"],
            "raised ordinal composition",
        ),
        "½": (
            unite(
                transform(load("1"), scale=0.43, x=-120.0, y=390.0)
                + transform(load("/"), scale=0.82, y=60.0)
                + transform(load("2"), scale=0.43, x=120.0)
            ),
            ["accepted Portsmouth 1", "solidus", "accepted Portsmouth 2"],
            "family-derived diagonal fraction",
        ),
        "¾": (
            unite(
                transform(load("3"), scale=0.43, x=-120.0, y=390.0)
                + transform(load("/"), scale=0.82, y=60.0)
                + transform(load("4"), scale=0.43, x=120.0)
            ),
            ["accepted Portsmouth 3", "solidus", "accepted Portsmouth 4"],
            "family-derived diagonal fraction",
        ),
    }


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    entries = []
    for character, (contours, components, construction) in constructions().items():
        stem = f"{ord(character):04x}"
        geometry_output = PROJECT / "geometry" / f"web-symbol-composed-{stem}.npz"
        arrays = {
            f"{role}_{index}": points.astype(np.float32)
            for index, (role, points) in enumerate(contours)
        }
        arrays["character"] = np.asarray(character)
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(geometry_output, **arrays)
        mask = nonzero_mask(engine, contours)
        report = {
            "character": character,
            "status": "experimental_web_symbol_composition",
            "pipeline": [construction, "5x nonzero-winding overlap removal", "10240-point contour resampling"],
            "components": components,
            "pointsPerContour": 10240,
            "geometryArtifact": str(geometry_output.relative_to(PROJECT)),
            "visualReview": "candidate pending actual-font render",
        }
        (PROJECT / "reports" / f"web-symbol-composed-{stem}.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        entries.append((character, mask))

    tile_w, tile_h, columns = 300, 350, 4
    canvas = Image.new("RGB", (40 + columns * tile_w, 120 + 2 * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    draw.text((35, 25), "Portsmouth lower-web symbol compositions", fill="#111", font=title)
    for index, (character, mask) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 25 + col * tile_w, 95 + row * tile_h
        draw.rounded_rectangle((x0, y0, x0 + 275, y0 + 325), radius=10, fill="#fffdf8", outline="#d0cabf", width=2)
        draw.text((x0 + 15, y0 + 12), f"U+{ord(character):04X}  {character}", fill="#151515", font=label)
        if character == "\u00ad":
            draw.text((x0 + 55, y0 + 155), "soft hyphen → hyphen", fill="#655f57", font=label)
        else:
            glyph = _render_mask(mask, (235, 235))
            canvas.paste(glyph, (x0 + (275 - glyph.width) // 2, y0 + 65 + (235 - glyph.height) // 2))
    output = PROJECT / "specimens" / "web-symbol-compositions.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
