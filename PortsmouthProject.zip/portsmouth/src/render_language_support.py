#!/usr/bin/env python3
"""Render an honest Portsmouth 1.0 language-coverage presentation sheet."""

from __future__ import annotations

import unicodedata

from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT


SAMPLES = (
    ("ENGLISH", "Sphinx of black quartz, judge my vow."),
    ("FRENCH", "Portez ce vieux whisky au juge blond qui fume."),
    ("GERMAN", "Falsches Üben von Xylophonmusik quält jeden Zwerg."),
    ("SPANISH", "El veloz murciélago hindú comía feliz cardillo y kiwi."),
    ("POLISH", "Pchnąć w tę łódź jeża lub ośm skrzyń fig."),
    ("UKRAINIAN", "Ще й ґедзь почув ці фрази й зник у хащах."),
    ("RUSSIAN", "Съешь же ещё этих мягких французских булок, да выпей чаю."),
)


def missing_codepoints(text: str, cmap: dict[int, str]) -> list[int]:
    return sorted({
        ord(character) for character in text
        if not character.isspace() and ord(character) not in cmap
    })


def main() -> None:
    font_path = PROJECT / "build/family/Portsmouth.ttf"
    font = TTFont(font_path)
    cmap = font.getBestCmap()
    font.close()
    width, row_height = 2200, 235
    canvas = Image.new("RGB", (width, 205 + len(SAMPLES) * row_height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui_path, 46)
    ui = ImageFont.truetype(ui_path, 19)
    small = ImageFont.truetype(ui_path, 15)
    portsmouth = ImageFont.truetype(font_path, 57)
    fallback = ImageFont.truetype(ui_path, 50)
    draw.text((58, 34), "Portsmouth 1.0 — language coverage", font=title, fill="#171715")
    draw.text(
        (60, 103),
        "Black rows are rendered in Portsmouth · gray Cyrillic rows are target copy only and explicitly unsupported",
        font=ui,
        fill="#5e5850",
    )
    y = 165
    for language, sample in SAMPLES:
        missing = missing_codepoints(sample, cmap)
        supported = not missing
        fill = "#fffdf8" if supported else "#e7e2d9"
        outline = "#c9c0b3" if supported else "#aa8178"
        draw.rounded_rectangle((45, y, width - 45, y + row_height - 20), radius=12, fill=fill, outline=outline, width=2)
        draw.text((70, y + 22), language, font=ui, fill="#985848" if supported else "#7b4f49")
        status = "SUPPORTED / PORTSMOUTH 1.0" if supported else "NOT YET ENCODED / CYRILLIC REQUIRED"
        draw.text((315, y + 24), status, font=small, fill="#6e675e" if supported else "#9a5147")
        draw.text((70, y + 76), sample, font=portsmouth if supported else fallback, fill="#171715" if supported else "#77716a")
        if missing:
            scripts = sorted({unicodedata.name(chr(cp), "UNKNOWN").split()[0] for cp in missing})
            draw.text(
                (72, y + 163),
                f"Missing {len(missing)} distinct codepoints · script: {', '.join(scripts)} · fallback shown only to preserve the target sentence",
                font=small,
                fill="#815d57",
            )
        y += row_height
    output = PROJECT / "specimens/Portsmouth-1.0-language-support.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
