#!/usr/bin/env python3
"""Promote the visually accepted 78 extended majority candidates."""

from __future__ import annotations

import json
import shutil

from portsmouth_engine import PROJECT


PREFIX = "extended-majority-candidate"


def main() -> None:
    audit = json.loads(
        (PROJECT / "reports" / "extended-coverage-audit-0.101.json").read_text()
    )
    candidates = [
        entry for entry in audit["entries"]
        if entry["compatiblePersistentTopology"] and not entry["production"]
    ]
    promoted = []
    for entry in candidates:
        codepoint = ord(entry["character"])
        composed_geometry = PROJECT / "geometry" / f"extended-composed-candidate-{codepoint:04x}.npz"
        selected_prefix = "extended-composed-candidate" if composed_geometry.exists() else PREFIX
        candidate_geometry = PROJECT / "geometry" / f"{selected_prefix}-{codepoint:04x}.npz"
        candidate_report = PROJECT / "reports" / f"{selected_prefix}-{codepoint:04x}.json"
        if not candidate_geometry.exists() or not candidate_report.exists():
            raise FileNotFoundError(entry["codepoint"])
        detail = json.loads(candidate_report.read_text())
        if detail["outputTopology"] != detail["expectedTopology"]:
            raise ValueError(f"{entry['codepoint']} candidate changes topology")
        geometry = PROJECT / "geometry" / f"multicontour-trace-{codepoint:04x}.npz"
        report = PROJECT / "reports" / f"multicontour-trace-{codepoint:04x}.json"
        if geometry.exists() or report.exists():
            raise FileExistsError(f"Refusing to replace existing production geometry for {entry['codepoint']}")
        shutil.copy2(candidate_geometry, geometry)
        detail.update({
            "status": (
                "experimental_promoted_extended_composition"
                if selected_prefix == "extended-composed-candidate"
                else "experimental_promoted_extended_majority"
            ),
            "candidateGeometry": str(candidate_geometry.relative_to(PROJECT)),
            "candidateReport": str(candidate_report.relative_to(PROJECT)),
            "geometryArtifact": str(geometry.relative_to(PROJECT)),
            "visualReview": "passes complete 78-glyph rendered acceptance sheet",
        })
        report.write_text(json.dumps(detail, indent=2) + "\n")
        promoted.append(entry["codepoint"])
    output = PROJECT / "reports" / "extended-majority-promotion-0.103.json"
    output.write_text(json.dumps({
        "status": "promoted",
        "count": len(promoted),
        "codepoints": promoted,
        "reviewSpecimen": "specimens/extended-majority-candidates-0.103.png",
    }, indent=2) + "\n")
    print(output)
    print(json.dumps({"promoted": len(promoted)}, indent=2))


if __name__ == "__main__":
    main()
