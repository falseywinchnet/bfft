#!/usr/bin/env python3
"""Render alphabet, symbol, and fixed-pitch diagnostics for Portsmouth."""

from __future__ import annotations

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT
from build_portsmouth_family import FAMILY_VERSION


def main() -> None:
    directory = PROJECT / "build" / "family"
    faces = [
        ("Regular", directory / "Portsmouth.ttf"),
        ("Light", directory / "Portsmouth-Light.ttf"),
        ("Italic", directory / "Portsmouth-Italic.ttf"),
        ("Bold", directory / "Portsmouth-Bold.ttf"),
        ("Bold Italic", directory / "Portsmouth-BoldItalic.ttf"),
        ("Mono 575", PROJECT / "build/mono/PortsmouthMono.ttf"),
    ]
    canvas = Image.new("RGB", (2200, 3315), "#f1ede4")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 40)
    label = ImageFont.truetype(ui, 17)
    draw.text((45, 25), f"Portsmouth {FAMILY_VERSION} — family diagnostics", fill="#111", font=title)
    rows = [
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "abcdefghijklmnopqrstuvwxyz",
        "0123456789  !?¿¡  @#%&  ©®  ¼½¾  ¶§",
        "MWmæ minimum rhythm / aqua quay / 1lI| / 0OØø",
        "Ăă Ąą Đđ Ĕĕ Ęę Ğğ Ģģ ĤĦħ Ĩĩ Ĭĭ Įį İ Ĳĳ Ĵĵ",
        "Ķ Ĺĺ Ļļ Ľľ Ŀŀ Łł Ņņ Ŋŋ Ŏŏ Őő Œœ Ŗŗ ŚŜŝ Š",
        "Ţţ Ũũ Ŭŭ Űű Ųų ſ Ǣǣ ǰ Șș Țț Ȯȯ Ȳȳ ȷ",
    ]
    y = 95
    for name, path in faces:
        draw.text((48, y), name.upper(), fill="#985848", font=label)
        face = ImageFont.truetype(path, 40)
        for index, text in enumerate(rows):
            draw.text((45, y + 28 + index * 62), text, fill="#171715", font=face)
        draw.line((45, y + 465, 2155, y + 465), fill="#c9c0b3", width=2)
        y += 500

    mono = ImageFont.truetype(PROJECT / "build/mono/PortsmouthMono.ttf", 38)
    draw.text((48, y), "MONO CELL TEST — VERTICAL RULES EVERY 575 FONT UNITS", fill="#985848", font=label)
    scale = 38 / 1000.0
    start_x = 50
    cell = 575 * scale
    for index in range(41):
        x = int(round(start_x + index * cell))
        draw.line((x, y + 35, x, y + 175), fill="#d3cbc0", width=1)
    draw.text((start_x, y + 50), "iiii  WWWW  mæmæ  0000  @@@@  J1Il", fill="#171715", font=mono)
    output = PROJECT / "specimens" / f"Portsmouth-Family-{FAMILY_VERSION}-diagnostics.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
