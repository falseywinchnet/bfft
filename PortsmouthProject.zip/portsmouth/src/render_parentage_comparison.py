#!/usr/bin/env python3
"""Render all five source faces against the canonical Portsmouth master."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import EikonalMidpointEngine, PROJECT


def font_for_cap_height(path: Path, target_pixels: int) -> ImageFont.FreeTypeFont:
    probe = ImageFont.truetype(path, 1000)
    bounds = probe.getbbox("H")
    measured = max(1, bounds[3] - bounds[1])
    return ImageFont.truetype(path, max(1, round(1000 * target_pixels / measured)))


def fit_text(draw, path: Path, text: str, target_cap: int, maximum_width: int):
    cap = target_cap
    while cap > 20:
        font = font_for_cap_height(path, cap)
        if draw.textbbox((0, 0), text, font=font)[2] <= maximum_width:
            return font
        cap -= 2
    return font_for_cap_height(path, cap)


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    rows = [(source.family, source.path, False) for source in engine.sources]
    rows.append(("Portsmouth", PROJECT / "build" / "family" / "Portsmouth.ttf", True))

    width, row_height = 2400, 325
    canvas = Image.new("RGB", (width, 225 + len(rows) * row_height + 105), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui_path, 48)
    subtitle = ImageFont.truetype(ui_path, 19)
    label = ImageFont.truetype(ui_path, 21)
    small = ImageFont.truetype(ui_path, 15)
    draw.text((62, 35), "Five pedigrees, one Portsmouth", fill="#171715", font=title)
    draw.text(
        (65, 99),
        "The same words at matched cap height — inherited structural memory, no inherited identity",
        fill="#5e5850",
        font=subtitle,
    )
    draw.text(
        (65, 138),
        "Annotation Mono · Comic Shanns Mono · Syne Mono · Bedstead · Routed Gothic  →  Portsmouth",
        fill="#985848",
        font=subtitle,
    )

    samples = (
        "Hamburgefontsiv  minimum rhythm",
        "AQUAMARINE QUAYS  1lI|  0OQq",
        "a q æ m w  @ & ?  0123456789",
    )
    y = 195
    for name, path, is_child in rows:
        fill = "#fffaf0" if is_child else "#fffdf8"
        outline = "#b55b4b" if is_child else "#d0c8bb"
        draw.rounded_rectangle(
            (45, y, width - 45, y + row_height - 18),
            radius=14,
            fill=fill,
            outline=outline,
            width=3 if is_child else 1,
        )
        role = "RESULT / MAKIMA MASTER" if is_child else "PARENT SOURCE"
        draw.text((72, y + 20), name, fill="#171715", font=label)
        name_right = draw.textbbox((72, y + 20), name, font=label)[2]
        draw.text((name_right + 34, y + 24), role, fill="#a05748" if is_child else "#82796e", font=small)
        for index, sample in enumerate(samples):
            face = fit_text(draw, path, sample, 56 if index == 0 else 43, width - 175)
            draw.text((72, y + 56 + index * 76), sample, fill="#171715", font=face)
        y += row_height

    draw.text(
        (62, y + 12),
        f"Portsmouth {FAMILY_VERSION} · equal-weight routed fusion · normalized vertical landmarks · periodic Makima true-shape curves",
        fill="#5e5850",
        font=subtitle,
    )
    output = PROJECT / "specimens" / f"Portsmouth-Parentage-{FAMILY_VERSION}.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
