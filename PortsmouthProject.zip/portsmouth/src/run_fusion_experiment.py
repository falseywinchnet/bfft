#!/usr/bin/env python3
"""Compare rejected and structurally registered lowercase-m fusion."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from structural_fusion import (
    field_mean_mask,
    ordered_top_band_fusion,
    register_stems,
    shoulder_mass_delta,
)


def render_tile(mask: np.ndarray, maximum: tuple[int, int]) -> Image.Image:
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return Image.new("RGB", maximum, "white")
    left, right = max(0, xs.min() - 15), min(mask.shape[1], xs.max() + 16)
    top, bottom = max(0, ys.min() - 15), min(mask.shape[0], ys.max() + 16)
    crop = (255 - mask[top:bottom, left:right].astype(np.uint8) * 255)
    image = Image.fromarray(crop, "L").convert("RGB")
    image.thumbnail(maximum, Image.Resampling.LANCZOS)
    return image


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    original = [
        engine.source_field(source, "m") for source in engine.active_sources("m")
    ]
    registered, target_stems, source_stems = register_stems(engine, original)
    raw, registered_mask, level = field_mean_mask(engine, registered)
    ordered_mask, replaced = ordered_top_band_fusion(
        engine, registered, registered_mask
    )
    ordered_sdf = engine.signed_distance(ordered_mask)
    rejected = engine.midpoint("m")

    entries = [(field.source.family, field.mask) for field in original]
    entries.extend((
        ("Rejected unregistered SDF", rejected.mask),
        (f"Stem-registered SDF · {level:+.1f}", registered_mask),
        ("Ordered shoulder/radius fusion", ordered_mask),
    ))
    deltas = {
        field.source.filename: shoulder_mass_delta(
            engine, registered[index].mask, target_stems
        )
        for index, field in enumerate(original)
    }
    deltas["rejected"] = shoulder_mass_delta(engine, rejected.mask, target_stems)
    deltas["registeredSDF"] = shoulder_mass_delta(
        engine, registered_mask, target_stems
    )
    deltas["orderedFusion"] = shoulder_mass_delta(
        engine, ordered_mask, target_stems
    )
    report = {
        "character": "m",
        "targetStemAxes": list(map(float, target_stems)),
        "sourceStemAxes": source_stems,
        "registeredFieldLevel": level,
        "orderedColumns": replaced,
        "secondMinusFirstShoulderMassY": deltas,
        "topology": {
            "rejected": engine.topology(rejected.mask),
            "registeredSDF": engine.topology(registered_mask),
            "orderedFusion": engine.topology(ordered_mask),
        },
        "distanceOrderedToRejected": engine.field_distance(
            ordered_sdf, rejected.sdf
        ),
    }
    report_path = PROJECT / "reports" / "fusion-006d.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")

    tile_w, tile_h, columns = 370, 400, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new(
        "RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 34
    )
    label = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 19
    )
    small = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 14
    )
    draw.text((40, 30), "Portsmouth lowercase m — fusion experiment 01", fill="#111", font=title)
    draw.text(
        (40, 78),
        "global vertical landmarks · registered stem axes · ordered shoulder mass",
        fill="#575149", font=small,
    )
    for index, (name, mask) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
            radius=10, fill="#fffdf8", outline="#d0cabf", width=2,
        )
        glyph = render_tile(mask, (tile_w - 65, tile_h - 110))
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 66 + (tile_h - 110 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        key = original[index].source.filename if index < len(original) else (
            "rejected" if index == len(original)
            else "registeredSDF" if index == len(original) + 1
            else "orderedFusion"
        )
        draw.text(
            (x0 + 15, y0 + 43),
            f"diagnostic shoulder centroid Δy: {deltas[key]:+.1f}",
            fill="#655f57", font=small,
        )
    output = PROJECT / "specimens" / "fusion-006d.png"
    canvas.save(output)
    print(json.dumps(report, indent=2))
    print(output)


if __name__ == "__main__":
    main()
