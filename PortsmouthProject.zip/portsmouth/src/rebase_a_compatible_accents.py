#!/usr/bin/env python3
"""Place compatible detached marks over the approved one-storey a base."""

from __future__ import annotations

import json
import shutil

import numpy as np

from boundary_trace import rasterize_contour_complex, resample_closed
from portsmouth_engine import EikonalMidpointEngine, PROJECT


CHARACTERS = "äā"


def archived(path):
    with np.load(path, allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key].astype(float))
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    base_path = PROJECT / "geometry" / "multicontour-trace-0061.npz"
    base = archived(base_path)
    base_top = max(float(np.max(points[:, 1])) for role, points in base if role == "outer")
    for character in CHARACTERS:
        stem = f"{ord(character):04x}"
        geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
        report_path = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
        original = archived(geometry)
        original_outer = max(
            (points for role, points in original if role == "outer"),
            key=lambda points: abs(float(np.ptp(points[:, 0]) * np.ptp(points[:, 1]))),
        )
        original_base_top = float(np.max(original_outer[:, 1]))
        marks = [
            (role, points)
            for role, points in original
            if float(np.min(points[:, 1])) > original_base_top + 10.0
        ]
        if not marks:
            raise ValueError(f"No detached mark found for {character}")
        lowest_mark = min(float(np.min(points[:, 1])) for _, points in marks)
        shift = max(0.0, base_top + 24.0 - lowest_mark)
        marks = [(role, points + np.array([0.0, shift])) for role, points in marks]
        output = base + marks
        actual = engine.topology(rasterize_contour_complex(engine, output))
        expected = {
            "components": sum(role == "outer" for role, _ in output),
            "holes": sum(role == "hole" for role, _ in output),
        }
        if actual != expected:
            raise ValueError(f"{character} rebase topology {actual}, expected {expected}")
        backup_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}-pre-one-storey-a.npz"
        backup_report = PROJECT / "reports" / f"multicontour-trace-{stem}-pre-one-storey-a.json"
        if not backup_geometry.exists():
            shutil.copy2(geometry, backup_geometry)
        if not backup_report.exists():
            shutil.copy2(report_path, backup_report)
        arrays = {
            f"{role}_{index}": resample_closed(points, 10240).astype(np.float32)
            for index, (role, points) in enumerate(output)
        }
        arrays["character"] = np.asarray(character)
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(geometry, **arrays)
        old_report = json.loads(backup_report.read_text())
        report = {
            "character": character,
            "status": "experimental_rebased_one_storey_a_accent",
            "designConstraint": "approved one-storey a with retained detached accent geometry",
            "pipeline": [
                "approved_one_storey_a_base",
                "retained_existing_detached_mark_geometry",
                "minimum_optical_separation",
            ],
            "sources": [
                "ComicShannsMono-Regular.ttf", "SyneMono-Regular.ttf",
                "routed-gothic.ttf",
            ],
            "equalSourceWeight": 1.0 / 3.0,
            "accentSources": old_report.get("sources", []),
            "accentEqualSourceWeight": old_report.get("equalSourceWeight"),
            "baseCharacter": "a",
            "accentVerticalAdjustment": shift,
            "expectedTopology": expected,
            "outputTopology": actual,
            "pointsPerContour": 10240,
            "baselineGeometry": str(backup_geometry.relative_to(PROJECT)),
            "baselineReport": str(backup_report.relative_to(PROJECT)),
            "geometryArtifact": str(geometry.relative_to(PROJECT)),
            "visualReview": None,
        }
        report_path.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"character": character, "topology": actual}, ensure_ascii=False))


if __name__ == "__main__":
    main()
