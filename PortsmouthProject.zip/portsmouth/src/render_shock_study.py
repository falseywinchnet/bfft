#!/usr/bin/env python3
"""Render source shock graphs to validate structural representation."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from shock_graph import extract, statistics


def render(character: str = "m") -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    fields = [
        engine.source_field(source, character)
        for source in engine.active_sources(character)
    ]
    entries = []
    report = {}
    for field in fields:
        graph = extract(field.mask, pixels_per_unit=engine.pixels_per_unit)
        entries.append((field.source.family, field.mask, graph))
        report[field.source.filename] = statistics(graph)

    tile_w, tile_h, columns = 390, 420, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new(
        "RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    title_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 34
    )
    label_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 20
    )
    small_font = ImageFont.truetype(
        "/System/Library/Fonts/Supplemental/Arial.ttf", 14
    )
    draw.text(
        (40, 30), f"Portsmouth structural basis study — {character}",
        fill="#111", font=title_font,
    )
    draw.text(
        (40, 78), "filled geometry · Eikonal shock graph · radius-colored junctions",
        fill="#575149", font=small_font,
    )
    for index, (label, mask, graph) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20),
            radius=10, fill="#fffdf8", outline="#d0cabf", width=2,
        )
        ys, xs = np.nonzero(mask)
        left, right = max(0, xs.min() - 15), min(mask.shape[1], xs.max() + 16)
        top, bottom = max(0, ys.min() - 15), min(mask.shape[0], ys.max() + 16)
        crop_mask = mask[top:bottom, left:right]
        crop_skeleton = graph.skeleton[top:bottom, left:right]
        crop_junctions = graph.junctions[top:bottom, left:right]
        layer = np.full((*crop_mask.shape, 3), 255, dtype=np.uint8)
        layer[crop_mask] = (26, 26, 24)
        expanded_skeleton = ndimage.binary_dilation(crop_skeleton, iterations=1)
        expanded_junctions = ndimage.binary_dilation(crop_junctions, iterations=3)
        layer[expanded_skeleton] = (222, 75, 52)
        layer[expanded_junctions] = (40, 119, 173)
        glyph = Image.fromarray(layer)
        glyph.thumbnail((tile_w - 70, tile_h - 115), Image.Resampling.LANCZOS)
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 68 + (tile_h - 115 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        stat = statistics(graph)
        draw.text((x0 + 16, y0 + 16), label, fill="#151515", font=label_font)
        draw.text(
            (x0 + 16, y0 + 45),
            f"endpoints {stat['endpoints']} · junction regions {stat['junctionRegions']}",
            fill="#625c54", font=small_font,
        )
    stem = f"{ord(character):04x}"
    output = PROJECT / "specimens" / f"shock-graph-{stem}.png"
    canvas.save(output)
    (PROJECT / "reports" / f"shock-graph-{stem}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(output)


if __name__ == "__main__":
    render("m")

