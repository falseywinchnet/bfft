#!/usr/bin/env python3
"""Build the first installable Portsmouth font from accepted geometry archives."""

from __future__ import annotations

import json
import math
import unicodedata
from pathlib import Path

import numpy as np
from fontTools.agl import UV2AGL
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import EikonalMidpointEngine, PROJECT
from spacing_portfolio import is_letter, solve_proportional
from vectorize import signed_area


VERSION = "1.0"
MODAL_ACCENTS = frozenset(map(ord, "àáâãåèéêñõ"))
SIMPLIFICATION_TOLERANCE = 0.8
MINIMUM_SIDEBEARING = 35
GRAPHIC_CODEPOINTS = tuple(range(0x20, 0x7F)) + tuple(range(0xA0, 0x100))
# Post-Latin-1 geometry already carried through the same dense transport and
# contour-unity pipeline. Every character is encoded by all five parent files;
# project case routing still determines the contributing outlines.
ALL_SOURCE_EXTENDED_CODEPOINTS = (
    0x0100, 0x0101, 0x0106, 0x010A, 0x010B, 0x010C, 0x010E,
    0x0112, 0x0113, 0x0116, 0x0117, 0x011A, 0x0120, 0x0121,
    0x012A, 0x012B, 0x0131, 0x0143, 0x0147, 0x014C, 0x014D,
    0x0154, 0x0158, 0x015E, 0x015F, 0x0164, 0x016A, 0x016B,
    0x016E, 0x0174, 0x0175, 0x0176, 0x0177, 0x0178, 0x0179,
    0x017B, 0x017C, 0x017D,
)
MAJORITY_EXTENDED_CODEPOINTS = (
    0x0102, 0x0103, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115,
    0x0118, 0x0119, 0x011E, 0x011F, 0x0122, 0x0123, 0x0124, 0x0126,
    0x0127, 0x0128, 0x0129, 0x012C, 0x012D, 0x012E, 0x012F, 0x0130,
    0x0132, 0x0133, 0x0134, 0x0135, 0x0136, 0x0139, 0x013A, 0x013B,
    0x013C, 0x013D, 0x013E, 0x013F, 0x0140, 0x0141, 0x0142, 0x0145,
    0x0146, 0x014A, 0x014B, 0x014E, 0x014F, 0x0150, 0x0151, 0x0152,
    0x0153, 0x0156, 0x0157, 0x015A, 0x015C, 0x015D, 0x0160, 0x0162,
    0x0163, 0x0168, 0x0169, 0x016C, 0x016D, 0x0170, 0x0171, 0x0172,
    0x0173, 0x017F, 0x01E2, 0x01E3, 0x01F0, 0x0218, 0x0219, 0x021A,
    0x021B, 0x022E, 0x022F, 0x0232, 0x0233, 0x0237,
)
EXTENDED_CODEPOINTS = ALL_SOURCE_EXTENDED_CODEPOINTS + MAJORITY_EXTENDED_CODEPOINTS
PUNCTUATION_CODEPOINTS = (0x2014, 0x2018, 0x2019, 0x201C, 0x201D)
EASTERN_LATIN_CODEPOINTS = tuple(map(ord, "ćĈĉčďěĜĝĥķńňŕřśšťůźž"))
PRODUCTION_CODEPOINTS = (
    GRAPHIC_CODEPOINTS + EXTENDED_CODEPOINTS
    + EASTERN_LATIN_CODEPOINTS + PUNCTUATION_CODEPOINTS
)


def geometry_for(codepoint: int) -> Path | None:
    stem = f"{codepoint:04x}"
    for prefix in (
        "letter-repair", "letter-extension", "punctuation-repair",
        "boundary-trace", "multicontour-trace",
    ):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            report_path = PROJECT / "reports" / f"{prefix}-{stem}.json"
            if report_path.exists():
                status = json.loads(report_path.read_text()).get("status", "")
                if status.startswith("rejected"):
                    continue
            return path
    return None


def glyph_name(codepoint: int) -> str:
    return UV2AGL.get(codepoint, f"uni{codepoint:04X}")


def _point_segment_distance(
    points: np.ndarray, start: np.ndarray, end: np.ndarray
) -> np.ndarray:
    vector = end - start
    denominator = float(np.dot(vector, vector))
    if denominator <= 1e-12:
        return np.linalg.norm(points - start, axis=1)
    fraction = np.clip(((points - start) @ vector) / denominator, 0.0, 1.0)
    projection = start + fraction[:, None] * vector
    return np.linalg.norm(points - projection, axis=1)


def _rdp_open(points: np.ndarray, tolerance: float) -> np.ndarray:
    if len(points) <= 2:
        return points
    keep = np.zeros(len(points), dtype=bool)
    keep[[0, -1]] = True
    stack = [(0, len(points) - 1)]
    while stack:
        first, last = stack.pop()
        if last - first <= 1:
            continue
        distances = _point_segment_distance(
            points[first + 1:last], points[first], points[last]
        )
        if distances.size and float(np.max(distances)) > tolerance:
            split = first + int(np.argmax(distances)) + 1
            keep[split] = True
            stack.append((first, split))
            stack.append((split, last))
    return points[keep]


def simplify_closed(points: np.ndarray, tolerance: float) -> np.ndarray:
    """RDP a loop without treating its coincident endpoints as one baseline."""
    points = np.asarray(points, dtype=np.float64)
    if np.allclose(points[0], points[-1]):
        points = points[:-1]
    center = np.mean(points, axis=0)
    first = int(np.argmax(np.sum((points - center) ** 2, axis=1)))
    points = np.roll(points, -first, axis=0)
    opposite = int(np.argmax(np.sum((points - points[0]) ** 2, axis=1)))
    first_half = _rdp_open(points[:opposite + 1], tolerance)
    second_half = _rdp_open(
        np.vstack((points[opposite:], points[0])), tolerance
    )
    simplified = np.vstack((first_half[:-1], second_half[:-1]))
    if len(simplified) < 3:
        raise ValueError("Contour simplification collapsed a closed path")
    return simplified


def archived_contours(path: Path) -> list[tuple[str, np.ndarray]]:
    with np.load(path, allow_pickle=False) as archive:
        return [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files
            if key not in {"character", "unitsPerEm"}
        ]


def empty_glyph():
    return TTGlyphPen(None).glyph()


def notdef_glyph():
    pen = TTGlyphPen(None)
    pen.moveTo((55, -20))
    pen.lineTo((545, -20))
    pen.lineTo((545, 720))
    pen.lineTo((55, 720))
    pen.closePath()
    pen.moveTo((135, 65))
    pen.lineTo((135, 635))
    pen.lineTo((465, 635))
    pen.lineTo((465, 65))
    pen.closePath()
    return pen.glyph()


def mean_advance(engine: EikonalMidpointEngine, character: str) -> float:
    if character == "r":
        report = PROJECT / "reports" / "boundary-trace-0072.json"
        if report.exists():
            data = json.loads(report.read_text())
            if data.get("status") == "experimental_promoted_shoulder_squeeze":
                return float(data["targetAdvance"])
    if character in "aqæ":
        report = PROJECT / "reports" / f"multicontour-trace-{ord(character):04x}.json"
        if report.exists():
            data = json.loads(report.read_text())
            if "targetAdvance" in data and (
                data.get("status") == f"experimental_user_directed_one_storey_{character}"
                or data.get("status") == "experimental_promoted_explicit_ligature"
            ):
                return float(data["targetAdvance"])
    if character == "@":
        report = PROJECT / "reports" / "multicontour-trace-0040.json"
        if report.exists():
            return float(json.loads(report.read_text())["targetAdvance"])
    stem = f"{ord(character):04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        report = PROJECT / "reports" / f"{prefix}-{stem}.json"
        if not report.exists():
            continue
        data = json.loads(report.read_text())
        if (
            data.get("status") == "experimental_promoted_extended_composition"
            and "targetAdvance" in data
        ):
            return float(data["targetAdvance"])
        if data.get("status") in {
            "experimental_majority_source_trace",
            "experimental_promoted_extended_majority",
        }:
            selected = set(data["sources"])
            return float(np.mean([
                source.widths[ord(character)]
                for source in engine.sources if source.filename in selected
            ]))
    sources = engine.active_sources(character)
    return float(np.mean([source.widths[ord(character)] for source in sources]))


def outline_glyph(
    contours: list[tuple[str, np.ndarray]],
    advance: int,
    *,
    simplification_tolerance: float = SIMPLIFICATION_TOLERANCE,
) -> tuple[object, int, dict]:
    simplified = []
    original_points = 0
    for role, points in contours:
        original_points += len(points)
        contour = simplify_closed(points, simplification_tolerance)
        area = signed_area(contour)
        # TrueType convention: black contours clockwise, counters counterclockwise.
        should_be_clockwise = role == "outer"
        if (area < 0.0) != should_be_clockwise:
            contour = contour[::-1]
        simplified.append((role, contour))
    minimum_x = min(float(np.min(points[:, 0])) for _, points in simplified)
    maximum_x = max(float(np.max(points[:, 0])) for _, points in simplified)
    shift = advance / 2.0
    pen = TTGlyphPen(None)
    final_points = 0
    final_contours = 0
    integer_contours = []
    for role, contour in simplified:
        integer = np.rint(contour + np.array([shift, 0.0])).astype(np.int32)
        keep = np.ones(len(integer), dtype=bool)
        keep[1:] = np.any(integer[1:] != integer[:-1], axis=1)
        integer = integer[keep]
        if len(integer) > 1 and np.array_equal(integer[0], integer[-1]):
            integer = integer[:-1]
        if len(np.unique(integer, axis=0)) < 3:
            continue
        pen.moveTo(tuple(map(int, integer[0])))
        for point in integer[1:]:
            pen.lineTo(tuple(map(int, point)))
        pen.closePath()
        integer_contours.append((role, integer))
        final_points += len(integer)
        final_contours += 1
    if final_contours == 0:
        raise ValueError("No contours survived integer conversion")
    left = int(math.floor(minimum_x + shift))
    right = int(math.ceil(maximum_x + shift))
    return pen.glyph(), left, {
        "originalPoints": original_points,
        "outputPoints": final_points,
        "contours": final_contours,
        "xMin": left,
        "xMax": right,
        "leftSidebearing": left,
        "rightSidebearing": advance - right,
    }


def render_specimen(font_path: Path, output: Path, version: str) -> None:
    canvas = Image.new("RGB", (1800, 1570), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    small = ImageFont.truetype(ui, 17)
    face = ImageFont.truetype(font_path, 80)
    display = ImageFont.truetype(font_path, 128)
    draw.text((55, 32), f"Portsmouth Regular {version} · first TTF series", fill="#111", font=title)
    draw.text(
        (55, 82),
        "Archived fusion geometry · unresolved characters intentionally absent",
        fill="#5d574e",
        font=small,
    )
    lines = [
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "abcdefghijklmnopqrstuvwxyz",
        "0123456789  0/1/i/I/l",
        "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
        "ÀÁÂÃÄÅ Æ Ç ÈÉÊË ÌÍÎÏ Ñ ÒÓÔÕÖ Ø",
        "ÙÚÛÜ Ý Þ   ä æ ç ë ìíîï òóôö ùúûü ýþÿ",
        "£¥¢ ¤  ×÷±  ¼  ²³¹ µ·  Ðð Øø ß  «Portsmouth»  ¿Qué?",
        "Āā ĆČ Ċċ Ď Ēē Ėė Ě Ġġ Īī ı ŃŇ Ōō ŔŘ Şş",
        "Ť Ūū Ů Ŵŵ Ŷŷ Ÿ ŹŻż Ž",
    ]
    y = 145
    for line in lines:
        draw.text((65, y), line, fill="#171715", font=face)
        y += 120
    draw.line((60, 1355, 1740, 1355), fill="#c74e3c", width=2)
    draw.text((70, 1360), "Portsmouth", fill="#111", font=display, anchor="la")
    draw.text((70, 1510), "baseline", fill="#8b8175", font=small)
    canvas.save(output)


def build(
    *,
    version: str = VERSION,
    excluded_codepoints: frozenset[int] = frozenset(),
    codepoints: tuple[int, ...] = PRODUCTION_CODEPOINTS,
) -> tuple[Path, Path, dict]:
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    archived = [
        cp for cp in codepoints
        if cp not in excluded_codepoints and geometry_for(cp) is not None
    ]
    cmap_codepoints = sorted(set(archived) | {0x20, 0xA0})
    names = {cp: glyph_name(cp) for cp in cmap_codepoints}
    glyph_order = [".notdef"] + [names[cp] for cp in cmap_codepoints]
    glyphs = {".notdef": notdef_glyph()}
    metrics = {".notdef": (600, 55)}
    cmap = {cp: names[cp] for cp in cmap_codepoints}
    glyph_report = []
    space_width = int(round(float(np.mean([
        source.widths[0x20]
        for source in engine.sources
        if source.filename in {
            "AnnotationMono-VF.ttf",
            "ComicShannsMono-Regular.ttf",
            "routed-gothic.ttf",
        }
    ]))))
    for cp in cmap_codepoints:
        name = names[cp]
        path = geometry_for(cp)
        if path is None:
            glyphs[name] = empty_glyph()
            metrics[name] = (space_width, 0)
            glyph_report.append({
                "codepoint": f"U+{cp:04X}",
                "character": chr(cp),
                "name": name,
                "kind": "spacing",
                "advance": space_width,
            })
            continue
        contours = archived_contours(path)
        all_points = np.vstack([points for _, points in contours])
        width = float(np.max(all_points[:, 0]) - np.min(all_points[:, 0]))
        character = chr(cp)
        if is_letter(character):
            contours, advance, _ = solve_proportional(contours, character)
            width = float(np.ptp(np.vstack([points for _, points in contours])[:, 0]))
            desired_advance = float(advance)
        else:
            desired_advance = mean_advance(engine, character)
            advance = int(math.ceil(max(desired_advance, width + 2 * MINIMUM_SIDEBEARING)))
        glyph, lsb, detail = outline_glyph(contours, advance)
        glyphs[name] = glyph
        metrics[name] = (advance, lsb)
        glyph_report.append({
            "codepoint": f"U+{cp:04X}",
            "character": chr(cp),
            "name": name,
            "kind": "outline",
            "geometry": str(path.relative_to(PROJECT)),
            "equalWeightMeanAdvance": desired_advance,
            "advance": advance,
            **detail,
        })

    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(glyph_order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=850, descent=-250, lineGap=0)
    fb.setupNameTable({
        "familyName": "Portsmouth Regular",
        "styleName": "Regular",
        "uniqueFontIdentifier": f"PortsmouthRegular-Regular {version}",
        "fullName": "Portsmouth Regular",
        "psName": "PortsmouthRegular-Regular",
        "typographicFamily": "Portsmouth Regular",
        "typographicSubfamily": "Regular",
        "wwsFamilyName": "Portsmouth Regular",
        "wwsSubfamilyName": "Regular",
        "version": f"Version {version}",
        "copyright": "Portsmouth experimental typeface; source provenance in PROJECT.md",
        "licenseDescription": "Experimental build for personal and artistic evaluation; source provenance and licenses are documented with the project.",
    })
    target = engine.target_landmarks
    fb.setupOS2(
        sTypoAscender=850,
        sTypoDescender=-250,
        sTypoLineGap=0,
        usWinAscent=1050,
        usWinDescent=400,
        sxHeight=int(round(target.xheight)),
        sCapHeight=int(round(target.capheight)),
        usWeightClass=400,
        usWidthClass=5,
        fsType=0,
        fsSelection=0x40,
        achVendID="PRTS",
        ulUnicodeRange1=0x00000003,
        ulCodePageRange1=0x00000001,
    )
    fb.setupPost(isFixedPitch=0)
    fb.setupMaxp()
    fb.font["head"].fontRevision = float(version)
    destination = PROJECT / "build" / f"Portsmouth-Regular-{version}.ttf"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fb.save(destination)

    unresolved = [
        cp for cp in GRAPHIC_CODEPOINTS
        if cp not in cmap and all(cp in source.cmap for source in engine.sources)
    ]
    unsupported = [
        cp for cp in GRAPHIC_CODEPOINTS if cp not in cmap and cp not in unresolved
    ]
    report = {
        "font": str(destination.relative_to(PROJECT)),
        "version": version,
        "unitsPerEm": 1000,
        "format": "TrueType glyf",
        "outlineSimplificationTolerance": SIMPLIFICATION_TOLERANCE,
        "iso8859_1": {
            "graphicPositions": len(GRAPHIC_CODEPOINTS),
            "encodedInFont": len(cmap),
            "archivedOutlines": len(archived),
            "spacingCharacters": ["U+0020", "U+00A0"],
            "unresolvedSharedCharacters": [f"U+{cp:04X}" for cp in unresolved],
            "unsupportedByRequiredSources": [f"U+{cp:04X}" for cp in unsupported],
            "controlPositionsNotMapped": 65,
        },
        "productionCoverage": {
            "requestedCodepoints": len(codepoints),
            "encodedCharacters": len(cmap),
            "archivedOutlines": len(archived),
            "extendedCharacters": [f"U+{cp:04X}" for cp in EXTENDED_CODEPOINTS if cp in cmap],
        },
        "glyphCountIncludingNotdef": len(glyph_order),
        "glyphs": glyph_report,
    }
    report_path = PROJECT / "reports" / f"first-ttf-build-{version}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    if version == VERSION:
        (PROJECT / "reports" / "first-ttf-build.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )

    # Reopen eagerly to force table decompilation and basic structural validation.
    font = TTFont(destination, lazy=False, recalcBBoxes=True)
    if font["head"].unitsPerEm != 1000:
        raise ValueError("Built font has an unexpected UPM")
    if not math.isclose(font["head"].fontRevision, float(version), abs_tol=1e-4):
        raise ValueError("Built font has an unexpected revision")
    if len(font.getBestCmap()) != len(cmap):
        raise ValueError("Built cmap does not match requested coverage")
    font.close()
    specimen = PROJECT / "specimens" / f"Portsmouth-Regular-{version}.png"
    render_specimen(destination, specimen, version)
    return destination, specimen, report


def main() -> None:
    historical = [
        ("0.010", MODAL_ACCENTS | {ord("@")}),
        ("0.011", frozenset({ord("@")})),
        ("0.012", frozenset()),
        ("0.013", frozenset()),
        ("0.014", frozenset()),
        ("0.015", frozenset()),
        ("0.016", frozenset()),
        ("0.017", frozenset()),
        ("0.018", frozenset()),
        ("0.019", frozenset()),
        ("0.020", frozenset()),
        ("0.021", frozenset()),
        ("0.022", frozenset()),
        ("0.023", frozenset()),
        ("0.024", frozenset()),
        ("0.025", frozenset()),
    ]
    for version, excluded in historical:
        if not (PROJECT / "build" / f"Portsmouth-Regular-{version}.ttf").exists():
            build(
                version=version,
                excluded_codepoints=excluded,
                codepoints=GRAPHIC_CODEPOINTS,
            )
    font, specimen, report = build()
    print(json.dumps({
        "font": str(font),
        "specimen": str(specimen),
        "glyphCountIncludingNotdef": report["glyphCountIncludingNotdef"],
        **report["iso8859_1"],
    }, indent=2))


if __name__ == "__main__":
    main()
