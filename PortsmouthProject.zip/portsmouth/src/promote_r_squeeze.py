#!/usr/bin/env python3
"""Promote the restrained lowercase-r shoulder squeeze."""

from __future__ import annotations

import json
import shutil

import numpy as np

from build_first_ttf import geometry_for
from build_r_squeeze_candidates import squeeze
from portsmouth_engine import EikonalMidpointEngine, PROJECT


SHOULDER_SCALE = 0.90
SIDEBEARING_REDUCTION = 14.0


def main() -> None:
    geometry = geometry_for(ord("r"))
    report_path = PROJECT / "reports" / "boundary-trace-0072.json"
    baseline_geometry = PROJECT / "geometry" / "boundary-trace-0072-pre-squeeze.npz"
    baseline_report = PROJECT / "reports" / "boundary-trace-0072-pre-squeeze.json"
    if not baseline_geometry.exists():
        shutil.copy2(geometry, baseline_geometry)
    if not baseline_report.exists():
        shutil.copy2(report_path, baseline_report)
    with np.load(baseline_geometry, allow_pickle=False) as archive:
        metadata = {
            key: archive[key]
            for key in archive.files if key in {"character", "unitsPerEm"}
        }
        contours = [
            ("hole" if key.startswith("hole") else "outer", archive[key])
            for key in archive.files if key not in {"character", "unitsPerEm"}
        ]
    transformed, detail = squeeze(contours, SHOULDER_SCALE)
    arrays = {
        f"{role}_{index}": points.astype(np.float32)
        for index, (role, points) in enumerate(transformed)
    }
    arrays.update(metadata)
    np.savez_compressed(geometry, **arrays)
    engine = EikonalMidpointEngine(pixels_per_unit=0.25)
    # Read the routed source metric directly so this promotion remains
    # idempotent after the canonical report begins overriding mean_advance().
    source_advance = float(np.mean([
        source.widths[ord("r")] for source in engine.active_sources("r")
    ]))
    target_advance = (
        source_advance
        - detail["widthReduction"]
        - 2.0 * SIDEBEARING_REDUCTION
    )
    previous = json.loads(baseline_report.read_text())
    previous.update({
        "status": "experimental_promoted_shoulder_squeeze",
        "selectedCandidate": "0.90 shoulder-only",
        "shoulderScale": SHOULDER_SCALE,
        "stemRightAnchor": detail["stemRightAnchor"],
        "sourceInkWidth": detail["sourceInkWidth"],
        "outputInkWidth": detail["outputInkWidth"],
        "widthReduction": detail["widthReduction"],
        "sidebearingReductionPerSide": SIDEBEARING_REDUCTION,
        "targetAdvance": target_advance,
        "baselineGeometry": str(baseline_geometry.relative_to(PROJECT)),
        "baselineReport": str(baseline_report.relative_to(PROJECT)),
        "visualReview": (
            "left stem retained; shoulder reach and internal gap reduced without "
            "changing terminal identity"
        ),
    })
    report_path.write_text(json.dumps(previous, indent=2) + "\n")
    # Composed r-with-mark forms retain the accepted r body and therefore its
    # horizontal metric rather than freezing the pre-correction advance.
    for derived_report in (PROJECT / "reports").glob("multicontour-trace-*.json"):
        derived = json.loads(derived_report.read_text())
        if (
            derived.get("status") == "experimental_promoted_extended_composition"
            and derived.get("baseCharacter") == "r"
        ):
            derived["targetAdvance"] = target_advance
            derived["metricInheritance"] = "corrected lowercase r advance"
            derived_report.write_text(json.dumps(derived, indent=2) + "\n")
    print(json.dumps({key: previous[key] for key in (
        "status", "selectedCandidate", "sourceInkWidth", "outputInkWidth",
        "widthReduction", "sidebearingReductionPerSide", "targetAdvance",
    )}, indent=2))


if __name__ == "__main__":
    main()
