#!/usr/bin/env python3
"""Inventory majority-supported Latin Extended geometry for future fusion."""

from __future__ import annotations

import json
import unicodedata

from build_first_ttf import PRODUCTION_CODEPOINTS, geometry_for
from portsmouth_engine import EikonalMidpointEngine, PROJECT


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    entries = []
    for codepoint in range(0x0100, 0x0250):
        character = chr(codepoint)
        sources = [source for source in engine.sources if codepoint in source.cmap]
        if len(sources) < 3:
            continue
        topologies = {
            source.filename: engine.topology(engine.source_field(source, character).mask)
            for source in sources
        }
        signatures = {(value["components"], value["holes"]) for value in topologies.values()}
        entries.append({
            "codepoint": f"U+{codepoint:04X}",
            "character": character,
            "name": unicodedata.name(character, "UNNAMED"),
            "sourceCount": len(sources),
            "sources": [source.filename for source in sources],
            "topologies": topologies,
            "compatiblePersistentTopology": len(signatures) == 1,
            "production": codepoint in PRODUCTION_CODEPOINTS and geometry_for(codepoint) is not None,
            "geometry": (
                str(geometry_for(codepoint).relative_to(PROJECT))
                if geometry_for(codepoint) is not None else None
            ),
        })
    report = {
        "range": "U+0100..U+024F",
        "minimumSources": 3,
        "productionCharacters": sum(entry["production"] for entry in entries),
        "compatibleCandidates": sum(
            entry["compatiblePersistentTopology"] and not entry["production"]
            for entry in entries
        ),
        "topologyConflicts": sum(
            not entry["compatiblePersistentTopology"] and not entry["production"]
            for entry in entries
        ),
        "policy": (
            "Topology agreement is a screening condition only. New outlines still require "
            "10,240-point equal-source transport and rendered visual acceptance."
        ),
        "entries": entries,
    }
    output = PROJECT / "reports" / "extended-coverage-audit-0.101.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "entries"}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
