#!/usr/bin/env python3
"""Render the final 1/l/I/pipe distinction across every Portsmouth 1.0 face."""

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT


FACES = (
    ("Portsmouth Regular · heavy standalone", PROJECT / "build/Portsmouth-Regular-1.0.ttf"),
    ("Portsmouth · Regular", PROJECT / "build/family/Portsmouth.ttf"),
    ("Portsmouth · Light", PROJECT / "build/family/Portsmouth-Light.ttf"),
    ("Portsmouth · Italic", PROJECT / "build/family/Portsmouth-Italic.ttf"),
    ("Portsmouth · Bold", PROJECT / "build/family/Portsmouth-Bold.ttf"),
    ("Portsmouth · Bold Italic", PROJECT / "build/family/Portsmouth-BoldItalic.ttf"),
    ("Portsmouth Mono · standalone", PROJECT / "build/mono/PortsmouthMono.ttf"),
)


def main() -> None:
    width, row_height = 1700, 230
    canvas = Image.new("RGB", (width, 150 + len(FACES) * row_height), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 38)
    label = ImageFont.truetype(ui, 19)
    draw.text((55, 32), "Portsmouth 1.0 — 1 / l / I / | disambiguation", font=title, fill="#111")
    draw.text((58, 88), "lowercase l has no terminal bars · I and 1 retained · pipe remains full-height", font=label, fill="#5b544b")
    for index, (name, path) in enumerate(FACES):
        y = 135 + index * row_height
        draw.rounded_rectangle((45, y, width - 45, y + row_height - 18), radius=10, fill="#fffdf8", outline="#cbc3b7", width=2)
        draw.text((70, y + 20), name, font=label, fill="#514a42")
        face = ImageFont.truetype(path, 130)
        draw.text((600, y + 28), "1lI|   Il1|   l|Il1", font=face, fill="#141412")
    output = PROJECT / "specimens/Portsmouth-1.0-disambiguation-family.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
