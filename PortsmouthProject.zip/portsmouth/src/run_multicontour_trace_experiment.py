#!/usr/bin/env python3
"""Trace Portsmouth glyphs whose unity contains outer and counter contours."""

from __future__ import annotations

import argparse
import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.optimize import linear_sum_assignment

from boundary_trace import (
    annealed_boundary_barycenter,
    boundary_cloud,
    rasterize_contour,
    rasterize_contour_complex,
)
from medial_transport import (
    MedialMeasure,
    intrinsic_graph_barycenter,
    mask_statistics,
    sample_medial_structure,
)
from outline_geometry import (
    ContourLoop,
    normalized_selected_source_contours,
    normalized_source_contours,
    union_contour_complex,
)
from portsmouth_engine import EikonalMidpointEngine, GlyphField, PROJECT
from transport_barycenter import free_support_barycenter


def _descriptor(loop: ContourLoop) -> np.ndarray:
    return np.array([
        loop.centroid[0] / 500.0,
        loop.centroid[1] / 700.0,
        np.sqrt(loop.area) / 500.0,
    ])


def pair_loops(complexes, role: str) -> list[list[ContourLoop]]:
    sources = [
        [loop for loop in complex_.loops if loop.role == role]
        for complex_ in complexes
    ]
    counts = {len(value) for value in sources}
    if len(counts) != 1:
        raise ValueError(f"Sources disagree on {role} contour count: {sorted(counts)}")
    count = len(sources[0])
    if count == 0:
        return []
    reference = sorted(sources[0], key=lambda loop: (loop.centroid[1], loop.centroid[0]))
    aligned = [reference]
    reference_descriptor = np.asarray([_descriptor(loop) for loop in reference])
    for loops in sources[1:]:
        descriptors = np.asarray([_descriptor(loop) for loop in loops])
        cost = np.sum(
            (reference_descriptor[:, None, :] - descriptors[None, :, :]) ** 2,
            axis=2,
        )
        rows, columns = linear_sum_assignment(cost)
        ordered = [None] * count
        for row, column in zip(rows, columns):
            ordered[int(row)] = loops[int(column)]
        aligned.append(ordered)
    return [[aligned[source][index] for source in range(len(aligned))] for index in range(count)]


def retain_persistent_loops(complex_, expected: dict) -> tuple[object, list[dict]]:
    """Match analytic loops to topology that persists at the normalized work scale."""
    retained = []
    discarded = []
    for role, key in (("outer", "components"), ("hole", "holes")):
        loops = sorted(
            (loop for loop in complex_.loops if loop.role == role),
            key=lambda loop: loop.area,
            reverse=True,
        )
        count = int(expected[key])
        if len(loops) < count:
            raise ValueError(
                f"Analytic extraction found {len(loops)} persistent candidates "
                f"for {count} expected {role} loops"
            )
        retained.extend(loops[:count])
        discarded.extend({"role": role, "area": float(loop.area)} for loop in loops[count:])
    return type(complex_)(loops=retained), discarded


def _contains_point(points: np.ndarray, point: np.ndarray) -> bool:
    """Even-odd containment for one closed contour."""
    x, y = map(float, point)
    x0, y0 = points[:, 0], points[:, 1]
    x1, y1 = np.roll(x0, -1), np.roll(y0, -1)
    crosses = ((y0 > y) != (y1 > y)) & (
        x < (x1 - x0) * (y - y0) / np.where(np.abs(y1 - y0) > 1e-12, y1 - y0, 1.0) + x0
    )
    return bool(np.count_nonzero(crosses) % 2)


def hole_owner_indices(outer_groups, hole_groups) -> list[int]:
    """Assign every paired counter to the same paired containing body."""
    owners = []
    for hole_group in hole_groups:
        source_owners = []
        for source_index, hole in enumerate(hole_group):
            candidates = [
                (outer_group[source_index].area, outer_index)
                for outer_index, outer_group in enumerate(outer_groups)
                if _contains_point(outer_group[source_index].points, hole.centroid)
            ]
            if not candidates:
                raise ValueError("Counter is not contained by any paired outer body")
            source_owners.append(min(candidates)[1])
        if any(owner != source_owners[0] for owner in source_owners[1:]):
            raise ValueError(f"Sources disagree on counter ownership: {source_owners}")
        owners.append(source_owners[0])
    return owners


def component_fields(engine, fields, outer_group, hole_groups=()) -> list[GlyphField]:
    """Make a connected field for one paired body and its owned counters."""
    result = []
    for source_index, (field, outer) in enumerate(zip(fields, outer_group)):
        contours = [("outer", outer.points)] + [
            ("hole", holes[source_index].points) for holes in hole_groups
        ]
        mask = rasterize_contour_complex(engine, contours)
        result.append(GlyphField(
            source=field.source,
            character=field.character,
            mask=mask,
            sdf=engine.signed_distance(mask),
            advance=field.advance,
            bounds=field.bounds,
        ))
    return result


def medial_basis(engine, fields):
    """Use the densest common connected medial sampling supported by a body."""
    last_error = None
    for count in (128, 96, 64, 48, 32, 24, 16, 12, 8, 6, 4, 3, 2, 1):
        try:
            if count == 1:
                measures = [singleton_medial_measure(engine, field) for field in fields]
            else:
                measures = [sample_medial_structure(engine, field, count) for field in fields]
            initial = free_support_barycenter(
                [measure.support for measure in measures],
                [measure.mass for measure in measures],
                scale=np.array([500.0, 500.0, 60.0]),
            )
            median, info = intrinsic_graph_barycenter(measures, initial)
            info["samples"] = count
            return measures, median, info
        except ValueError as error:
            last_error = error
    raise ValueError(f"No common connected medial basis: {last_error}")


def singleton_medial_measure(engine, field) -> MedialMeasure:
    """One maximal-inscribed attractor for a sub-pixel-thin contour body."""
    if not np.any(field.mask):
        raise ValueError(f"{field.source.filename} component raster is empty")
    masked = np.where(field.mask, field.sdf, np.inf)
    row, column = np.unravel_index(int(np.argmin(masked)), masked.shape)
    x = engine.x_min + (column + 0.5) / engine.pixels_per_unit
    y = engine.y_max - (row + 0.5) / engine.pixels_per_unit
    radius = max(float(-field.sdf[row, column]), 0.5 / engine.pixels_per_unit)
    return MedialMeasure(
        support=np.asarray([[x, y, radius]], dtype=np.float64),
        mass=np.ones(1, dtype=np.float64),
        geodesic=np.zeros((1, 1), dtype=np.float64),
    )


def _render_mask(mask: np.ndarray, maximum: tuple[int, int]) -> Image.Image:
    ys, xs = np.nonzero(mask)
    left, right = max(0, xs.min() - 12), min(mask.shape[1], xs.max() + 13)
    top, bottom = max(0, ys.min() - 12), min(mask.shape[0], ys.max() + 13)
    crop = mask[top:bottom, left:right]
    layer = np.full((*crop.shape, 3), 255, dtype=np.uint8)
    layer[crop] = (24, 24, 22)
    image = Image.fromarray(layer)
    image.thumbnail(maximum, Image.Resampling.LANCZOS)
    return image


def run_character(
    engine,
    character: str,
    points_per_contour: int,
    *,
    couple_clearance: bool = False,
    selected_sources=None,
    output_prefix: str | None = None,
    status_override: str | None = None,
    source_selection_policy: str | None = None,
) -> None:
    sources = selected_sources or engine.active_sources(character)
    fields = [engine.source_field(source, character) for source in sources]
    raw = (
        normalized_selected_source_contours(engine, character, sources)
        if selected_sources is not None
        else normalized_source_contours(engine, character)
    )
    extracted_complexes = [
        union_contour_complex(raw[field.source.filename], pixels_per_unit=5.0)
        for field in fields
    ]
    persistent_topologies = [engine.topology(field.mask) for field in fields]
    if any(value != persistent_topologies[0] for value in persistent_topologies[1:]):
        raise ValueError(f"Sources disagree at persistent topology scale: {persistent_topologies}")
    persistent_topology = persistent_topologies[0]
    filtered = [
        retain_persistent_loops(complex_, persistent_topology)
        for complex_ in extracted_complexes
    ]
    complexes = [value[0] for value in filtered]
    discarded_loops = [value[1] for value in filtered]
    tops = [
        max(float(np.max(loop.points[:, 1])) for loop in complex_.outer)
        for complex_ in complexes
    ]
    target_top = float(np.median(tops))
    for complex_, top in zip(complexes, tops):
        scale = target_top / top
        for loop in complex_.loops:
            loop.points[:, 1] *= scale
            loop.centroid[1] *= scale
            loop.area *= scale

    outer_groups = pair_loops(complexes, "outer")
    hole_groups = pair_loops(complexes, "hole")
    owners = hole_owner_indices(outer_groups, hole_groups)
    owned_holes = [
        [group for group, owner in zip(hole_groups, owners) if owner == outer_index]
        for outer_index in range(len(outer_groups))
    ]
    body_fields = [
        component_fields(engine, fields, outer_group, owned_holes[outer_index])
        for outer_index, outer_group in enumerate(outer_groups)
    ]
    groups = [
        ("outer", group, outer_index, None)
        for outer_index, group in enumerate(outer_groups)
    ]
    groups += [
        (
            "hole",
            group,
            owner,
            outer_groups[owner] if couple_clearance else None,
        )
        for group, owner in zip(hole_groups, owners)
    ]
    output_contours = []
    contour_reports = []
    for role, group, owner, relation_group in groups:
        if persistent_topology["components"] > 1 or selected_sources is not None:
            basis_fields = body_fields[owner]
        else:
            basis_fields = fields
        measures, median, median_info = medial_basis(engine, basis_fields)
        clouds = [
            boundary_cloud(
                engine, field, measure, median, plan,
                count=points_per_contour,
                source_contour=loop.points,
                relation_contour=(
                    relation.points if relation_group is not None else None
                ),
            )
            for field, measure, plan, loop, relation in zip(
                basis_fields,
                measures,
                median.plans,
                group,
                relation_group if relation_group is not None else [None] * len(group),
            )
        ]
        contour, annealing = annealed_boundary_barycenter(clouds)
        output_contours.append((role, contour))
        contour_reports.append({
            "role": role,
            "ownerOuter": owner,
            "points": points_per_contour,
            "medianSkeleton": median_info,
            "annealing": annealing,
        })
    mask = rasterize_contour_complex(engine, output_contours)
    expected = {
        "components": len(complexes[0].outer),
        "holes": len(complexes[0].holes),
    }
    actual = engine.topology(mask)
    review_notes = {
        "a": "upper-left aperture transition needs optical curve review",
        "ā": "inherits the unresolved lowercase a aperture transition",
        "ä": "inherits the unresolved lowercase a aperture transition",
        "æ": "internal a/e junction is over-compressed and needs optical review",
        "Ġ": "inherits the uppercase G lower-right bar and bowl junction",
        "j": "shoulder and tittle proportion need optical review",
        "Q": "tail and counter must be coupled; independent traces form an optical notch",
        "q": "user identified the bowl-to-descender construction for redraw",
        "Ŵ": "inherits the uppercase W central junction review",
        "ŵ": "inherits the lowercase w central junction review",
    }
    review_note = review_notes.get(character)
    if character == "Q" and couple_clearance:
        review_note = "continuous clearance coupling did not materially repair the tail/counter notch"
    if actual != expected:
        status = "rejected_topology_mismatch"
    elif character in review_notes:
        status = "needs_design_review"
    elif selected_sources is not None:
        status = "experimental_majority_source_trace"
    else:
        status = "experimental_multicontour_trace"
    if status_override is not None and actual == expected:
        status = status_override
    experiment_prefix = output_prefix or (
        "multicontour-coupled" if couple_clearance else "multicontour-trace"
    )
    stem = f"{ord(character):04x}"
    pipeline = [
        "nonzero_winding_source_unity",
        "working_scale_contour_persistence",
        "equal_source_cyclic_phase_synchronization",
        "role_and_descriptor_contour_pairing",
    ]
    if selected_sources is not None:
        pipeline.insert(0, "explicit_at_least_three_of_five_source_selection")
    if couple_clearance:
        pipeline.append("experimental_outer_counter_clearance_signature_coupling")
    pipeline += [
        "median_skeleton_anchored_monotone_transport_per_contour",
        "equal_weight_multicontour_trace",
    ]
    report = {
        "character": character,
        "status": status,
        "pipeline": pipeline,
        "experimentalClearanceCoupling": couple_clearance,
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 1.0 / len(fields),
        "sourceSelectionPolicy": (
            source_selection_policy
            or (
                "all fonts encoding the character, minimum three of five"
                if selected_sources is not None else "case-routed project default"
            )
        ),
        "pointsPerSourceContour": points_per_contour,
        "sourceBoundaryExtractionPixelsPerUnit": 5.0,
        "exactTargetInkTop": target_top,
        "sourceTopology": {
            field.source.filename: {
                "components": len(complex_.outer),
                "holes": len(complex_.holes),
                "discardedAnalyticLoops": discarded,
            }
            for field, complex_, discarded in zip(fields, complexes, discarded_loops)
        },
        "expectedTopology": expected,
        "outputTopology": actual,
        "visualReview": review_note,
        "medianSkeleton": [value["medianSkeleton"] for value in contour_reports],
        "contours": contour_reports,
        "geometry": mask_statistics(mask),
        "skeletonInflationUsed": False,
        "densityFloodUsed": False,
    }
    geometry_directory = PROJECT / "geometry"
    geometry_directory.mkdir(exist_ok=True)
    geometry_output = geometry_directory / f"{experiment_prefix}-{stem}.npz"
    geometry_arrays = {
        f"{role}_{index}": contour.astype(np.float32)
        for index, (role, contour) in enumerate(output_contours)
    }
    geometry_arrays["character"] = np.asarray(character)
    geometry_arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(geometry_output, **geometry_arrays)
    report["geometryArtifact"] = str(geometry_output.relative_to(PROJECT))
    (PROJECT / "reports" / f"{experiment_prefix}-{stem}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )

    entries = [(field.source.family, field.mask) for field in fields]
    entries.append(("Portsmouth contour unity", mask))
    tile_w, tile_h, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 150 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 14)
    draw.text((40, 28), f"Portsmouth {character} — multi-contour unity", fill="#111", font=title)
    draw.text(
        (40, 78),
        f"{points_per_contour:,} points/contour/source · contour bodies transported independently",
        fill="#575149", font=small,
    )
    for index, (name, source_mask) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10,
            fill="#fffdf8", outline="#d0cabf", width=2,
        )
        glyph = _render_mask(source_mask, (tile_w - 70, tile_h - 105))
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 63 + (tile_h - 105 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        subtitle = str(actual) if index == len(entries) - 1 else "height-normalized source"
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    output = PROJECT / "specimens" / f"{experiment_prefix}-{stem}.png"
    canvas.save(output)
    print(json.dumps({key: value for key, value in report.items() if key != "contours"}, indent=2))
    print(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("glyphs", nargs="*", default=list("aeopbdgqij"))
    parser.add_argument("--points", type=int, default=10240)
    parser.add_argument("--couple-clearance", action="store_true")
    parser.add_argument("--majority", action="store_true")
    arguments = parser.parse_args()
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    for character in arguments.glyphs:
        selected = None
        if arguments.majority:
            selected = [
                source for source in engine.sources if ord(character) in source.cmap
            ]
            if len(selected) < 3:
                raise ValueError(f"{character!r} is encoded by fewer than three sources")
        run_character(
            engine,
            character,
            arguments.points,
            couple_clearance=arguments.couple_clearance,
            selected_sources=selected,
        )


if __name__ == "__main__":
    main()
