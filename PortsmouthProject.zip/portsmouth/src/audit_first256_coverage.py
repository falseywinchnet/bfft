#!/usr/bin/env python3
"""Audit Portsmouth coverage among shared encoded codepoints below U+0100."""

from __future__ import annotations

import json
import unicodedata

from portsmouth_engine import EikonalMidpointEngine, PROJECT


def geometry_for(codepoint: int):
    stem = f"{codepoint:04x}"
    for prefix in ("boundary-trace", "multicontour-trace"):
        path = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        if path.exists():
            report_path = PROJECT / "reports" / f"{prefix}-{stem}.json"
            if report_path.exists():
                status = json.loads(report_path.read_text()).get("status", "")
                if status.startswith("rejected"):
                    continue
            return prefix, path
    return None, None


def audit() -> dict:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    shared = sorted(
        codepoint
        for codepoint in set.intersection(*(set(source.cmap) for source in engine.sources))
        if codepoint < 256
    )
    archived, conflicts, empty, compatible_missing = [], [], [], []
    for codepoint in shared:
        character = chr(codepoint)
        prefix, geometry_path = geometry_for(codepoint)
        entry = {
            "character": character,
            "codepoint": f"U+{codepoint:04X}",
            "name": unicodedata.name(character, "UNKNOWN"),
            "category": unicodedata.category(character),
        }
        try:
            fields = [
                engine.source_field(source, character)
                for source in engine.active_sources(character)
            ]
        except KeyError:
            entry["reason"] = "encoded spacing glyph without ink bounds"
            empty.append(entry)
            continue
        topologies = {
            field.source.filename: engine.topology(field.mask) for field in fields
        }
        values = list(topologies.values())
        consensus = all(value == values[0] for value in values[1:])
        entry["sourceTopology"] = topologies
        entry["sourceTopologyConsensus"] = consensus
        if geometry_path is not None:
            report_path = PROJECT / "reports" / f"{prefix}-{codepoint:04x}.json"
            report = json.loads(report_path.read_text())
            entry.update({
                "geometry": str(geometry_path.relative_to(PROJECT)),
                "report": str(report_path.relative_to(PROJECT)),
                "status": report["status"],
                "designConstraint": report.get("designConstraint"),
            })
            archived.append(entry)
        elif consensus:
            compatible_missing.append(entry)
        else:
            conflicts.append(entry)
    return {
        "range": "U+0000..U+00FF",
        "sharedEncodedCount": len(shared),
        "archivedCount": len(archived),
        "spacingWithoutOutlineCount": len(empty),
        "unresolvedTopologyConflictCount": len(conflicts),
        "topologyCompatibleMissingCount": len(compatible_missing),
        "archived": archived,
        "spacingWithoutOutline": empty,
        "unresolvedTopologyConflicts": conflicts,
        "topologyCompatibleMissing": compatible_missing,
    }


def main() -> None:
    report = audit()
    output = PROJECT / "reports" / "first256-coverage-audit.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if not isinstance(value, list)}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
