#!/usr/bin/env python3
"""Eikonal medial atoms and geometric-basis diffusion for Portsmouth."""

from __future__ import annotations

import numpy as np
from scipy import ndimage
from scipy.optimize import linear_sum_assignment
from scipy.sparse import coo_matrix, eye
from scipy.sparse.csgraph import laplacian as graph_laplacian
from scipy.sparse.csgraph import dijkstra
from scipy.sparse.linalg import eigsh, spsolve
from scipy.spatial import cKDTree

from portsmouth_engine import EikonalMidpointEngine, GlyphField
from shock_graph import extract
from transport_barycenter import TransportBarycenter


class MedialMeasure:
    def __init__(self, support: np.ndarray, mass: np.ndarray, geodesic: np.ndarray):
        self.support = support
        self.mass = mass
        self.geodesic = geodesic


def _diffusion_coordinates(skeleton: np.ndarray, modes: int = 3) -> np.ndarray:
    """Lowest nonconstant modes of the unsegmented medial-pixel graph."""
    rows, columns = np.nonzero(skeleton)
    count = len(rows)
    lookup = np.full(skeleton.shape, -1, dtype=np.int32)
    lookup[rows, columns] = np.arange(count)
    edge_rows: list[int] = []
    edge_columns: list[int] = []
    weights: list[float] = []
    for dy, dx, weight in (
        (0, 1, 1.0), (1, 0, 1.0), (1, 1, 2 ** -0.5), (1, -1, 2 ** -0.5)
    ):
        target_rows = rows + dy
        target_columns = columns + dx
        valid = (
            (target_rows >= 0) & (target_rows < skeleton.shape[0])
            & (target_columns >= 0) & (target_columns < skeleton.shape[1])
        )
        source_index = np.flatnonzero(valid)
        target_index = lookup[target_rows[valid], target_columns[valid]]
        present = target_index >= 0
        for first, second in zip(source_index[present], target_index[present]):
            edge_rows.extend((int(first), int(second)))
            edge_columns.extend((int(second), int(first)))
            weights.extend((weight, weight))
    adjacency = coo_matrix(
        (weights, (edge_rows, edge_columns)), shape=(count, count)
    ).tocsr()
    operator = graph_laplacian(adjacency, normed=True)
    _, vectors = eigsh(operator, k=modes + 1, which="SM", tol=1e-7)
    coordinates = vectors[:, 1 : modes + 1] * np.sqrt(count)
    x = columns.astype(np.float64)
    y = -rows.astype(np.float64)
    for index in range(modes):
        vector = coordinates[:, index]
        cx = float(np.dot(vector, x - np.mean(x)))
        cy = float(np.dot(vector, y - np.mean(y)))
        reference = cx if abs(cx) >= abs(cy) else cy
        if reference < 0.0:
            coordinates[:, index] *= -1.0
    return coordinates


def sample_medial_measure(
    engine: EikonalMidpointEngine,
    field: GlyphField,
    count: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Deterministically sample reconstructive ``(x, y, radius)`` atoms.

    Farthest-point sampling is performed in normalized position/radius space.
    It is deliberately not a segmentation: every atom is simply a maximal-disk
    sample of the glyph's Eikonal shock set.
    """
    graph = extract(field.mask, pixels_per_unit=engine.pixels_per_unit)
    rows, columns = np.nonzero(graph.skeleton)
    if len(rows) < count:
        raise ValueError(f"{field.source.filename} has only {len(rows)} medial samples")
    x = engine.x_min + (columns + 0.5) / engine.pixels_per_unit
    y = engine.y_max - (rows + 0.5) / engine.pixels_per_unit
    radius = graph.radius[rows, columns]
    atoms = np.column_stack((x, y, radius)).astype(np.float64)
    feature = atoms / np.array([500.0, 500.0, 60.0])

    # Begin at the leftmost high-radius atom, then cover the feature cloud.
    left_band = np.flatnonzero(x <= np.quantile(x, 0.05))
    first = int(left_band[np.argmax(radius[left_band])])
    chosen = np.empty(count, dtype=np.int64)
    chosen[0] = first
    nearest2 = np.sum((feature - feature[first]) ** 2, axis=1)
    nearest2[first] = -1.0
    for index in range(1, count):
        selected = int(np.argmax(nearest2))
        chosen[index] = selected
        distance2 = np.sum((feature - feature[selected]) ** 2, axis=1)
        nearest2 = np.minimum(nearest2, distance2)
        nearest2[chosen[: index + 1]] = -1.0
    support = atoms[chosen]
    mass = np.full(count, 1.0 / count, dtype=np.float64)
    return support, mass


def sample_medial_structure(
    engine: EikonalMidpointEngine,
    field: GlyphField,
    count: int,
) -> MedialMeasure:
    """Sample medial atoms together with gauge-invariant graph distances."""
    graph = extract(field.mask, pixels_per_unit=engine.pixels_per_unit)
    rows, columns = np.nonzero(graph.skeleton)
    x = engine.x_min + (columns + 0.5) / engine.pixels_per_unit
    y = engine.y_max - (rows + 0.5) / engine.pixels_per_unit
    radius = graph.radius[rows, columns]
    atoms = np.column_stack((x, y, radius)).astype(np.float64)
    feature = atoms / np.array([500.0, 500.0, 60.0])
    if len(atoms) < count:
        raise ValueError(f"{field.source.filename} has only {len(atoms)} medial samples")
    left_band = np.flatnonzero(x <= np.quantile(x, 0.05))
    chosen = np.empty(count, dtype=np.int64)
    chosen[0] = int(left_band[np.argmax(radius[left_band])])
    nearest2 = np.sum((feature - feature[chosen[0]]) ** 2, axis=1)
    nearest2[chosen[0]] = -1.0
    for index in range(1, count):
        chosen[index] = int(np.argmax(nearest2))
        distance2 = np.sum((feature - feature[chosen[index]]) ** 2, axis=1)
        nearest2 = np.minimum(nearest2, distance2)
        nearest2[chosen[: index + 1]] = -1.0

    lookup = np.full(graph.skeleton.shape, -1, dtype=np.int32)
    lookup[rows, columns] = np.arange(len(rows))
    edge_rows: list[int] = []
    edge_columns: list[int] = []
    weights: list[float] = []
    for dy, dx, weight in (
        (0, 1, 1.0), (1, 0, 1.0), (1, 1, 2 ** 0.5), (1, -1, 2 ** 0.5)
    ):
        tr, tc = rows + dy, columns + dx
        valid = (tr >= 0) & (tr < graph.skeleton.shape[0]) & (tc >= 0) & (tc < graph.skeleton.shape[1])
        source_index = np.flatnonzero(valid)
        target_index = lookup[tr[valid], tc[valid]]
        present = target_index >= 0
        for first, second in zip(source_index[present], target_index[present]):
            edge_rows.extend((int(first), int(second)))
            edge_columns.extend((int(second), int(first)))
            weights.extend((weight, weight))
    adjacency = coo_matrix(
        (weights, (edge_rows, edge_columns)), shape=(len(rows), len(rows))
    ).tocsr()
    geodesic = dijkstra(adjacency, indices=chosen)[:, chosen]
    geodesic /= engine.pixels_per_unit
    if not np.all(np.isfinite(geodesic)):
        raise ValueError(f"{field.source.filename} medial graph is disconnected")
    return MedialMeasure(
        support=atoms[chosen],
        mass=np.full(count, 1.0 / count, dtype=np.float64),
        geodesic=geodesic,
    )


def intrinsic_graph_barycenter(
    measures: list[MedialMeasure],
    initial: TransportBarycenter,
    *,
    iterations: int = 12,
    structure_scale: float = 500.0,
    frame_weight: float = 0.18,
) -> tuple[TransportBarycenter, dict]:
    """Hard metric-graph barycenter with an explicit normalized-frame gauge."""
    count = len(initial.support)
    permutations = [np.argmax(plan, axis=1) for plan in initial.plans]
    support = initial.support[:, :3].copy()
    changes = []
    for iteration in range(1, iterations + 1):
        aligned_distances = np.asarray([
            measure.geodesic[np.ix_(permutation, permutation)]
            for measure, permutation in zip(measures, permutations)
        ])
        basis = np.mean(aligned_distances, axis=0)
        updated_permutations = []
        changed = 0
        for measure, old in zip(measures, permutations):
            # Candidate j is judged by its complete intrinsic-distance row
            # against the current barycenter row i under the other current
            # correspondences.  This is a hard GW-style linearization.
            source_rows = measure.geodesic[:, old]
            structural = np.mean(
                (basis[:, None, :] - source_rows[None, :, :]) ** 2,
                axis=2,
            ) / (structure_scale ** 2)
            delta = support[:, None, :] - measure.support[None, :, :]
            frame = np.sum(
                (delta / np.array([500.0, 500.0, 60.0])) ** 2,
                axis=2,
            )
            rows_assignment, columns_assignment = linear_sum_assignment(
                structural + frame_weight * frame
            )
            permutation = np.empty(count, dtype=np.int64)
            permutation[rows_assignment] = columns_assignment
            changed += int(np.count_nonzero(permutation != old))
            updated_permutations.append(permutation)
        permutations = updated_permutations
        support = np.mean(np.asarray([
            measure.support[permutation]
            for measure, permutation in zip(measures, permutations)
        ]), axis=0)
        changes.append(changed)
        if changed == 0:
            break
    plans = []
    objective = 0.0
    mass = np.full(count, 1.0 / count)
    aligned_distances = []
    for measure, permutation in zip(measures, permutations):
        plan = np.zeros((count, count), dtype=np.float64)
        plan[np.arange(count), permutation] = mass
        plans.append(plan)
        aligned_distances.append(measure.geodesic[np.ix_(permutation, permutation)])
    basis = np.mean(aligned_distances, axis=0)
    for distance in aligned_distances:
        objective += float(np.mean((distance - basis) ** 2)) / len(measures)
    result = TransportBarycenter(
        support=support,
        support_mass=mass,
        source_supports=[measure.support for measure in measures],
        source_masses=[measure.mass for measure in measures],
        plans=plans,
        objective=objective,
        iterations=iteration,
        initialization=initial.initialization,
    )
    return result, {
        "operator": "hard_intrinsic_graph_transport_barycenter",
        "iterations": iteration,
        "assignmentChanges": changes,
        "structureScale": structure_scale,
        "frameWeight": frame_weight,
        "intrinsicObjective": objective,
    }


def disk_envelope(
    engine: EikonalMidpointEngine,
    atoms: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Build each medial disk, then merge disks by their Eikonal envelope."""
    envelope = np.full((engine.height, engine.width), -np.inf, dtype=np.float32)
    ppu = engine.pixels_per_unit
    for atom in atoms:
        x, y, radius = atom[:3]
        radius = max(float(radius), 0.5 / ppu)
        column = (x - engine.x_min) * ppu - 0.5
        row = (engine.y_max - y) * ppu - 0.5
        pixel_radius = radius * ppu
        c0 = max(0, int(np.floor(column - pixel_radius - 1)))
        c1 = min(engine.width, int(np.ceil(column + pixel_radius + 2)))
        r0 = max(0, int(np.floor(row - pixel_radius - 1)))
        r1 = min(engine.height, int(np.ceil(row + pixel_radius + 2)))
        yy, xx = np.ogrid[r0:r1, c0:c1]
        distance = np.hypot(xx - column, yy - row) / ppu
        envelope[r0:r1, c0:c1] = np.maximum(
            envelope[r0:r1, c0:c1], radius - distance
        )
    return envelope, envelope >= 0.0


def diffusive_geometric_basis(
    result: TransportBarycenter,
    *,
    neighbors: int = 5,
    anchor: float = 0.12,
) -> tuple[np.ndarray, dict]:
    """Solve a connection-style local-geometry barycenter.

    Transport plans first place every source atom in the barycenter's common
    indexing.  Each graph edge then takes the equal-weight mean of source
    length and circular direction separately.  A graph-Laplacian equilibrium
    integrates those local relations while a weak anchor fixes translation,
    scale, and the already-normalized font frame.
    """
    mass = result.support_mass
    aligned = np.asarray([
        (plan @ source) / mass[:, None]
        for plan, source in zip(result.plans, result.source_supports)
    ])[:, :, :3]
    initial = np.mean(aligned, axis=0)
    count = len(initial)
    tree = cKDTree(initial[:, :2] / np.array([500.0, 500.0]))
    _, indices = tree.query(
        initial[:, :2] / np.array([500.0, 500.0]),
        k=min(neighbors + 1, count),
    )
    edges = sorted({
        (min(i, int(j)), max(i, int(j)))
        for i in range(count)
        for j in np.atleast_1d(indices[i])[1:]
        if i != int(j)
    })
    edge_count = len(edges)
    rows = np.repeat(np.arange(edge_count), 2)
    columns = np.asarray([value for edge in edges for value in edge])
    values = np.tile(np.array([-1.0, 1.0]), edge_count)
    incidence = coo_matrix(
        (values, (rows, columns)), shape=(edge_count, count)
    ).tocsr()

    desired = np.zeros((edge_count, 3), dtype=np.float64)
    reliability = np.ones(edge_count, dtype=np.float64)
    for edge_index, (first, second) in enumerate(edges):
        vectors = aligned[:, second, :2] - aligned[:, first, :2]
        lengths = np.linalg.norm(vectors, axis=1)
        units = vectors / np.maximum(lengths[:, None], 1e-9)
        direction = np.sum(units, axis=0)
        coherence = np.linalg.norm(direction) / len(units)
        if np.linalg.norm(direction) <= 1e-9:
            direction = initial[second, :2] - initial[first, :2]
        direction /= max(np.linalg.norm(direction), 1e-9)
        desired[edge_index, :2] = direction * np.mean(lengths)
        desired[edge_index, 2] = np.mean(
            aligned[:, second, 2] - aligned[:, first, 2]
        )
        reliability[edge_index] = max(coherence, 0.15)

    weighted = incidence.multiply(reliability[:, None])
    laplacian = incidence.T @ weighted
    system = laplacian + anchor * eye(count, format="csr")
    solved = np.empty_like(initial)
    for dimension in range(3):
        right = incidence.T @ (reliability * desired[:, dimension])
        right += anchor * initial[:, dimension]
        solved[:, dimension] = spsolve(system, right)
    solved[:, 2] = np.maximum(solved[:, 2], 1.0)
    residual = incidence @ solved - desired
    return solved, {
        "operator": "euclidean_connection_basis_diffusion",
        "sources": int(len(aligned)),
        "nodes": int(count),
        "edges": int(edge_count),
        "anchor": float(anchor),
        "meanDirectionCoherence": float(np.mean(reliability)),
        "rmsRelationResidual": float(np.sqrt(np.mean(residual ** 2))),
        "displacementFromDirectBarycenter": float(np.sqrt(np.mean(
            np.sum((solved[:, :2] - initial[:, :2]) ** 2, axis=1)
        ))),
    }


def mask_statistics(mask: np.ndarray) -> dict[str, int]:
    labels, components = ndimage.label(mask)
    del labels
    return {
        "areaPixels": int(np.count_nonzero(mask)),
        "components": int(components),
    }
