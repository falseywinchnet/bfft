#!/usr/bin/env python3
"""Render Courier New, Portsmouth Regular, and Portsmouth Light together."""

from __future__ import annotations

import json

from PIL import Image, ImageDraw, ImageFont

from audit_light_reference import COURIER_NEW, font_for_cap_height
from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import PROJECT


def fit_text(draw, path, text: str, cap_height: int, maximum_width: int):
    while cap_height > 16:
        font = font_for_cap_height(path, cap_height)
        bounds = draw.textbbox((0, 0), text, font=font)
        if bounds[2] - bounds[0] <= maximum_width:
            return font
        cap_height -= 2
    return font_for_cap_height(path, cap_height)


def main() -> None:
    report = json.loads(
        (PROJECT / "reports" / f"light-reference-audit-{FAMILY_VERSION}.json").read_text()
    )
    rows = (
        ("COURIER NEW REGULAR / REFERENCE", COURIER_NEW, "courierNewRegular"),
        ("PORTSMOUTH REGULAR", PROJECT / "build" / "family" / "Portsmouth.ttf", "portsmouthRegular"),
        ("PORTSMOUTH LIGHT / EIKONAL −18.5", PROJECT / "build" / "family" / "Portsmouth-Light.ttf", "portsmouthLight"),
    )
    canvas = Image.new("RGB", (2200, 1080), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 42)
    label = ImageFont.truetype(ui, 17)
    draw.text((55, 30), "Portsmouth Light — reference weight", fill="#171715", font=title)
    draw.text(
        (58, 86),
        "Matched cap height · median upright stems measured across H I N E M",
        fill="#5d574e",
        font=label,
    )
    y = 130
    for name, path, key in rows:
        width = report["stemWidthsPixels"][key]
        draw.text((58, y), f"{name}  ·  {width:g}px / 700px cap", fill="#985848", font=label)
        display = fit_text(draw, path, "HINEM  minimum rhythm", 72, 2085)
        body = fit_text(
            draw, path,
            "A quiet courier carries Portsmouth through readable pages.",
            30, 2085,
        )
        draw.text((55, y + 30), "HINEM  minimum rhythm", fill="#171715", font=display)
        draw.text((58, y + 165), "A quiet courier carries Portsmouth through readable pages.", fill="#292724", font=body)
        draw.line((55, y + 235, 2145, y + 235), fill="#c8c0b4", width=2)
        y += 285
    output = PROJECT / "specimens" / f"Portsmouth-Light-{FAMILY_VERSION}-comparison.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
