#!/usr/bin/env python3
"""Build the first Portsmouth Eikonal midpoint studies and diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from portsmouth_engine import EikonalMidpointEngine, PROJECT, render_midpoint_study


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("glyphs", nargs="*", default=["M", "m"])
    parser.add_argument("--pixels-per-unit", type=float, default=1.0)
    args = parser.parse_args()
    engine = EikonalMidpointEngine(pixels_per_unit=args.pixels_per_unit)
    engine.write_engine_report(PROJECT / "reports" / "engine-normalization.json")
    for character in args.glyphs:
        if len(character) != 1:
            raise SystemExit(f"Expected one character, got {character!r}")
        result = engine.midpoint(character)
        stem = f"{ord(character):04x}"
        render_midpoint_study(
            result, PROJECT / "specimens" / f"midpoint-{stem}.png"
        )
        report = PROJECT / "reports" / f"midpoint-{stem}.json"
        report.write_text(json.dumps(result.diagnostics, indent=2) + "\n")
        print(
            character,
            "sources=", len(result.sources),
            "topology=", result.diagnostics["midpointTopology"],
            "flags=", [
                name for name, value in result.diagnostics["dominance"].items()
                if value["flag"]
            ],
        )


if __name__ == "__main__":
    main()

