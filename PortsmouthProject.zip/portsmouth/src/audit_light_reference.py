#!/usr/bin/env python3
"""Compare Portsmouth Light stem weight with the Courier New reference."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION, LIGHT_TARGET_RADIUS
from portsmouth_engine import PROJECT


COURIER_NEW = Path("/System/Library/Fonts/Supplemental/Courier New.ttf")
CAP_PIXELS = 700
PROBE_GLYPHS = "HINEM"


def font_for_cap_height(path: Path, target: int) -> ImageFont.FreeTypeFont:
    probe = ImageFont.truetype(path, 1000)
    bounds = probe.getbbox("H")
    measured = max(1, bounds[3] - bounds[1])
    return ImageFont.truetype(path, round(1000 * target / measured))


def glyph_mask(path: Path, character: str) -> np.ndarray:
    font = font_for_cap_height(path, CAP_PIXELS)
    bounds = font.getbbox(character)
    width, height = bounds[2] - bounds[0], bounds[3] - bounds[1]
    image = Image.new("L", (width + 40, height + 40), 0)
    ImageDraw.Draw(image).text(
        (20 - bounds[0], 20 - bounds[1]), character, font=font, fill=255
    )
    mask = np.asarray(image) >= 128
    rows, columns = np.nonzero(mask)
    return mask[rows.min():rows.max() + 1, columns.min():columns.max() + 1]


def run_lengths(row: np.ndarray) -> np.ndarray:
    padded = np.concatenate(([False], row, [False])).astype(np.int8)
    changes = np.diff(padded)
    return np.where(changes == -1)[0] - np.where(changes == 1)[0]


def median_upright_stem(path: Path) -> float:
    widths = []
    for character in PROBE_GLYPHS:
        mask = glyph_mask(path, character)
        for fraction in (0.18, 0.25, 0.32, 0.68, 0.75, 0.82):
            row = mask[int(round((mask.shape[0] - 1) * fraction))]
            runs = run_lengths(row)
            widths.extend(
                int(value) for value in runs
                if 3 < value < mask.shape[1] * 0.35
            )
    return float(np.median(widths))


def main() -> None:
    paths = {
        "courierNewRegular": COURIER_NEW,
        "portsmouthRegular": PROJECT / "build" / "family" / "Portsmouth.ttf",
        "portsmouthLight": PROJECT / "build" / "family" / "Portsmouth-Light.ttf",
    }
    widths = {key: median_upright_stem(path) for key, path in paths.items()}
    difference = widths["portsmouthLight"] - widths["courierNewRegular"]
    report = {
        "version": FAMILY_VERSION,
        "method": (
            "median vertical-stem run across H I N E M at a matched 700-pixel H cap height"
        ),
        "probeGlyphs": PROBE_GLYPHS,
        "matchedCapHeightPixels": CAP_PIXELS,
        "stemWidthsPixels": widths,
        "lightMinusCourierPixels": difference,
        "targetErosionRadiusFontUnits": LIGHT_TARGET_RADIUS,
        "tolerancePixels": 6.0,
        "passed": (
            abs(difference) <= 6.0
            and widths["portsmouthLight"] < widths["portsmouthRegular"]
        ),
    }
    output = PROJECT / "reports" / f"light-reference-audit-{FAMILY_VERSION}.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    print(output)
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
