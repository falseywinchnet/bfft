#!/usr/bin/env python3
"""Promote visually accepted lower-web symbol compositions."""

from __future__ import annotations

import json
import shutil

from portsmouth_engine import EikonalMidpointEngine, PROJECT


CHARACTERS = "©ª\u00ad®¶º½¾"


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    promoted = []
    for character in CHARACTERS:
        stem = f"{ord(character):04x}"
        candidate_geometry = PROJECT / "geometry" / f"web-symbol-composed-{stem}.npz"
        candidate_report_path = PROJECT / "reports" / f"web-symbol-composed-{stem}.json"
        current_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
        current_report = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
        if not candidate_geometry.exists() or not candidate_report_path.exists():
            raise FileNotFoundError(f"Missing candidate for U+{ord(character):04X}")
        shutil.copy2(candidate_geometry, current_geometry)
        candidate = json.loads(candidate_report_path.read_text())
        sources = [source.filename for source in engine.sources if ord(character) in source.cmap]
        report = {
            **candidate,
            "status": "experimental_promoted_web_symbol_composition",
            "sources": sources,
            "equalSourceWeight": None,
            "sourceWeighting": "inherited from accepted Portsmouth component geometry",
            "candidateReport": str(candidate_report_path.relative_to(PROJECT)),
            "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
            "visualReview": "passes composed specimen and installed-font contextual review",
        }
        current_report.write_text(json.dumps(report, indent=2) + "\n")
        promoted.append(f"U+{ord(character):04X}")
    print(json.dumps({"promoted": promoted}, indent=2))


if __name__ == "__main__":
    main()
