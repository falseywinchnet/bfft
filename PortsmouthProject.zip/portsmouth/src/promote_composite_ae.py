#!/usr/bin/env python3
"""Promote the accepted explicit Portsmouth æ ligature construction."""

from __future__ import annotations

import json
import shutil

import numpy as np

from portsmouth_engine import PROJECT


def main() -> None:
    stem = "00e6"
    current_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}.npz"
    current_report = PROJECT / "reports" / f"multicontour-trace-{stem}.json"
    baseline_geometry = PROJECT / "geometry" / f"multicontour-trace-{stem}-pre-explicit-ligature.npz"
    baseline_report = PROJECT / "reports" / f"multicontour-trace-{stem}-pre-explicit-ligature.json"
    candidate = PROJECT / "geometry" / f"composite-ae-{stem}-shift145.npz"
    if not baseline_geometry.exists():
        shutil.copy2(current_geometry, baseline_geometry)
    if not baseline_report.exists():
        shutil.copy2(current_report, baseline_report)
    with np.load(candidate, allow_pickle=False) as archive:
        arrays = {
            key: archive[key].astype(np.float32)
            for key in archive.files if key not in {"character", "unitsPerEm"}
        }
        arrays["character"] = np.asarray("æ")
        arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
        np.savez_compressed(current_geometry, **arrays)
        points = np.vstack(list(arrays.values())[:-2])
    target_advance = float(np.max(points[:, 0]) - np.min(points[:, 0]) + 70.0)
    report = {
        "character": "æ",
        "status": "experimental_promoted_explicit_ligature",
        "designConstraint": "accepted Portsmouth a and e joined at one controlled central seam",
        "pipeline": [
            "accepted_portsmouth_a_geometry",
            "accepted_portsmouth_e_geometry",
            "symmetric_145_unit_center_separation",
            "nonzero_winding_body_union",
            "two_counter_retention",
        ],
        "sources": [
            "AnnotationMono-VF.ttf", "ComicShannsMono-Regular.ttf",
            "SyneMono-Regular.ttf", "bedstead.otf", "routed-gothic.ttf",
        ],
        "equalSourceWeight": None,
        "componentWeights": {
            "a": "accepted glyph-specific equal-third Shanns/Syne/Routed",
            "e": "accepted default equal-quarter Annotation/Shanns/Bedstead/Routed",
        },
        "halfCenterSeparation": 145.0,
        "targetAdvance": target_advance,
        "expectedTopology": {"components": 1, "holes": 2},
        "outputTopology": {"components": 1, "holes": 2},
        "pointsPerContour": 10240,
        "candidateGeometry": str(candidate.relative_to(PROJECT)),
        "candidateReport": "reports/composite-ae-00e6.json",
        "baselineGeometry": str(baseline_geometry.relative_to(PROJECT)),
        "baselineReport": str(baseline_report.relative_to(PROJECT)),
        "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
        "visualReview": "Accepted: two open counters, legible central stem, and no congested seam.",
    }
    current_report.write_text(json.dumps(report, indent=2) + "\n")
    experiment_report_path = PROJECT / "reports" / "composite-ae-00e6.json"
    experiment = json.loads(experiment_report_path.read_text())
    experiment["status"] = "experimental_promoted_explicit_ligature"
    experiment["selectedHalfCenterSeparation"] = 145.0
    experiment["replacesCurrentGeometry"] = True
    experiment["visualReview"] = report["visualReview"]
    experiment_report_path.write_text(json.dumps(experiment, indent=2) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
