#!/usr/bin/env python3
"""Compare direct and diffusive medial barycenters for lowercase m."""

from __future__ import annotations

import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from medial_transport import (
    disk_envelope,
    intrinsic_graph_barycenter,
    mask_statistics,
    sample_medial_structure,
)
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from transport_barycenter import free_support_barycenter


def main() -> None:
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    fields = [engine.source_field(source, "m") for source in engine.active_sources("m")]
    measures = []
    for field in fields:
        measures.append(sample_medial_structure(engine, field, 128))
    supports = [measure.support for measure in measures]
    masses = [measure.mass for measure in measures]
    direct = free_support_barycenter(
        supports, masses, scale=np.array([500.0, 500.0, 60.0]),
    )
    intrinsic, intrinsic_info = intrinsic_graph_barycenter(measures, direct)
    _, direct_mask = disk_envelope(engine, direct.support)
    _, intrinsic_mask = disk_envelope(engine, intrinsic.support)

    report = {
        "character": "m",
        "pipeline": ["transport", "barycenter", "build_disks", "merge_envelope"],
        "sources": [field.source.filename for field in fields],
        "equalSourceWeight": 1.0 / len(fields),
        "medialAtomsPerSource": 128,
        "transport": "hard_intrinsic_metric_graph_correspondence",
        "directBarycenter": {
            "objective": direct.objective,
            "iterations": direct.iterations,
            **mask_statistics(direct_mask),
        },
        "intrinsicGraphBarycenter": {
            **intrinsic_info,
            **mask_statistics(intrinsic_mask),
        },
        "geometryBuilt": "one maximal disk per barycenter atom",
        "geometryMerged": "union via maximum Eikonal disk envelope",
    }
    (PROJECT / "reports" / "medial-fusion-006d.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )

    entries = [(field.source.family, field.mask, support) for field, support in zip(fields, supports)]
    entries += [
        ("Direct transported barycenter", direct_mask, direct.support),
        ("Intrinsic graph barycenter", intrinsic_mask, intrinsic.support),
    ]
    tile_w, tile_h, columns = 380, 390, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new("RGB", (80 + columns * tile_w, 155 + rows * tile_h), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 34)
    label = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 19)
    small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 14)
    draw.text((40, 28), "Portsmouth m — medial transport pathways", fill="#111", font=title)
    draw.text(
        (40, 78),
        "transport → barycenter → build maximal disks → merge Eikonal envelope",
        fill="#575149", font=small,
    )
    for index, (name, mask, atoms) in enumerate(entries):
        col, row = index % columns, index // columns
        x0, y0 = 40 + col * tile_w, 120 + row * tile_h
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_w - 20, y0 + tile_h - 20), radius=10,
            fill="#fffdf8", outline="#d0cabf", width=2,
        )
        ys, xs = np.nonzero(mask)
        left, right = max(0, xs.min() - 12), min(mask.shape[1], xs.max() + 13)
        top, bottom = max(0, ys.min() - 12), min(mask.shape[0], ys.max() + 13)
        crop = mask[top:bottom, left:right]
        layer = np.full((*crop.shape, 3), 255, dtype=np.uint8)
        layer[crop] = (25, 25, 23)
        glyph = Image.fromarray(layer)
        glyph.thumbnail((tile_w - 75, tile_h - 105), Image.Resampling.LANCZOS)
        gx = x0 + (tile_w - 20 - glyph.width) // 2
        gy = y0 + 64 + (tile_h - 105 - glyph.height) // 2
        canvas.paste(glyph, (gx, gy))
        # Transform atom coordinates through the same crop and thumbnail scale.
        columns_a = (atoms[:, 0] - engine.x_min) * engine.pixels_per_unit - 0.5
        rows_a = (engine.y_max - atoms[:, 1]) * engine.pixels_per_unit - 0.5
        scale = glyph.width / max(crop.shape[1], 1)
        for cx, cy, radius in zip(columns_a, rows_a, atoms[:, 2]):
            px = gx + (cx - left) * scale
            py = gy + (cy - top) * scale
            rr = max(1.2, min(3.2, radius / 22.0))
            draw.ellipse((px - rr, py - rr, px + rr, py + rr), fill="#d34e38")
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), "red = transported medial atoms", fill="#655f57", font=small)

    output = PROJECT / "specimens" / "medial-fusion-006d.png"
    canvas.save(output)
    print(json.dumps(report, indent=2))
    print(output)


if __name__ == "__main__":
    main()
