#!/usr/bin/env python3
"""Render the accepted 0.108 punctuation changes at inspection scale."""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from build_portsmouth_family import FAMILY_VERSION
from portsmouth_engine import PROJECT


def main():
    canvas = Image.new("RGB", (2400, 2200), "#f2ede3")
    draw = ImageDraw.Draw(canvas)
    ui_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    ui = ImageFont.truetype(ui_path, 22)
    title = ImageFont.truetype(ui_path, 43)
    draw.text((65, 38), f"Portsmouth {FAMILY_VERSION} — punctuation revision review", font=title, fill="#171715")
    draw.text((68, 100), "Geometry only · no kerning · no GSUB/GPOS · literal -- remains literal", font=ui, fill="#625b52")

    regular = PROJECT / "build/family/Portsmouth.ttf"
    mono = PROJECT / "build/mono/PortsmouthMono.ttf"
    rows = [
        ("SEMICOLON RELATION", regular, ",   ;   :      comma / midpoint tomoe / colon", 88),
        ("PLUS-ALIGNED HYPHEN", regular, "H-H   H+H      a-b   a+b      --   —", 108),
        ("CURLY QUOTES", regular, "‘single’  “double”  ‘nested “thought”’", 104),
        ("MONO CODE", mono, "if (a-- > b) { note = “AI — thought”; }", 82),
    ]
    y = 185
    for label, path, text, size in rows:
        draw.text((70, y), label, font=ui, fill="#985848")
        baseline = y + 175
        draw.line((65, baseline, 2325, baseline), fill="#557b9d", width=2)
        draw.text((255, baseline), text, font=ImageFont.truetype(path, size), fill="#171715", anchor="ls")
        y += 295

    draw.text((70, 1375), "U+2014 THOUGHT BREAK ACROSS THE FAMILY", font=ui, fill="#985848")
    faces = [
        ("Regular", "Portsmouth.ttf"), ("Light", "Portsmouth-Light.ttf"),
        ("Italic", "Portsmouth-Italic.ttf"), ("Bold", "Portsmouth-Bold.ttf"),
        ("Bold Italic", "Portsmouth-BoldItalic.ttf"),
    ]
    for index, (label, filename) in enumerate(faces):
        col, row = index % 3, index // 3
        x, top = 70 + col * 765, 1430 + row * 325
        draw.rounded_rectangle((x, top, x + 700, top + 275), 12, outline="#c8bfb2", width=2)
        draw.text((x + 20, top + 15), label.upper(), font=ui, fill="#665f56")
        baseline = top + 222
        draw.line((x + 18, baseline, x + 680, baseline), fill="#557b9d", width=2)
        draw.line((x + 18, baseline - 140, x + 680, baseline - 140), fill="#c96e5c", width=2)
        face = ImageFont.truetype(PROJECT / "build/family" / filename, 200)
        draw.text((x + 240, baseline), "A—B", font=face, fill="#171715", anchor="ls")

    output = PROJECT / "specimens" / f"Portsmouth-Punctuation-Revision-{FAMILY_VERSION}.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
