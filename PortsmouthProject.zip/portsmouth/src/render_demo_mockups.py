#!/usr/bin/env python3
"""Render contextual Portsmouth specimens for optical defect discovery."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from portsmouth_engine import PROJECT


UI = "/System/Library/Fonts/Supplemental/Arial.ttf"


def wrapped(draw, text: str, font, width: int) -> list[str]:
    words = text.split()
    lines, current = [], ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if current and draw.textbbox((0, 0), candidate, font=font)[2] > width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def editorial(font_path: Path, version: str) -> Path:
    image = Image.new("RGB", (1800, 1640), "#f1ede4")
    draw = ImageDraw.Draw(image)
    ui = ImageFont.truetype(UI, 16)
    label = ImageFont.truetype(UI, 18)
    display = ImageFont.truetype(font_path, 154)
    deck = ImageFont.truetype(font_path, 42)
    body = ImageFont.truetype(font_path, 28)
    draw.text((65, 38), f"PORTSMOUTH {version} / RUNNING-TEXT AUDIT", fill="#716b62", font=label)
    draw.text((60, 92), "Portsmouth", fill="#171716", font=display)
    draw.text(
        (70, 270),
        "A geometric midpoint with a human pulse.",
        fill="#b64634",
        font=deck,
    )
    draw.line((68, 342, 1732, 342), fill="#bcb4a7", width=2)

    paragraph = (
        "At the quayside, a quiet crowd watched five strange alphabets become one. "
        "Each voice kept its own rhythm, yet the page remained calm: broad counters, "
        "plain stems, quick joins, and a little angular wit where curves meet structure."
    )
    y = 390
    for line in wrapped(draw, paragraph, body, 1060):
        draw.text((68, y), line, fill="#242321", font=body)
        y += 43
    draw.text((1190, 390), "aqua\nquay\nquagga\nequal\nfaq", fill="#171716", font=ImageFont.truetype(font_path, 62), spacing=14)

    draw.text((68, 680), "SIZE LADDER", fill="#716b62", font=label)
    y = 720
    for size in (18, 24, 32, 44, 60):
        face = ImageFont.truetype(font_path, size)
        draw.text((68, y), f"{size:02d}  Portsmouth makes ordinary language feel newly drawn.", fill="#171716", font=face)
        y += size + 24

    draw.text((68, 1080), "COLLISION / CONFUSION STRINGS", fill="#716b62", font=label)
    tests = [
        "minimum rhythm  mwmn  rnrn  cld  fjt",
        "a q aq qa aqua quark equal kafka façades",
        "0 O Ø ø  1 I l i  @  / \\  () [] {}",
        "J1 JI Il 1i  © ®  ª º  ½ ¾  ¶  ¿Qué?",
        "À Québec, Strasse, smørrebrød; Ð Ø ø ± µ · ¤",
    ]
    y = 1120
    test_face = ImageFont.truetype(font_path, 37)
    for line in tests:
        draw.text((68, y), line, fill="#171716", font=test_face)
        y += 76

    draw.text(
        (68, 1558),
        "Visual authority: inspect joins, counters, spacing rhythm, accents, and repeated-letter color.",
        fill="#716b62",
        font=ui,
    )
    output = PROJECT / "specimens" / f"Portsmouth-Regular-{version}-editorial.png"
    image.save(output)
    return output


def interface(font_path: Path, version: str) -> Path:
    image = Image.new("RGB", (1800, 1220), "#101514")
    draw = ImageDraw.Draw(image)
    label = ImageFont.truetype(UI, 16)
    face = ImageFont.truetype(font_path, 31)
    small = ImageFont.truetype(font_path, 24)
    heading = ImageFont.truetype(font_path, 76)
    accent = "#a5e36b"
    ink = "#e7e9df"
    muted = "#859089"
    draw.rounded_rectangle((45, 42, 1755, 1170), radius=18, fill="#151c1a", outline="#35423d", width=2)
    draw.ellipse((78, 72, 94, 88), fill="#e26356")
    draw.ellipse((106, 72, 122, 88), fill="#d8aa52")
    draw.ellipse((134, 72, 150, 88), fill="#6abf76")
    draw.text((1640, 70), f"v{version}", fill=muted, font=label)
    draw.text((82, 132), "PORTSMOUTH / GLYPH LAB", fill=ink, font=heading)
    draw.text((86, 238), "fusion.status", fill=muted, font=small)
    draw.text((410, 238), "stable - 1 static midpoint", fill=accent, font=small)

    rows = [
        ("sources", "annotation + shanns + syne + bedstead + gothic"),
        ("route.a", "shanns / syne / gothic   weight 0.333333"),
        ("route.q", "shanns / syne / gothic   straight descender"),
        ("landmarks", "baseline 0  ·  x-height 505  ·  cap 700"),
        ("identity", "0/O/Ø  1/I/l/i  @/¤/§  q/g/p/b/d"),
    ]
    y = 330
    for key, value in rows:
        draw.text((88, y), f"{key:<14}", fill="#77bfc4", font=face)
        draw.text((410, y), value, fill=ink, font=face)
        y += 70
    draw.line((86, 700, 1710, 700), fill="#35423d", width=2)
    code = [
        "$ portsmouth inspect --text 'aquatic quays / minimum rhythm'",
        "counter.clearance ......... pass",
        "descender.join ............ pass",
        "accent.separation ......... review visually",
        "coverage.web .............. © ® ª º ½ ¾ ¶ ¿ @ # % &",
        "render .................... The quick brown fox jumps 0123456789",
    ]
    y = 748
    for index, line in enumerate(code):
        draw.text((88, y), line, fill=accent if index == 0 else ink, font=small)
        y += 60
    output = PROJECT / "specimens" / f"Portsmouth-Regular-{version}-interface.png"
    image.save(output)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", default="0.016")
    parser.add_argument("--font", type=Path)
    arguments = parser.parse_args()
    font = arguments.font or PROJECT / "build" / f"Portsmouth-Regular-{arguments.version}.ttf"
    if not font.exists():
        raise FileNotFoundError(font)
    for output in (editorial(font, arguments.version), interface(font, arguments.version)):
        print(output)


if __name__ == "__main__":
    main()
