#!/usr/bin/env python3
"""Build selected Portsmouth a/q/æ from Shanns, Routed, and Syne Mono."""

from __future__ import annotations

import argparse
import json
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from boundary_trace import annealed_boundary_barycenter, boundary_cloud, rasterize_contour_complex
from outline_geometry import landmark_normalized_contours, union_contour_complex
from portsmouth_engine import EikonalMidpointEngine, PROJECT
from run_multicontour_trace_experiment import (
    _render_mask,
    component_fields,
    medial_basis,
    pair_loops,
)


SOURCES = (
    "ComicShannsMono-Regular.ttf",
    "SyneMono-Regular.ttf",
    "routed-gothic.ttf",
)
POINTS = 10240


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("character", nargs="?", choices=("a", "q", "æ"), default="a")
    arguments = parser.parse_args()
    engine = EikonalMidpointEngine(pixels_per_unit=0.5)
    character = arguments.character
    source_by_name = {source.filename: source for source in engine.sources}
    sources = [source_by_name[name] for name in SOURCES]
    source_fields = [engine.source_field(source, character) for source in sources]
    normalized = {
        source.filename: landmark_normalized_contours(engine, source, character)
        for source in sources
    }
    tops = [
        max(float(np.max(contour[:, 1])) for contour in normalized[source.filename])
        for source in sources
    ]
    target_top = float(np.median(tops))
    for source, top in zip(sources, tops):
        scale = target_top / top
        for contour in normalized[source.filename]:
            contour[:, 1] *= scale
    complexes = [
        union_contour_complex(normalized[source.filename], pixels_per_unit=5.0)
        for source in sources
    ]
    source_topology = [
        {"components": len(value.outer), "holes": len(value.holes)}
        for value in complexes
    ]
    expected = source_topology[0]
    if any(value != expected for value in source_topology):
        raise ValueError(f"Selected a constructions disagree: {source_topology}")
    if expected["components"] != 1:
        raise ValueError(f"Selected construction requires one body: {expected}")

    outer_group = [max(value.outer, key=lambda loop: loop.area) for value in complexes]
    hole_groups = pair_loops(complexes, "hole")
    body_fields = component_fields(engine, source_fields, outer_group, hole_groups)
    measures, median, median_info = medial_basis(engine, body_fields)
    output = []
    contour_reports = []
    for role, group in [("outer", outer_group)] + [("hole", group) for group in hole_groups]:
        clouds = [
            boundary_cloud(
                engine,
                field,
                measure,
                median,
                plan,
                count=POINTS,
                source_contour=loop.points,
            )
            for field, measure, plan, loop in zip(
                body_fields, measures, median.plans, group
            )
        ]
        contour, annealing = annealed_boundary_barycenter(clouds)
        output.append((role, contour))
        contour_reports.append({"role": role, "annealing": annealing})

    mask = rasterize_contour_complex(engine, output)
    actual = engine.topology(mask)
    if actual != expected:
        raise ValueError(f"Constrained a topology {actual}, expected {expected}")
    stem = f"{ord(character):04x}"
    geometry = PROJECT / "geometry" / f"constrained-{character}-{stem}.npz"
    arrays = {
        f"{role}_{index}": contour.astype(np.float32)
        for index, (role, contour) in enumerate(output)
    }
    arrays["character"] = np.asarray(character)
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(geometry, **arrays)
    report = {
        "character": character,
        "status": f"candidate_user_directed_one_storey_{character}",
        "designConstraint": (
            "one-storey construction only" if character == "a"
            else "one-storey bowl with straight descending right stem" if character == "q"
            else "single joined a/e body with two independently transported counters"
        ),
        "pipeline": [
            "exclude_incompatible_annotation_and_bedstead_constructions",
            "equal_weight_shanns_syne_routed_transport",
            "one_storey_outer_counter_unity",
        ],
        "sources": list(SOURCES),
        "excludedSources": ["AnnotationMono-VF.ttf", "bedstead.otf"],
        "equalSourceWeight": 1.0 / 3.0,
        "targetAdvance": float(np.mean([source.widths[ord(character)] for source in sources])),
        "exactTargetInkTop": target_top,
        "sourceTopology": dict(zip(SOURCES, source_topology)),
        "expectedTopology": expected,
        "outputTopology": actual,
        "pointsPerContour": POINTS,
        "medianSkeleton": median_info,
        "contours": contour_reports,
        "geometryArtifact": str(geometry.relative_to(PROJECT)),
        "replacesCurrentGeometry": False,
        "visualReview": None,
    }
    report_path = PROJECT / "reports" / f"constrained-{character}-{stem}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")

    entries = [
        (field.source.family, field.mask, "equal ⅓ · one-storey")
        for field in body_fields
    ]
    entries.append(("Portsmouth candidate", mask, str(actual)))
    tile_width, tile_height, columns = 390, 410, 3
    rows = math.ceil(len(entries) / columns)
    canvas = Image.new(
        "RGB", (80 + columns * tile_width, 150 + rows * tile_height), "#eee9df"
    )
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 18)
    small = ImageFont.truetype(ui, 14)
    draw.text((40, 28), f"Portsmouth {character} — one-storey fusion", fill="#111", font=title)
    draw.text(
        (40, 78),
        "Comic Shanns + Syne Mono + Routed Gothic · equal one-third geometry",
        fill="#575149",
        font=small,
    )
    for index, (name, source_mask, subtitle) in enumerate(entries):
        column, row = index % columns, index // columns
        x0, y0 = 40 + column * tile_width, 120 + row * tile_height
        draw.rounded_rectangle(
            (x0, y0, x0 + tile_width - 20, y0 + tile_height - 20),
            radius=10,
            fill="#fffdf8",
            outline="#d0cabf",
            width=2,
        )
        image = _render_mask(source_mask, (tile_width - 70, tile_height - 105))
        canvas.paste(
            image,
            (
                x0 + (tile_width - 20 - image.width) // 2,
                y0 + 63 + (tile_height - 105 - image.height) // 2,
            ),
        )
        draw.text((x0 + 15, y0 + 15), name, fill="#151515", font=label)
        draw.text((x0 + 15, y0 + 42), subtitle, fill="#655f57", font=small)
    specimen = PROJECT / "specimens" / f"constrained-{character}-{stem}.png"
    canvas.save(specimen)
    print(json.dumps({key: value for key, value in report.items() if key != "contours"}, indent=2))
    print(specimen)


if __name__ == "__main__":
    main()
