#!/usr/bin/env python3
"""Promote visually accepted localized J and numeral 1 repairs."""

from __future__ import annotations

import json
import shutil

import numpy as np

from portsmouth_engine import PROJECT


SELECTIONS = {
    "J": ("boundary-trace", "restrained", "restrained rounded top bar"),
    "1": ("multicontour-trace", "360", "symmetric 360-unit rounded foot"),
}


def main() -> None:
    promoted = {}
    for character, (prefix, label, description) in SELECTIONS.items():
        stem = f"{ord(character):04x}"
        current_geometry = PROJECT / "geometry" / f"{prefix}-{stem}.npz"
        current_report = PROJECT / "reports" / f"{prefix}-{stem}.json"
        backup_geometry = PROJECT / "geometry" / f"{prefix}-{stem}-pre-terminal-repair.npz"
        backup_report = PROJECT / "reports" / f"{prefix}-{stem}-pre-terminal-repair.json"
        candidate = PROJECT / "geometry" / f"terminal-repair-{stem}-{label}.npz"
        if not backup_geometry.exists():
            shutil.copy2(current_geometry, backup_geometry)
        if not backup_report.exists():
            shutil.copy2(current_report, backup_report)
        with np.load(candidate, allow_pickle=False) as archive:
            points = archive["outer_0"].astype(np.float32)
        key = "contour" if prefix == "boundary-trace" else "outer_0"
        np.savez_compressed(
            current_geometry,
            **{key: points},
            character=np.asarray(character),
            unitsPerEm=np.asarray(1000, dtype=np.int32),
        )
        old = json.loads(backup_report.read_text())
        report = {
            "character": character,
            "status": "experimental_promoted_terminal_repair",
            "designConstraint": description,
            "pipeline": [
                "preserve_accepted_body_geometry",
                "clip_only_flagged_terminal_region",
                "construct_symmetric_rounded_terminal",
                "nonzero_winding_union",
            ],
            "sources": old["sources"],
            "equalSourceWeight": old["equalSourceWeight"],
            "selectedCandidate": label,
            "candidateGeometry": str(candidate.relative_to(PROJECT)),
            "baselineGeometry": str(backup_geometry.relative_to(PROJECT)),
            "baselineReport": str(backup_report.relative_to(PROJECT)),
            "geometryArtifact": str(current_geometry.relative_to(PROJECT)),
            "expectedTopology": {"components": 1, "holes": 0},
            "outputTopology": {"components": 1, "holes": 0},
            "pointsPerContour": 10240,
            "visualReview": f"Accepted localized repair: {description}; remaining body unchanged.",
        }
        current_report.write_text(json.dumps(report, indent=2) + "\n")
        promoted[character] = report
    experiment_path = PROJECT / "reports" / "terminal-repairs-J1.json"
    experiment = json.loads(experiment_path.read_text())
    experiment["status"] = "experimental_promoted_terminal_repairs"
    experiment["selected"] = {character: value[1] for character, value in SELECTIONS.items()}
    experiment["replacesCurrentGeometry"] = True
    experiment["visualReview"] = "Accepted restrained J bar and 360-unit numeral 1 foot."
    experiment_path.write_text(json.dumps(experiment, indent=2) + "\n")
    print(json.dumps(promoted, indent=2))


if __name__ == "__main__":
    main()
