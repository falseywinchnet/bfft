#!/usr/bin/env python3
"""Render enlarged Regular/q2 glyph comparisons and their pixel differences."""

from __future__ import annotations

import sys

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps

from portsmouth_engine import PROJECT


def glyph_image(path, character: str) -> Image.Image:
    image = Image.new("L", (720, 900), 0)
    font = ImageFont.truetype(path, 760)
    ImageDraw.Draw(image).text((110, 60), character, fill=255, font=font)
    return image


def main() -> None:
    characters = sys.argv[1] if len(sys.argv) > 1 else "¿Òª@VMW"
    regular = PROJECT / "build" / "Portsmouth-Regular-0.017.ttf"
    q2 = PROJECT / "build" / "experimental" / "Portsmouth-Quadratic-0.017-makima-q2.ttf"
    canvas = Image.new("RGB", (2250, 90 + len(characters) * 940), "#eee9df")
    draw = ImageDraw.Draw(canvas)
    ui = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title = ImageFont.truetype(ui, 34)
    label = ImageFont.truetype(ui, 20)
    draw.text((35, 20), "Regular 0.017 · Makima q2 · amplified absolute difference", fill="#111", font=title)
    for row, character in enumerate(characters):
        y = 80 + row * 940
        left = glyph_image(regular, character)
        right = glyph_image(q2, character)
        difference = ImageOps.autocontrast(ImageChops.difference(left, right)).convert("RGB")
        left_rgb = Image.merge("RGB", (left, left, left))
        right_rgb = Image.merge("RGB", (right, right, right))
        for column, (name, image) in enumerate((("Regular", left_rgb), ("Makima q2", right_rgb), ("difference", difference))):
            x = 30 + column * 740
            canvas.paste(image, (x, y + 30))
            draw.text((x + 10, y), f"{character} · {name}", fill="#5d574e", font=label)
    output = PROJECT / "specimens" / "experimental" / "Portsmouth-Makima-q2-glyph-detail.png"
    canvas.save(output)
    print(output)


if __name__ == "__main__":
    main()
