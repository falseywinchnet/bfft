#!/usr/bin/env python3
"""Dense blue-noise glyph fingerprints annealed around a median skeleton."""

from __future__ import annotations

from dataclasses import dataclass
import heapq

import numpy as np
from scipy import ndimage
from scipy.spatial import cKDTree

from medial_transport import MedialMeasure, disk_envelope
from portsmouth_engine import EikonalMidpointEngine, GlyphField
from shock_graph import extract
from transport_barycenter import TransportBarycenter


@dataclass
class DenseFingerprint:
    source: str
    native_points: np.ndarray
    transported_points: np.ndarray
    tether_points: np.ndarray
    source_anchor: np.ndarray
    median_anchor: np.ndarray
    median_anchor_points: np.ndarray
    relative_tangent_normal: np.ndarray


def blue_noise_centroids(
    engine: EikonalMidpointEngine,
    field: GlyphField,
    count: int,
    *,
    iterations: int = 7,
    seed: int = 0,
) -> np.ndarray:
    """Approximate a high-density centroidal Voronoi/blue-noise fingerprint."""
    rows, columns = np.nonzero(field.mask)
    if len(rows) < count:
        raise ValueError(f"{field.source.filename} has too little ink for {count} atoms")
    pixels = np.column_stack((columns.astype(float), rows.astype(float)))
    rng = np.random.default_rng(seed)
    centers = pixels[rng.choice(len(pixels), count, replace=False)].copy()
    for _ in range(iterations):
        _, labels = cKDTree(centers).query(pixels, k=1)
        population = np.bincount(labels, minlength=count)
        sum_x = np.bincount(labels, weights=pixels[:, 0], minlength=count)
        sum_y = np.bincount(labels, weights=pixels[:, 1], minlength=count)
        occupied = population > 0
        centers[occupied, 0] = sum_x[occupied] / population[occupied]
        centers[occupied, 1] = sum_y[occupied] / population[occupied]
        if np.any(~occupied):
            distance, _ = cKDTree(centers[occupied]).query(pixels, k=1)
            replacements = np.argsort(distance)[-np.count_nonzero(~occupied):]
            centers[~occupied] = pixels[replacements]
    x = engine.x_min + (centers[:, 0] + 0.5) / engine.pixels_per_unit
    y = engine.y_max - (centers[:, 1] + 0.5) / engine.pixels_per_unit
    return np.column_stack((x, y))


def _node_frames(support: np.ndarray, geodesic: np.ndarray) -> np.ndarray:
    """Tangent/normal frame from each atom's intrinsic neighborhood."""
    count = len(support)
    frames = np.empty((count, 2, 2), dtype=np.float64)
    for index in range(count):
        order = np.argsort(geodesic[index])
        neighbors = order[1 : min(9, count)]
        delta = support[neighbors, :2] - support[index, :2]
        covariance = delta.T @ delta
        values, vectors = np.linalg.eigh(covariance)
        tangent = vectors[:, int(np.argmax(values))]
        if tangent[0] < 0.0 or (abs(tangent[0]) < 1e-9 and tangent[1] < 0.0):
            tangent *= -1.0
        normal = np.array([-tangent[1], tangent[0]])
        frames[index, 0] = tangent
        frames[index, 1] = normal
    return frames


def transport_fingerprint(
    field: GlyphField,
    measure: MedialMeasure,
    median: TransportBarycenter,
    plan: np.ndarray,
    native_points: np.ndarray,
    median_geodesic: np.ndarray,
) -> DenseFingerprint:
    """Lift dense ink atoms into the median skeleton's intrinsic frame."""
    mass = median.support_mass
    permutation = np.argmax(plan, axis=1)  # median node -> source node
    inverse = np.empty(len(permutation), dtype=np.int64)
    inverse[permutation] = np.arange(len(permutation))
    source_frames = _node_frames(measure.support, measure.geodesic)
    # Median graph distances are the equal-weight source distances in the
    # accepted correspondence, and supply its local tangent neighborhoods.
    median_frames = _node_frames(median.support, median_geodesic)
    nearest_source = cKDTree(measure.support[:, :2]).query(native_points, k=1)[1]
    median_anchor = inverse[nearest_source]
    delta = native_points - measure.support[nearest_source, :2]
    tangent = source_frames[nearest_source, 0]
    normal = source_frames[nearest_source, 1]
    radius = np.maximum(measure.support[nearest_source, 2], 1.0)
    relative = np.column_stack((
        np.sum(delta * tangent, axis=1) / radius,
        np.sum(delta * normal, axis=1) / radius,
    ))
    median_tangent = median_frames[median_anchor, 0]
    median_normal = median_frames[median_anchor, 1]
    median_radius = median.support[median_anchor, 2]
    transported = (
        median.support[median_anchor, :2]
        + median_radius[:, None]
        * (relative[:, :1] * median_tangent + relative[:, 1:] * median_normal)
    )
    return DenseFingerprint(
        source=field.source.filename,
        native_points=native_points,
        transported_points=transported.copy(),
        tether_points=transported.copy(),
        source_anchor=nearest_source,
        median_anchor=median_anchor,
        median_anchor_points=median.support[median_anchor, :2],
        relative_tangent_normal=relative,
    )


def anneal_fingerprints(
    fingerprints: list[DenseFingerprint],
    *,
    schedule: tuple[tuple[int, float, float], ...] = (
        (72, 0.34, 0.26),
        (48, 0.30, 0.22),
        (32, 0.26, 0.18),
        (22, 0.22, 0.15),
        (14, 0.18, 0.12),
        (10, 0.14, 0.10),
    ),
    passes_per_stage: int = 3,
) -> tuple[list[np.ndarray], list[dict]]:
    """Neighborhood-consensus annealing with equal source influence."""
    points = [fingerprint.transported_points.copy() for fingerprint in fingerprints]
    source_count = len(points)
    atom_count = len(points[0])
    labels = np.repeat(np.arange(source_count), atom_count)
    anchor_points = np.vstack([
        fingerprint.median_anchor_points for fingerprint in fingerprints
    ])
    relative = np.vstack([
        fingerprint.relative_tangent_normal for fingerprint in fingerprints
    ])
    trace = []
    for stage, (neighbors, attraction, tether) in enumerate(schedule, start=1):
        for pass_index in range(passes_per_stage):
            pooled = np.vstack(points)
            # Spatial proximity alone confuses a stem with the shoulder that
            # touches it.  The annealing neighborhood therefore also lives in
            # the shared skeleton-anchor and tangent/normal coordinates.
            feature = np.column_stack((
                pooled / 70.0,
                anchor_points / 38.0,
                relative / 0.42,
            ))
            tree = cKDTree(feature)
            distances, indices = tree.query(feature, k=min(neighbors, len(pooled)))
            updated = pooled.copy()
            for index in range(len(pooled)):
                local_indices = np.atleast_1d(indices[index])
                local_distances = np.atleast_1d(distances[index])
                sigma = max(float(np.median(local_distances[1:])), 1.0)
                weights = np.exp(-0.5 * (local_distances / sigma) ** 2)
                source_means = []
                for source in range(source_count):
                    selected = labels[local_indices] == source
                    if np.any(selected):
                        weight = weights[selected]
                        source_means.append(np.average(
                            pooled[local_indices[selected]], axis=0, weights=weight
                        ))
                neighborhood_target = np.mean(source_means, axis=0)
                source = labels[index]
                local = index % atom_count
                tether_target = fingerprints[source].tether_points[local]
                updated[index] = (
                    (1.0 - attraction - tether) * pooled[index]
                    + attraction * neighborhood_target
                    + tether * tether_target
                )
            points = [
                updated[source * atom_count : (source + 1) * atom_count]
                for source in range(source_count)
            ]
            trace.append({
                "stage": stage,
                "pass": pass_index + 1,
                "neighbors": neighbors,
                "attraction": attraction,
                "tether": tether,
                "meanTetherDisplacement": float(np.mean([
                    np.mean(np.linalg.norm(value - fingerprint.tether_points, axis=1))
                    for value, fingerprint in zip(points, fingerprints)
                ])),
            })
    return points, trace


def density_geometry(
    engine: EikonalMidpointEngine,
    point_sets: list[np.ndarray],
    target_area: int,
    *,
    sigma_pixels: float = 4.0,
    seed_skeleton: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Rasterize equal-source density and retain exactly the target ink area."""
    density = np.zeros((engine.height, engine.width), dtype=np.float64)
    for points in point_sets:
        columns = np.rint((points[:, 0] - engine.x_min) * engine.pixels_per_unit - 0.5).astype(int)
        rows = np.rint((engine.y_max - points[:, 1]) * engine.pixels_per_unit - 0.5).astype(int)
        valid = (rows >= 0) & (rows < engine.height) & (columns >= 0) & (columns < engine.width)
        source_density = np.zeros_like(density)
        np.add.at(source_density, (rows[valid], columns[valid]), 1.0)
        source_density = ndimage.gaussian_filter(source_density, sigma=sigma_pixels)
        source_density /= max(float(np.sum(source_density)), 1e-12)
        density += source_density / len(point_sets)
    target_area = min(max(int(target_area), 1), density.size)
    if seed_skeleton is None:
        seed = np.unravel_index(np.argmax(density), density.shape)
        seed_skeleton = np.zeros_like(density, dtype=bool)
        seed_skeleton[seed] = True
    mask = np.asarray(seed_skeleton, dtype=bool).copy()
    if np.count_nonzero(mask) > target_area:
        raise ValueError("Seed skeleton is larger than target area")
    queued = mask.copy()
    frontier: list[tuple[float, int, int]] = []
    height, width = mask.shape

    def push(row: int, column: int) -> None:
        if 0 <= row < height and 0 <= column < width and not queued[row, column]:
            queued[row, column] = True
            heapq.heappush(frontier, (-float(density[row, column]), row, column))

    for row, column in zip(*np.nonzero(mask)):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy or dx:
                    push(int(row + dy), int(column + dx))
    area = int(np.count_nonzero(mask))
    while area < target_area and frontier:
        _, row, column = heapq.heappop(frontier)
        mask[row, column] = True
        area += 1
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy or dx:
                    push(row + dy, column + dx)
    return density, mask


def redraw_from_new_skeleton(
    engine: EikonalMidpointEngine,
    density_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Extract the annealed skeleton/radius field and redraw its envelope."""
    graph = extract(density_mask, pixels_per_unit=engine.pixels_per_unit)
    skeleton = graph.skeleton
    rows, columns = np.nonzero(skeleton)
    base_atoms = np.column_stack((
        engine.x_min + (columns + 0.5) / engine.pixels_per_unit,
        engine.y_max - (rows + 0.5) / engine.pixels_per_unit,
        graph.radius[rows, columns],
    ))
    target_area = int(np.count_nonzero(density_mask))
    low, high = 0.85, 1.35
    reconstructed = density_mask.copy()
    atoms = base_atoms.copy()
    for _ in range(12):
        scale = 0.5 * (low + high)
        candidate_atoms = base_atoms.copy()
        candidate_atoms[:, 2] *= scale
        _, candidate = disk_envelope(engine, candidate_atoms)
        reconstructed = candidate
        atoms = candidate_atoms
        if np.count_nonzero(candidate) < target_area:
            low = scale
        else:
            high = scale
    return reconstructed, skeleton, atoms
