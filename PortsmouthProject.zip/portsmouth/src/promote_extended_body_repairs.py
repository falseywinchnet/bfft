#!/usr/bin/env python3
"""Repair ą, ģ, and ų while preserving the accepted Portsmouth base bodies."""

from __future__ import annotations

import json

import numpy as np

from build_first_ttf import archived_contours, geometry_for
from family_geometry import contours_from_mask, mask_topology, rasterize_local
from portsmouth_engine import PROJECT


def clip_halfplane(points, axis, threshold, keep_greater):
    output = []
    previous = points[-1]
    previous_inside = previous[axis] >= threshold if keep_greater else previous[axis] <= threshold
    for current in points:
        current_inside = current[axis] >= threshold if keep_greater else current[axis] <= threshold
        if current_inside != previous_inside:
            fraction = (threshold - previous[axis]) / (current[axis] - previous[axis])
            output.append(previous + fraction * (current - previous))
        if current_inside:
            output.append(current)
        previous, previous_inside = current, current_inside
    result = np.asarray(output, dtype=np.float64)
    if len(result) < 3:
        raise ValueError("mark clipping collapsed")
    return result


def save(character, contours, report):
    stem = f"{ord(character):04x}"
    path = PROJECT / "geometry" / f"letter-repair-{stem}.npz"
    arrays = {
        f"{role}_{index}": points.astype(np.float32)
        for index, (role, points) in enumerate(contours)
    }
    arrays["character"] = np.asarray(character)
    arrays["unitsPerEm"] = np.asarray(1000, dtype=np.int32)
    np.savez_compressed(path, **arrays)
    report["geometryArtifact"] = str(path.relative_to(PROJECT))
    (PROJECT / "reports" / f"letter-repair-{stem}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    return path


def attached_ogonek(character, base_character, *, x_cut=80.0, y_cut=100.0):
    base = [(role, points.astype(np.float64)) for role, points in archived_contours(geometry_for(ord(base_character)))]
    former = archived_contours(PROJECT / "geometry" / f"multicontour-trace-{ord(character):04x}.npz")
    former_outer = max(
        (points.astype(np.float64) for role, points in former if role == "outer"),
        key=lambda points: float(np.ptp(points[:, 0]) * np.ptp(points[:, 1])),
    )
    mark = clip_halfplane(former_outer, 0, x_cut, True)
    mark = clip_halfplane(mark, 1, y_cut, False)
    base_points = np.vstack([points for _, points in base])
    base_right = float(np.max(base_points[:, 0]))
    former_mark_right = float(np.max(mark[:, 0]))
    inward_shift = min(0.0, base_right - former_mark_right)
    mark[:, 0] += inward_shift
    mark_path = PROJECT / "geometry" / f"letter-repair-mark-{ord(character):04x}.npz"
    np.savez_compressed(
        mark_path,
        outer_0=mark.astype(np.float32),
        character=np.asarray(character),
        unitsPerEm=np.asarray(1000, dtype=np.int32),
    )
    merged_input = base + [("outer", mark)]
    mask, minimum, maximum = rasterize_local(merged_input, pixels_per_unit=4.0, padding=10.0)
    contours = contours_from_mask(mask, minimum, maximum, pixels_per_unit=4.0)
    report = {
        "character": character,
        "status": "experimental_promoted_base_preserving_ogonek",
        "method": "accepted_base_plus_clipped_inset_attached_ogonek",
        "baseCharacter": base_character,
        "xCut": x_cut,
        "yCut": y_cut,
        "ogonekInwardShift": inward_shift,
        "baseInkWidth": float(np.ptp(base_points[:, 0])),
        "outputInkWidth": float(np.ptp(np.vstack([points for _, points in contours])[:, 0])),
        "separableMarkGeometry": str(mark_path.relative_to(PROJECT)),
        "topology": mask_topology(mask),
    }
    save(character, contours, report)
    return report


def lowercase_g_comma_above():
    base = [(role, points.astype(np.float64)) for role, points in archived_contours(geometry_for(ord("g")))]
    comma = max(
        (points.astype(np.float64) for role, points in archived_contours(geometry_for(ord(","))) if role == "outer"),
        key=len,
    )
    center = 0.5 * (np.min(comma, axis=0) + np.max(comma, axis=0))
    mark = -(comma - center) * 0.58
    body = np.vstack([points for _, points in base])
    body_top = float(np.max(body[:, 1]))
    mark_min, mark_max = np.min(mark, axis=0), np.max(mark, axis=0)
    mark[:, 0] -= 0.5 * (mark_min[0] + mark_max[0])
    mark[:, 1] += body_top + 24.0 - mark_min[1]
    contours = base + [("outer", mark)]
    report = {
        "character": "ģ",
        "status": "experimental_promoted_latvian_comma_above",
        "method": "accepted_g_plus_rotated_scaled_comma_above",
        "baseCharacter": "g",
        "markScale": 0.58,
        "markRotationDegrees": 180,
        "baseToMarkGap": 24.0,
        "formerDefect": "eight-unit horizontal sliver below the descender",
        "topology": {"components": 2, "holes": 1},
    }
    save("ģ", contours, report)
    return report


def main():
    summary = {
        "aogonek": attached_ogonek("ą", "a"),
        "gcedilla": lowercase_g_comma_above(),
        "uogonek": attached_ogonek("ų", "u"),
    }
    output = PROJECT / "reports" / "extended-body-repairs.json"
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
